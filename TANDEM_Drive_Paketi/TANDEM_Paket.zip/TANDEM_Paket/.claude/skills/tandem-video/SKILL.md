---
name: tandem-video
description: TANDEM ekibi için kısa eğitim/tanıtım videosu üretirken yüklenir ("video yap", "yeni video", "altyazılı anlatım", "ekran kaydını düzenle"). tools/video şablonunu, süre sınırını, kontrol listesini ve teslim kuralını içerir.
---

# TANDEM video yönergesi

İlk yanıtının ilk satırı `TANDEM video yönergesi yüklendi.` olsun, ardından yapacağını 1-2 cümleyle söyle. Sade Türkçe yaz.

## Önce oku
`docs/VIDEO_REHBERI.md` (5 yol, kanıt etiketleri) ve `tools/video/README.md`. Başka araç (Hyperframes, Remotion, DaVinci) yalnızca kullanıcı isterse; rehberde "denenmedi" yazanı çalışıyormuş gibi anlatma.

## Kurallar (ekibin seçtikleri)
- **Süre:** bir video yaklaşık 2-3 dakika, en çok **3 dakika**, tek konu. Konu uzunsa ikiye böl, her biri kendi dosyası olsun.
- **Ses:** varsayılan Microsoft Türkçe sinir sesi `tr-TR-AhmetNeural` (`edge-tts`, ayar `tools/video/kaynak/ses_ayar.json`; kadın sesi `tr-TR-EmelNeural`). Çevrimiçi servis: metin Microsoft'a gider, gizli bilgi okutma; `edge-tts` resmî değil. Kurulu değilse `pip install edge-tts` (kurmadan önce kullanıcıya söyle) ya da `"motor": "windows"` (yedek, daha yapay). Kullanıcı kendi sesini koyarsa `tools/video/ses_kendi/` altına aynı adlı WAV; sesin doğallığını/anlaşılırlığını "ölçtüm" diye yazma, insan dinlemeli.
- **Teslim:** `.mp4` ve `.srt` üret, **dosya yolunu söyle**. Drive'a yükleme, paylaşma, yayınlama kullanıcının eylemidir; yapma.
- Kayıt ya da ekran görüntüsünde parola, e-posta, anahtar, hesap adı görünüyorsa dur, kullanıcıya göster.
- Yeni araç/skill/MCP kurmadan önce resmî kaynağı oku; indirme boyutunu ve komutu söyle, **onay iste**; yalnızca proje klasörüne kur.

## Süreç (tools/video, Yol B)
1. `tools/video/kaynak/senaryo/v06.py`'yi örnek al; yeni `v0N.py` yaz (`no`, `dosya`, `baslik`, `sahneler`), `senaryo/__init__.py` listesine ekle. Her cümle kısa ve tek fikirli olsun.
2. `cd tools/video/kaynak` → `python uret.py N --kareler` → `tools/video/kare/` altındaki kareleri **aç ve bak** (yazı taşıyor mu, okunuyor mu). Taşma hata verir; cümleyi kısalt ya da sahneyi böl.
3. `python uret.py N` → `tools/video/cikti/` altında mp4 + srt.
4. Ölç: süre ≤ 180 sn, ses seviyesi `ffmpeg -i x.mp4 -af ebur128=framelog=quiet -f null -` ile yaklaşık -16 LUFS.
5. Dosya başına en çok 25 KB, sabit metin senaryoda (kodda değil).

## Ekran kaydı montajı (Yol A, `kayit.py`)
1. Kaydı önce **tara**: kareler (15 sn) + `ffmpeg freezedetect/silencedetect`; ekranda ad, e-posta, sekme başlığı var mı bak. Ses çoğu zaman konuşma değildir; kullanıcıya sor, uydurma.
2. Kesim kararını kullanıcının notundan/metninden al; içeriği bilmeden "gereksiz" sayma. Başka bir yerde yeniden açılan "boş sohbet" karşılamasını (ad içerir) şablon eşleştirmeyle ara.
3. `tools/video/kaynak/planlar/*.json` yaz (örnekler orada), `python kayit.py <plan> --kaynak <kayıt> --kareler` → `tools/video/kare/<dosya>_sayfa.jpg` sayfasını **aç, bak**; sonra tam üret. Toplam 3 dk geçilirse ikiye böl. Bölüme `anlatim` yazarsan Ahmet sesiyle seslendirilir (görüntü gerekirse yavaşlar).
4. **Kullanıcı adı/e-posta/hesap adı** görünen her saniyeyi `bulanik` ile kapat (içerik kayıyorsa `[x, y, w, h, "d:ss", "d:ss"]`). Üretimden sonra **çıktı karelerine bak**: açılır listeler (Gezgin adres çubuğu) ve yol kutuları sık kaçar. Windows OCR taraması yalnızca yardımcıdır (koyu zeminde yakalaması düşük), kanıt sayma.
5. Orijinal kaydı değiştirme, silme, kopyalama; çıktı `tools/video/cikti/`.

## Rapor
```
Ne yaptım:        ...
Nasıl doğruladım: ... (çalıştırdığım komut, süre, LUFS, baktığım kareler)
Denenmedi/açık:   ... (ör. insan dinlemesi, kendi ses)
Dosyalar:         ... (yol)
Senin yapacağın:  Drive'a yükleme / paylaşma / yayınlama
```
