# Kendi videonu yap (ekip için)

Amaç: proje sahibine bağlı kalmadan, yapay zekâ yardımıyla kısa anlatım videosu üretmek (yeni özellik tanıtımı, "nasıl yapılır", test notu). Eğitim serisindeki 6 video bu rehberdeki **Yol B** ile yapıldı; kaynağı `tools/video/` altındadır.

**Videoları izledikten sonra ne yapacağını bilmiyorsan:** `VIDEO_FOYU.md` (her video için adım adım alıştırma, yapıştırılacak metinlerle). Bu sayfa araçların başvuru kaynağıdır, föy ise "bugün ne yapacağım" sayfasıdır.

Kanıt etiketleri: **Doğrulandı** = bu projede çalıştırıp gördük. **Belgeye göre** = resmî sayfada yazıyor, burada denemedik. **Denenmedi** = kurulmadı/çalıştırılmadı.

## 1) Hangi yol, ne zaman?
| Yol | Ne için | Zorluk | Durum |
|---|---|---|---|
| A. Ekran kaydı + yapay zekâ montajı | Gerçek ekranı kes, yakınlaştır, altyazı ekle (ilk MCP rehber videosu böyle yapıldı) | Kolay | Doğrulandı |
| B. `tools/video` şablonu (Python + ffmpeg) | Metinden anlatımlı, altyazılı slayt videosu; ücretsiz Türkçe ses | Kolay-orta | Doğrulandı (6 video) |
| C. Hyperframes (HTML → MP4) | Tasarım odaklı kısa hareketli grafik, tanıtım, başlık | Orta | Doğrulandı (kuruldu, 9 sn örnek 17 sn'de render edildi) |
| D. Remotion (React → MP4) | Kodla video; çok sahneli, veriye bağlı | Orta-zor | Skill'ler kuruldu (belgeye göre); proje/render **denenmedi** |
| E. DaVinci Resolve MCP | Profesyonel editörde kesme/renk/ses | Zor | Belgeye göre; **kurulu değil, denenmedi** |

Başlangıç önerisi: önce A, sonra B. C-E "merak ediyorum" ya da "B yetmiyor" olunca.

## 2) Yol A: ekran kaydı + yapay zekâ montajı
**Önerilen (araç fark etmez, doğrulandı 2026-10-06):** `tools/video/kaynak/kayit.py` + plan dosyası. 15 dakikalık bir ekran kaydı bu yolla 2:17 ve 2:30'luk iki videoya bölündü: gereksiz bölümler kesildi, bekleme/yazma anları 3x-6x hızlandırıldı, önemli yerler yakınlaştırıldı, altyazı ve Türkçe anlatım (plandaki `anlatim` alanı) eklendi; kaydın kendi sesi atılır, anlatım sığsın diye görüntü gerekirse yavaşlar (en çok 0,6x) ve son kare tutulur. Bulanıklık varsayılan **kapalı** (proje sahibinin kararı: bulanık ekranda ne yapıldığı anlaşılmıyor); gerekirse `TANDEM_BULANIK=1` ile plandaki kutular uygulanır. Ad, e-posta, parola, başka uygulama bildirimi görünen anları **kesmek** (ya da kırpmayı o alanı dışarıda bırakacak şekilde seçmek) en iyi yoldur. Paylaşmadan önce çıktı karelerine bak (makine taraması yalnızca yardımcıdır, yakalama oranı düşük); kesim sınırında bir sonraki ekranın 1-2 karesi sızabilir, bu yüzden bitişi geçişten 0,3-0,5 sn önce seç. Adım adım: `VIDEO_FOYU.md` Video 4. Aşağıdaki liste Claude/Kinocut ile elle montaj içindir.
Kayıttaki kişisel veri: yeni boş sohbetin "İyi günler, <ad>" karşılaması ve tarayıcı sekme başlıkları en sık sızanlardır; planı yazmadan önce kareleri tara.
1. Kaydı al. Windows Xbox Game Bar (`Win`+`Alt`+`R`) yalnızca açık uygulama penceresini kaydeder (bilgi, bu bilgisayarda denenmedi); tüm ekran için OBS (ücretsiz, bu bilgisayarda kurulu değil).
2. Kayıtta parola, e-posta, anahtar görünmesin. Görünürse yapay zekâdan o bölümü bulanıklaştırmasını iste. Ad ve klasör yolları bulandırılmaz (proje sahibinin kararı, okunabilirlik için); parola/anahtar/e-posta görünen anı kes. Bulanıklık gerekirse `TANDEM_BULANIK=1` ile açılır.
3. Yapay zekâya (ffmpeg veya Kinocut MCP ile) ver:
```
kayit.mp4'ü düzenle: sessiz/bekleme yerlerini kes, tıklanan yerleri yakınlaştır,
her adıma Türkçe altyazı ekle. Önce 1 dakikalık taslak çıkar; ben dakika:saniye
vererek notlarımı yazacağım, sonra son sürümü çıkar.
```
4. Taslağı kendin izle, notlarını dk:sn ile ver ("0:42 altyazı geç kaldı"). Yapay zekâ videoyu baştan sona izleyemez, kareleri örnekler: son kontrol sende.

## 3) Yol B: `tools/video` şablonu
Gerekenler (Windows): Python 3.10+, ffmpeg, `pip install pillow numpy edge-tts`.
**Ses (varsayılan, daha doğal):** Microsoft'un Türkçe sinir sesi `tr-TR-AhmetNeural` (erkek; kadın için `tr-TR-EmelNeural`), `edge-tts` kütüphanesiyle. Ayar: `tools/video/kaynak/ses_ayar.json` (`ses`, `hiz`, `perde`). Bilmen gerekenler: (1) internet ister; (2) **metin Microsoft'un çevrimiçi servisine gider**, gizli bilgi yazma; (3) `edge-tts` resmî değil, Edge'in okuma servisini kullanan açık kaynak (GPL-3.0) bir paket; servis değişirse bozulabilir; (4) hesap ya da anahtar gerekmez. `edge-tts` başka bir Python'a kuruluysa o yorumlayıcının yolunu `TANDEM_SES_PYTHON` ortam değişkenine yaz. İnternetsiz/yedek yol: `ses_ayar.json` içinde `"motor": "windows"` (Windows'un yerleşik "Microsoft Tolga" sesi, daha yapay; Windows'ta Türkçe konuşma sesi kurulu olmalı). Motor, ses ya da hız değişirse WAV'lar otomatik yeniden üretilir. Doğallığı makine ölçemez: bir insan dinlemeli.
**Süre:** bir video en çok 3 dakika, tek konu (uzunsa ikiye böl).

```
cd tools\video\kaynak
python uret.py 4 --kareler     # yalnızca kontrol kareleri: ..\kare\
python uret.py 4               # videoyu üret: ..\cikti\04_....mp4 + .srt
python uret.py                 # hepsini üret
```
Akış: `senaryo/` (metin) → `ses_motor.py` (`ses_edge.py` ya da `ses.ps1`; cümle başına bir WAV, değişmeyen cümle yeniden okunmaz) → `cizim.py` (her sahne 1920x1080) → `muzik.py` (telifsiz sentez fon müziği + küçük efektler) → `uret.py` (ffmpeg, -16 LUFS).

| Dosya | Ne yapar |
|---|---|
| `senaryo/v01.py ... v06.py` | Her video bir dosya: sahneler, cümleler, ekranda görünecekler |
| `senaryo/sesletim.py` | İngilizce sözcüğün Türkçe okunuşu (yalnızca seslendirme; ekranda özgün yazım) |
| `cizim.py` | Sahne türleri: `kapak`, `liste`, `iki_sutun`, `kod`, `akis`, `kart`; taşan yazıyı hata olarak durdurur |
| `muzik.py` | Fon müziği ve efektler |
| `uret.py` | Ses karışımı, kareler, ffmpeg, altyazı (.srt) |

**Yeni video:** `v06.py`'yi `v07.py` olarak kopyala → `no`, `dosya`, `baslik`, `sahneler`i değiştir → `senaryo/__init__.py`'ye ekle → `python uret.py 7 --kareler` → kareleri aç, bak → `python uret.py 7`.
**Kendi sesin:** aynı adlı WAV'ı (`01_02_03.wav`) `ses_kendi\` altına koy; varsa o kullanılır (makine sesi yer tutucudur; doğallığı ve anlaşılırlığı makineyle ölçülmedi, bir insan dinlemeli).

## 4) Yol C: Hyperframes
Bilgi (resmî depo `heygen-com/hyperframes`, Apache-2.0, Node 22+ ve ffmpeg gerekir). Bu bilgisayarda doğrulanan kurulum (Node 24):
```
mkdir arac & cd arac
npm init -y
npm install hyperframes                          # ~34 MB paket
npx hyperframes browser ensure                   # bir kez: 114 MB Chrome Headless Shell
npx hyperframes telemetry disable                # anonim kullanım verisini kapat
npx hyperframes init ornek --example blank --non-interactive --skip-transcribe
cd ornek
npx hyperframes check                            # yazı okunur mu, animasyon oynuyor mu
npx hyperframes render --output ..\ornek.mp4
```
Notlar:
- Çalışan örnek: `tools/video/hyperframes_ornek/index.html` (HTML + GSAP). `npx hyperframes check` geçti (29/29 okunabilirlik); render 9 sn video / 17 sn.
- `npm install` esbuild'in kurulum betiğini güvenlik gereği engelledi ("allowScripts"); onaylamadan da çalıştı. Gerekmedikçe onaylama.
- Sistemdeki Chrome'u elle çağırma (Chrome'un açık oturumuna dokunur); `browser ensure` kendi tarayıcısını indirir.
- Örnekte GSAP internetten, yazı tipi Google Fonts'tan gelir; çevrimdışı gerekirse dosyaları yerele al.
- Hyperframes'in kendi skill'leri (`npx hyperframes skills update`) ayrı indirmedir; **bu ekipte kurulmadı**. İstersen yapay zekâdan önce ne indireceğini söylemesini iste.
- Kinocut MCP'sinin `hyperframes_*` araçları CLI'ı yolda bulamazsa `hyperframes_not_found` verir (bu bilgisayarda böyle oldu). CLI'ı doğrudan kullan; Kinocut'a bağlamak için Kinocut'un `env` ayarına `MCP_VIDEO_HYPERFRAMES_COMMAND` eklenir. Bu bilgisayarda 2026-10-06'da proje sahibinin onayıyla `claude_desktop_config.json` içine eklendi (kaynakta değişkenin dosya yolunu olduğu gibi kabul ettiği okundu; yedek dosya yanında). **Claude Desktop yeniden başlatıldıktan sonra `hyperframes_doctor` ile doğrulanacak: şimdilik "eklendi, denenmedi".** Ayrıntı ve geri alma: `VIDEO_FOYU.md` son bölüm.

## 5) Yol D: Remotion
- Remotion'un **eski MCP'si kullanımdan kalktı**; resmî yöntem skill'ler (belgeye göre, remotion.dev/docs/ai/mcp).
- Bu ekipte kurulan: `arac/.claude/skills/` altında 7 skill (`remotion-best-practices`, `-create`, `-markup`, `-render`, `-captions`, `-studio`, `-docs`). Komut: `npx skills add remotion-dev/skills --skill <ad...> -a claude-code -y --copy`. İçlerinde yalnızca iki küçük `.mjs` betiği var (harita hazırlama; yalnızca `fs`/`path`/`url` kullanıyor, okundu).
- Remotion projesi oluşturma ve render **denenmedi**. Yapay zekâya "remotion-create skill'ini kullanarak 10 saniyelik bir başlık videosu yap" de ve sonucu `render` ile doğrulat.
- **Lisans (belgeye göre, GitHub LICENSE.md):** bireyler, en fazla 3 çalışanlı şirketler ve kâr amacı gütmeyenler ücretsiz; 3'ten çok çalışanlı kâr amaçlı şirketler şirket lisansı almalı. Ekip büyürse tekrar kontrol et.

## 6) Yol E: DaVinci Resolve MCP
- Açık kaynak (MIT) `samuelgursky/davinci-resolve-mcp`: Resolve 18.5+ ve Python 3.10+ ister; dışarıdan tam kontrol için **ücretli Studio** sürümü gerekir, ücretsiz sürümde komutlar Resolve içinden bağlanır (belgeye göre). Kurulum: `npx davinci-resolve-mcp setup` (denenmedi).
- Bu bilgisayarda DaVinci kurulu değil (birkaç GB indirme). Ekipte biri zaten kullanıyorsa kendi bilgisayarında dene; kurulum bir MCP ayarı ekler, o yüzden önce resmî sayfasını oku.

## 7) Her videodan önce kontrol listesi
- [ ] Önce **1 dakikalık taslak**; sonra tam sürüm.
- [ ] Kontrol karelerine bak: yazı taşmıyor, renk okunuyor.
- [ ] Ses seviyesi: `ffmpeg -i video.mp4 -af ebur128=framelog=quiet -f null -` → "Integrated loudness" yaklaşık -16 LUFS.
- [ ] Kayıtta kişisel bilgi yok (parola, e-posta, anahtar, hesap adı).
- [ ] Müzik/görüntü lisansı belli.
- [ ] Bir insan baştan sona izledi/dinledi.

## 8) Sık sorunlar
| Belirti | Çözüm |
|---|---|
| `Türkçe ses (tr-TR) bulunamadı` | Windows Ayarlar → Saat ve dil → Konuşma → Türkçe ses ekle |
| `Metin sığmıyor` / `Kod penceresi taşıyor` | Cümleyi/satırı kısalt ya da sahneyi ikiye böl (hata kasıtlıdır: taşan yazı videoya girmesin) |
| `npx skills add` soru soruyor | `-y` ekle, `--skill` ile adları ver |
| Hyperframes `Chrome ... ETIMEDOUT` | `npx hyperframes browser ensure` çalıştır |
| ffmpeg bulunamadı | Kur ve yeni terminal aç (bu bilgisayarda WinGet klasöründe kurulu: `winget search ffmpeg` ile paketi bul) |

Yeni araç kurmadan önce: resmî kaynağı oku, indirme boyutunu ve neyi yazdığını söyle, yalnızca proje klasörüne kur, parola/anahtar isteyen kuruluma dikkat et (`docs/DEVIR_REHBERI.md` §3).
