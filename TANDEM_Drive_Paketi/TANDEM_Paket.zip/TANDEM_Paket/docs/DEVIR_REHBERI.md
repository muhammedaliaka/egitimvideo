# TANDEM devir rehberi (proje sahibi ara sıra destek verir)

2026-10-06'dan itibaren proje sahibi **ara sıra** destek verir. Günlük işi ekip yürütür. Bu sayfa kimin ne yaptığını, hangi sorunun kimde çözüleceğini ve yardımın nasıl isteneceğini anlatır.
Yapay zekâyla nasıl çalışılır: `EKIP_REHBERI.md`. İş kaydı: `EKIP_GUNLUGU.md`. Ne denendi, ne açık: `VAKA_TANDEM.md`.

## 1) İzleme sırası (toplam ~19 dk, Drive'da `Egitim_Videolari` klasöründe)
| Sıra | Video | Süre | Ne öğrenirsin |
|---|---|---|---|
| 0 | `TANDEM_Rehber_Video.mp4` | 6:04 | Claude'u kur, Roblox Studio'ya MCP ile bağla (anlatımlı: altyazı satırları aynı doğal Türkçe sesle okunur) |
| 1 | `01_Yapay_zeka_ne_yapar_nerede_yanilir.mp4` | 2:18 | Neyi iyi yapar, nerede uydurur; "güven ama doğrula" |
| 2 | `02_Muhakeme_guclu_ve_sinirli.mp4` | 2:07 | İyi istek kalıbı, hata ayıklama sırası, 4 soru |
| 3 | `03_Aciklari_bulan_skilller.mp4` | 2:25 | Güvenlik skill'leri, Roblox'ta istemciye güvenmeme |
| 4 | `04_Yapay_zeka_ile_video_duzenleme.mp4` | 2:57 | ffmpeg, kinocut, Remotion, Hyperframes, DaVinci MCP; kendi çekiminden video |
| 5 | `05_MCP_ve_skillleri_kurmak.mp4` | 2:28 | CLAUDE.md, skill yazma, dosya izni, MCP güvenliği |
| 6 | `06_Projeyi_birlikte_surdurmek.mp4` | 1:48 | Görev döngüsü, birleştirici, ne zaman sahibine yazılır |
| 7 | `07_Filesystem_ve_Desktop_Commander.mp4` | 2:17 | Claude Desktop'a Filesystem (dosya erişimi) ve Desktop Commander (komut erişimi) ekleme; Node.js notu `VIDEO_FOYU.md` Video 7'de |
| 8 | `08_Blender_MCP_kurulumu.mp4` | 2:30 | Claude'a Blender MCP'sini araştırtıp kurdurma, Blender'da bağlama, araba animasyonu denemesi |

Her videonun yanında aynı adlı `.srt` altyazı dosyası vardır (seslendirme Microsoft'un Türkçe yapay sinir sesidir, erkek ses "Ahmet"; altyazı videoya da gömülüdür). Eğitim videoları (1-8) 1-3 dakikadır; rehber video (0) 6:04'tür ve ikiye bölünmedi. 0, 7 ve 8 numaralılar proje sahibinin ekran kaydından kesilip anlatım eklenerek yapıldı (kayıttaki kendi sesi atıldı, yerine aynı sinir sesi kondu). 7 ve 8'in başında "herkesin bilgisayarını göremiyoruz; MCP bağlı değilse yapay zekâna sor" uyarısı vardır. Bu videolarda **bulanıklık yoktur** (proje sahibinin kararı: bulanık ekranda ne yapıldığı anlaşılmıyor); kayıtlarda proje sahibinin Windows kullanıcı adı, klasör yolları ve sohbet başlıkları görünür. Parola/anahtar görünmez (kontrol edildi). Videoları dışarıya paylaşmadan önce bir kez izleyip karar ver.

**Her videodan sonra ne yapılır:** `VIDEO_FOYU.md` (video başına adım adım alıştırma: ne yapıştırılır, ne görülmeli, takılınca ne bakılır). Önerilen sıra: video izle → föydeki aynı numaralı bölümü yap.

**Kendi videonu yapmak için:** `VIDEO_REHBERI.md` (5 yol, hangisi ne zaman) ve `tools/video/` şablonu. Eğitim videolarının hepsi bu şablonla üretildi; yeni video = bir senaryo dosyası kopyalamak.

## 2) Roller
| Rol | Kim | Yapar | Yapmaz |
|---|---|---|---|
| Ekip üyesi | herkes | Kilitler tablosuna yazar, yapay zekâyla küçük adım atar, denetim + Play ile dener, günlüğe yazar, değişen dosyaların listesini birleştiriciye yollar | Yayınlamaz, kilitli kararı tek başına değiştirmez |
| Birleştirici | ekibin seçtiği **1 kişi** | Değişiklikleri kendi kopyasında toplar → `node tools/denetim/denetim.js` (0 ihlal) → Studio'da bir tur oynar → `powershell -ExecutionPolicy Bypass -File tools\paket\paketle.ps1` → yeni zip'i Drive'a koyar → günlüğe "paket" satırı yazar | Yayınlamaz |
| Proje sahibi | ara sıra | Yayınlama (Publish), test kişisi daveti, oyunu açma/kapama, hesap/para, kilitli karar değişikliği, haftalık özetin okunması | Günlük kod işi |

## 3) Hangi sorun kimde çözülür?
| Durum | Önce ne yapılır | Sahibe gerek |
|---|---|---|
| Studio'da tekrar eden kod/ayar hatası | Yapay zekâya: "iki olası neden yaz, ölçerek ayır, kök nedeni düzelt, tekrar ölç" (`EKIP_REHBERI.md` §3) | Hayır |
| Yapay zekâ aynı hatada dönüyor, kuralları unuttu | Yeni sohbet aç, "İlk mesaj kalıbı"nı yapıştır, günlüğü okut | Hayır |
| Studio MCP bağlanmıyor | Rehber videosu "Bağlantıyı doğrula" bölümü. Olmazsa MCP'siz çalış: yapay zekâ `src`'yi değiştirir, sen `rojo build` ile yeni `Tandem.rbxl` üretip elle dene | Hayır |
| Team Create hatası (`connectToTeamCreateSession`) | `OKU_BENI.md` §3; herkes yerel paketle çalışsın | Hayır |
| İki kişi aynı dosyayı değiştirmiş | Birleştirici yapay zekâya iki sürümü verir: "ikisini karşılaştır, iki değişikliği de koru, denetimi çalıştır" | Hayır |
| Yeni özellik fikri | Serbest. Kilitli kararlarla (`PRODUCT_KARARLAR_tandem.md`) çelişmiyorsa yap, günlüğe yaz | Hayır |
| Kilitli bir kararı değiştirmek (D1-D4, D10-D12, D14-D16) | Gerekçeyi 3-4 cümleyle yaz | **Evet** |
| Yayınlamak, test kişisi davet etmek, oyunu açmak | Paket + günlükte test sonucu hazır olsun | **Evet** (sahibin işi) |
| Hesap, para, satın alma, ücretli araç | Ne gerektiğini ve nedenini yaz | **Evet** |
| 2 gündür çözülmeyen sorun | Aşağıdaki kalıpla yaz | **Evet** |

## 4) Yardım mesajı kalıbı (tek mesaj)
```
Ne yapmaya çalıştım: ...
Ne oldu (hata metni; ekran görüntüsü yalnızca Studio penceresinden): ...
Ne denedim: ...
Günlükteki satır: ...
Paket / tarih: ...
```
Parola, anahtar, e-posta gibi kişisel bilgiyi mesaja, ekran görüntüsüne ve dosyaya koyma.

## 5) Haftalık ritim (öneri)
- **Hafta başı (15 dk):** herkes günlüğü ve `VAKA_TANDEM.md`'yi okur, bir görev seçip Kilitler tablosuna yazar.
- **Hafta içi:** küçük adımlar; her biri günlüğe tek satır.
- **Hafta sonu:** birleştirici paket çıkarır; ekip Studio'da **Test → Clients and Servers** (2 kişi) ile bir tur birlikte oynar, sonucu günlüğe yazar.
- **Sahibe haftalık tek mesaj:** "bu hafta ne bitti, neye ihtiyaç var" (yalnızca §3'te "Evet" olan konular).

## 6) Açık işler (2026-10-06 itibarıyla)
- İki gerçek kişiyle eşleşme ("Eş Bul") yolu denenmedi; DataStore'a gerçek yazma/okuma doğrulanmadı.
- Madalya eşikleri bot ölçümüne göre geçici (Altın 75 / Gümüş 100 / Bronz 135 sn); gerçek oyuncu süreleriyle ayarlanacak.
- Sesler yer tutucudur (D4: gerçek sesler sahipten/ekipten gelir; yalnızca `Ayar/Ses` içindeki `Kaynak` satırları değişir).
- İlk Play'de (soğuk başlangıç) istemci araç görselleri bir kez kurulmadı; nedeni doğrulanmadı (`AracGorsel`, `MeshSablon`, StreamingEnabled şüpheli).
- Efekt eşzamanlama (Eszaman) Studio'da ölçüldü; canlı sunucuda gerçek ağ gecikmesi ve gerçek telefonla denenmedi.
