# TANDEM — karar defteri (soru-cevap ile)

Amaç: hafif bir prototip için yapılandırma belgesine giden yolda her kararı **gerekçesiyle** kaydetmek. Kullanıcı cevaplar; bıraktığı yerde mantıkla ben karar veririm ve gerekçesini yazarım.
Ana hedef (değişmedi): Akım mimarisini pürüzsüz yansıtmak; arkadaşların sisteme abone olup yeni bilgileri görmesi. Oyun, Akım'ın bulduğu fırsatın uçtan uca kanıtı.
Bağlam: [CASE_happy_wheels.md](CASE_happy_wheels.md), [PRODUCT_PLAN_tandem_coop.md](PRODUCT_PLAN_tandem_coop.md).

## Tur 1 (2026-10-03)

| # | Konu | Karar | Kim | Gerekçe |
|---|---|---|---|---|
| D1 | Ana his | **Komik kaos: mekanik ağırlıklı co-op** (bulmaca yalnızca küçük "ikimiz birlikte" engelleri) | kullanıcı | Mekanik/komedi odaklı iki kişilik oyunlar yeni ve yüksek (Grapple Cart 11 bin, Carry the Glass 5,4 bin); bulmaca odaklılar düşük (Teamwork Puzzles 1,4 bin, %51 beğeni). Kısa video üretir. |
| D2 | Zorluk | **Çok kolay giriş, 3. dakikadan sonra orta zorluk**; ilk bölümü oyuncuların ≥%60'ı bitirsin | kullanıcı | Türde oyuncuların %86-91'i ilk kilometre taşına ulaşmadan çıkıyor (Biker Duo dünya 1: %9; Webbed ilk 100 m: %14; Teamwork Puzzles 4. seviye: %18). Terk en çok ilk dakikada. |
| D3 | Eş sorunu | **Bot eş + hızlı eşleşme + arkadaş daveti** | kullanıcı | İlk haftalarda oyuncu azken eş bulunamazsa ilk oturum ölür. |
| D4 | Ekip | Roblox bilen yok; **ses efekti ve müziği kullanıcı yapıyor**; animasyondan çekiniliyor; yapay zekayı kullanıcı öğretecek; 3D'yi yapay zekayla üretip isteyen Blender'da düzenler | kullanıcı | Aşağıda D5-D8 bundan türüyor. |

## Ekip gerçeğinden türeyen kararlar (ben verdim)

| # | Karar | Gerekçe |
|---|---|---|
| D5 | **Özel animasyon yok.** Komedi fizikten (ragdoll, çarpışma, savrulma) ve **sesten** gelir; karakter için Roblox'un varsayılan animasyonları. | Ekip animasyondan çekiniyor; komik "kaza" fiziksel olduğu için animasyon gerektirmez. |
| D6 | **Ses ana komedi aracıdır** (kullanıcının güçlü yanı): her çarpma/uçuş/kurtuluş için kısa komik ses, müzik dinamik (gerginlik→rahatlama). Klip kalitesini ve hatırlanabilirliği belirler. | İzlenen kısa videoların komiği ses+zamanlamadır; ekibin tek hazır yetkinliği bu. |
| D7 | **Görsel stil: sade, blok/düşük poligon, oyuncak paleti.** Modeller Roblox Assistant'ın `generate_procedural_model` (ilkel parçalardan) ve `generate_mesh` araçlarıyla; isteyen Blender'da düzeltir (isteğe bağlı). | Yapay zekayla üretimi en kolay ve tutarlı stil; Roblox'un kendi estetiğine uyar. |
| D8 | **Araç zinciri: Roblox Studio + resmî Studio MCP sunucusu + Claude Code.** Claude Code Luau yazar/çalıştırır/test eder, ekran görüntüsü alır; Dosya tabanlı çalışma için Roblox'un resmî **Script Sync** (beta) yöntemi + git kontrol noktaları (Rojo gerekmez; *2026-10-03 düzeltme: resmî "coding harness" rehberi Script Sync öneriyor*). Kullanıcı "sistem kurucusu ve öğretmen" rolünde. | Roblox belgesi: MCP sunucusu Studio'daki script, mesh/model üretimi, Luau çalıştırma, test oyunu, ekran görüntüsü ve girdi simülasyonu araçlarını sunuyor; Claude Code hızlı bağlantı listesinde. Güvenlik: yalnızca güvenilen istemci bağlanır. |
| D9 | **Kapsam "dikey kesit" ile başlar:** 1 araç, 1 parkur, 2 oyuncu (+bot), mobil kontrol, ses seti. Yeni ekip için tahmin süresi, deneyimli ekibe göre uzar (aşağıdaki plan tablosu). | Fizik/ağ en riskli kısım; deneyimsiz ekipte önce bunu kanıtlamak şart. |

## Tur 2 (2026-10-03)

| # | Konu | Karar | Kim | Gerekçe |
|---|---|---|---|---|
| D10 | Araç/tema | **Tekerlekli ev eşyaları** (küvet, koltuk, yatak): iki oyuncu aynı eşyaya bağlı | kullanıcı | Tanıdık, komik, tek bakışta anlaşılır küçük görsel; ilkel parçalardan (blok) üretimi kolay; ev eşyası olmak "ciddi araç" rakiplerinden ayırır (gimmick). |
| D11 | Kontrol | **Asimetrik roller:** sürücü (direksiyon/denge) + yardımcı (gaz/fren + özel yetenek); roller kontrol noktalarında değişebilir | kullanıcı | İki oyuncunun da sürekli işi olur, birbirine bağımlı olurlar (türün asıl çekiciliği); bot eş için rol kuralı basit kalır. |
| D12 | Arkadaş aboneliği (Akım) | **Ayrı ntfy konusu:** yalnızca S/A fırsat + günlük özet | kullanıcı | Arkadaşlar telefonu boğmadan yalnızca "gerçekten önemli" bilgiyi görsün. Konu adı gizli anahtardır (aşağıda Akım bölümü). |
| D13 | Zaman bütçesi | **Bilinmiyor** (kullanıcı: "kesin rakam söyleyemem, ilk işimiz olacak"). Plan **saat** cinsinden yazılır; yer tutucu: 25 sa/hafta tüm ekip toplamı. **Faz 0 hız ölçümü** gerçek hızı (K katsayısı) ölçer, plan ona göre yeniden ölçeklenir | kullanıcı + ben | Tahmin yerine ölçüm; yanlış yer tutucu planı bozmasın diye ilk iş ölçümdür. |

## Tur 3 (2026-10-03)

| # | Konu | Karar | Kim | Gerekçe |
|---|---|---|---|---|
| D14 | Ekip | **3-4 kişi**: sistem kurucusu/öğretmen (kullanıcı), ses+müzik, 3D düzenleme (isteğe bağlı Blender), test/ölçüm | kullanıcı | Roller [PROTOTIP_TANDEM_YAPILANDIRMA.md](PROTOTIP_TANDEM_YAPILANDIRMA.md) §6. |
| D15 | Test kişisi | **5-10 arkadaş** (3-5 çift) | kullanıcı | Küçük örnek: Kapı A "ilk izlenim + gözlem" sayılır, istatistiksel kanıt değil; gerçek kanıt Kapı B'de (kapalı beta). |
| D16 | Hedef | **Önce kanıt, sonra yayın**: prototip yalnızca "ilk 3 dk eğlenceli mi, çift tekrar oynar mı" sorusunu cevaplar; herkese açık yayın ayrı plan | kullanıcı | Boşa emek riski en düşük. |

## Tur 3 sonrası: kullanıcının bana bıraktığı kararlar (ben verdim)

| # | Karar | Gerekçe |
|---|---|---|
| D17 | **Prototipte 1 araç (küvet) tam fizikle**; koltuk ve yatak yalnızca görsel/ses varyantı (aynı fizik) | Fizik ayarı tek sefer; ekip yeni, kapsam dar tutulur. Farklı fizikli araçlar Kapı A'dan sonra. |
| D18 | **1 pist (~3 dk) + modül mimarisi** (8-10 elle yapılmış parça); rastgele sonsuz üretim Kapı A sonrası | Eksik içerik riski küçük; modüller sonradan rastgele üretimin temeli olur. |
| D19 | **Roller prototipte sabit** (lobide seçim/otomatik); rol değiştirme Kapı A sonrası ilk ekleme | Önce asimetrik dengenin eğlenceli olduğu kanıtlansın; değiştirme arayüz+kod maliyeti getirir. |
| D20 | **Bot eş:** yardımcı rolünde bot gaz/freni orta düzeyde ve bilerek ara sıra yanlış zamanda kullanır (komik ama yenilmez değil); sürücü rolünde basit yol izleme + gürültü. Hızlı eşleşme **45 sn** bekler (kullanıcı isteğiyle 12 sn'den yükseltildi, 2026-10-03), sonra bot; gerçek eş **kontrol noktasında** devralır | Bot "mükemmel eş" olursa komedi ölür; hata, kliplik an üretir. Devralma kontrol noktasında olunca fizik kopmaz. |
| D21 | **Zorluk:** 1. bölüm ~90 sn, en çok 2 engel türü, kontrol noktası ~25 sn'de bir, düşünce 2 sn'de yeniden; 3. dakikadan sonra dar köprü + dönen çubuk + rampa | D2'yi (ilk bölümü ≥%60 bitirsin) sayıya çevirir. Parametreler ilk testte ayarlanır. |
| D22 | **Prototipte para kazanma yok**; yalnızca analitik olayları ve pass tasarımı hazır | Kapı A'dan önce satış mühendisliği boşa gidebilir; ölçülmüş merdiven plan §4'te hazır. |
| D23 | **Ölçüm:** Roblox Analytics (Creator Dashboard) + kendi olay günlüğü (huni: giriş → ilk hareket → ilk kontrol noktası → 1. bölüm bitişi → ikinci tur) | Kapı kararı sayıya dayansın; API ayrıntısı Faz 0'da doğrulanır. |
| D24 | **Ses önceliği:** ~20 olay sesi + 2 müzik döngüsü (gerginlik/rahatlama); ses üretimi ekip dışı paralel iş | Komedi sesten gelir (D6); kodu beklemeden paralel yürür. |
| D25 | **Durma/pivot kuralları:** (a) iki oyuncu fiziği Faz 1'de tutarlı değilse "ipsiz, ortak kontrol"e indir; (b) Faz 0 hız katsayısı K>2 ise kapsam yarıya iner; (c) Kapı A geçmezse 1 iyileştirme turu (≤15 sa), sonra dur/pivot | Garanti yok; en ucuza öğrenip durmak planın özü. |
| D26 | **Akım yansıması:** her kapı sonucu `VAKA_TANDEM.md`'ye yazılır (Akım'ın bulduğu fırsat → karar → ürün → ölçüm), arkadaş kanalına özet gider | Ana hedef: Akım'ın uçtan uca değerini göstermek, arkadaşların izlemesi. |

## Akım'a arkadaş aboneliği (D12 uygulaması)
- `AKIM_NTFY_FRIENDS_TOPIC` (yalnızca `.env`'de) tanımlıysa `ntfy:arkadaslar` kanalı açılır: yalnızca **S/A** basamağındaki fırsatlar (ilk bildirim + yükselme) ve **günlük özet**.
- Rehber: [ARKADAS_REHBERI.md](../../akim/docs/ARKADAS_REHBERI.md).

## Açık sorular
Yok. Kalanlar yapılandırma belgesindeki "Faz 0'da doğrulanacaklar" listesinde (teknik doğrulamalar).
