# Ürün planı: çift kişilik fizik-komedi araç oyunu (Roblox) — 2026-10-03

**Tez:** Düz "Obby ama sen ... üstündesin" dikkat çekmez. Dikkat çeken, geri döndüren ve yayılan oyunlar aynı üç şeyi yapıyor: **iki kişinin birbirine bağımlı olduğu fizik komedisi**, **sonsuz yenilenen içerik**, **sık güncelleme**. Plan bu üçünü, 8 hafta ve test kapılarıyla kuruyor.
Happy Wheels ilişkisi: kopya değil. Aynı "komik kaza" hissini Roblox'un kazanan biçimine çeviriyor ([neden değmez](CASE_happy_wheels.md)).

## 1. Kanıt (Roblox canlı ölçüm, 2026-10-03)

| Oyun | Oyuncu | Yaş | Ziyaret/gün | Favori/ziyaret | Olumlu oy | Son güncelleme | Not |
|---|---|---|---|---|---|---|---|
| Grapple Cart Obby [1 & 2 PLAYER] | 11,1 bin | 37 gün | 512 bin | **%0,43** | %93 | 1 gün | 2 kişilik araç + kanca |
| Carry the Glass Together [2 Player] | 5,5 bin | 96 gün | 233 bin | **%0,48** | %88 | 3 gün | iki kişi tek cam paneli taşır |
| Troll Wheelchair Tower | 3,1 bin | 33 gün | 56 bin | %8,6 | %80 | 0 gün | engelli arabasıyla rakibi lavlara itme |
| Obby But You're on a Scooter (düz) | 7,1 bin | 418 gün | 278 bin | %0,09 | %72 | 1 gün | düz araçlı parkur |
| Kart Of Hell (düz, rastgele bölüm) | 5,9 bin | 188 gün | 281 bin | %0,13 | %75 | 5 gün | 30 rastgele bölüm |
| Fling Things and People | 22,2 bin | 5 yıl | — | %0,07 | %80 | 338 gün | fizik komedisi; Roblox'taki en büyük örnek |

**Çıkarımlar** (ölçülen; nedensellik kanıtlanmış değil):
1. **İki kişilik oyunlar favori oranında düz parkurlardan 3-5 kat yüksek** (%0,43-0,48 vs %0,09-0,13). Favori = geri dönme niyeti.
2. **Dışarıya yayılma farkı çok büyük** (son 30 gün, ilk 12 YouTube videosu): Carry the Glass **7,8 M izlenme** (tek bir 20 sn'lik video 5,9 M), Grapple Cart 1,6 M, düz Scooter Obby **72 bin**. Düz parkur dışarıda neredeyse hiç konuşulmuyor; şüpheniz doğru. (Troll Wheelchair Tower için YouTube sayısı verilmedi: arama diğer "Troll Tower" oyunlarıyla karışıyor, güvenilir değil.)
   İzleyici/içerik üretici dilleri çok çeşitli (Endonezce, Tayca, Filipince, Rusça, İspanyolca, Türkçe): çeviri ve çok dilli klip baştan düşünülmeli.
3. **Derin içerik boşa gidiyor:** Scooter Obby'de 100 bölümün "Dünya 1" rozetini oyuncuların %47'si, "Dünya 2"yi %22'si alıyor; 38-40. dünyalar **%0,03**. İlk 8-10 bölüm + sonsuz mod, 100 bölümden değerli. Kart Of Hell ve Tower of Hell **rastgele üretim** kullanıyor (ucuz içerik).
4. **Güncelleme sıklığı:** 100 günden genç tüm kazananlar son 0-13 günde güncellenmiş; 105 gündür güncellenmeyen Skaters Of Hell 2,8 bine inmiş (605 günlük).
5. **Para kazanma Roblox'ta ucuz ve yaygın:** pass fiyat merdiveni 9-199 Robux, tepe 399-599 (tablo §4). Gelir birim fiyattan değil, ziyaret hacminden geliyor.

## 2. Ürün

**Çalışma adı: TANDEM.** İki oyuncu **tek araca bağlı** (iki kişilik bisiklet/hastane yatağı/alışveriş arabası/küvet): biri direksiyon-denge, diğeri gaz/fren/özel yetenek. Parkurda rampalar, dönen çubuklar, boşluklar. **Eksik iletişim = komedi** (Carry the Glass ve Grapple Cart'ın kanıtlanmış kancası).
- **Çekirdek döngü (3-5 dk):** pistten başla → birlikte engelleri aş → düşünce anında yeniden başla (yükleme yok) → rekor/puan → ödül.
- **Gore yok:** çizgi film "ouch", uçan eşyalar, komik ses. Roblox 13+ uyumlu.
- **Eş bulma:** arkadaş daveti **ve** hızlı eşleşme (eşi olmayan oyuncu oyundan çıkmasın). Tek kişiye kolay "solo" mod (bot eş) ilk oturumu kurtarır.
- **İçerik:** ilk lansmanda 3 tema × 3 elle yapılmış bölüm (9) + **rastgele üretilen sonsuz parkur** (modül havuzundan) + günlük meydan okuma. Gimmick modülleri (kanca, itici, ters yerçekimi) güncellemelerle eklenir.
- **Şaşırtma (gimmick):** her hafta bir "komik kural" (ör. araç şişmanlar, direksiyon rastgele yer değiştirir). Dışarı yayılacak anı üretir ve geri getirir.

## 3. Elde tutma (tekrar girme)

| Mekanizma | Neden | Nasıl |
|---|---|---|
| Anında yeniden deneme | "bir tur daha" | ölüm → 1 sn'de başlangıç, yükleme yok |
| Eş bağı | arkadaşla oynayan geri döner | aynı eşle oynadıkça "bağ seviyesi": ortak kozmetik ödüller |
| Günlük/haftalık | alışkanlık | günlük giriş serisi, günlük parkur, haftalık sıralama + etkinlik |
| Koleksiyon | uzun hedef | 8 araç + her araca kozmetik; nadir olanlar etkinliklerde |
| Sık güncelleme | kanıt §1.4 | haftalık küçük, ayda bir büyük (yeni tema + araç) |
| Kodlar | sosyal medya bağı | ayda 1-2 kod; takip/beğeni/favori çağrısı (Troll Tower favori %8,6) |

## 4. Robux (para kazanma): gerçek örneklerden merdiven

| Ürün türü | Gözlenen örnek (Robux) | Bizde |
|---|---|---|
| Kozmetik (iz, deri, korna) | 19-175 (+1 Speed: 42 pass, 83 bin oyuncu), Kitty/Super Cart 99 | 29-99, çok sayıda (10-15 ürün) |
| Rahatlık | Infinite Revives 139, Disable Popups 59-69 | takım yeniden doğuşu 139; reklamsız ekran 59 |
| VIP | 89-99 | 99: 2x altın + etiket + özel oda |
| Güç (hafif) | Double Jump 79, Gravity Coil 59-69, Fast Cart 49 | **yalnızca kozmetik/rahatlık**: eş adaleti bozulmasın |
| "Balina" ürünü | Spike Cart 399, Unlock All 599, Unlimited Rewinds 599 | 399-599: tüm araçlar paketi |
| Hediye | — | eşe takım yeniden doğuşu hediyesi (sosyal ve kârlı) |
| Premium Payouts | — | uzun oturum ek gelir (Roblox Premium kullanıcı süresi) |

Kurallar: ödemeli rastgele kutu **yok** (Roblox'un olasılık/yaş kuralları ve güven kaybı), güç satışı eşi cezalandıran bir şeye dönüşmesin. Dönüşüm oranı ve ortalama harcama **bilinmiyor**: lansmanda ölçülecek (§7).

## 5. Dışarıya yayılma (dağıtım)

1. **Klip üretici tasarım:** her 20-30 sn'de bir komik an (denge kaybı, uçuş, eşin yanlış düğmesi). Uzun yayın değil **kısa video** (Carry the Glass'ın 5,9 M'lik videosu 20 sn).
2. **Davet kancası:** oyun içi "arkadaşını çağır" (Roblox davet penceresi), eş yokken hızlı eşleşme.
3. **Ad/ikon/açıklama:** başlıkta biçim `[1 & 2 PLAYER] Ad`; ikonda iki karakter ve açık duygu; açıklamada arama etiketleri (rakipler yapıyor: "Tags: Obby, ...").
4. **İçerik üreticileri:** lansmandan 2 hafta önce 20-30 orta boy (10 bin-1 M) kanal; **Endonezce, Tayca, Filipince, İspanyolca, Rusça, Türkçe, İngilizce**. Özel sunucu kodu + ücretsiz VIP; ücretli işbirliğinde reklam bildirimi zorunlu.
5. **Çeviri:** Roblox otomatik çeviri açık, metin azaltılmış (ikon/jest ağırlıklı arayüz).
6. **Küçük, ölçülü reklam** (Roblox sponsorlu reklam) yalnızca algoritmaya ilk ivmeyi vermek için; harcama dönüşümle sınırlı (kapı C).

## 6. Kalite ve pürüzsüzlük listesi (lansman engelleyici)

- **Mobil önce:** düşük seviye telefonda ≥30 FPS, dokunmatik kontrol, ilk giriş ≤10 sn.
- **Ağ/fizik:** araç sahipliği tek oyuncuda, eş bağlantısı kısıtla (RopeConstraint/ağırlık dağılımı), gecikme testi (iki farklı bölge). **En büyük teknik risk**, 1. haftada kanıtlanmalı.
- **Hile/sunucu doğrulaması:** bitiş süresi ve kontrol noktaları sunucuda; ışınlanma/hız kontrolü.
- **Veri güvenliği:** DataStore yeniden deneme + oturum kilidi, satın alma makbuzu işleyici idempotent.
- **Moderasyon:** kullanıcı metni yok (yalnızca Roblox filtreli takma ad), içerik olgunluk anketi doldurulmuş, rapor yolu.
- **Ölçüm:** olay günlüğü (bölüm, süre, eş türü, satın alma) + lansmandan önce huni panosu.
- **Yayın operasyonu:** hazırlık (staging) yeri, geri alma, sürüm notu oyun içi, haftalık yayın takvimi.
- **Hukuk:** rakip adı/varlık/müzik kopyası yok; Roblox ses kütüphanesi.

## 7. Plan ve kapılar (7 kişi, yapay zekayla ~8 hf; hedef 8,7)

| Hf | Çıktı | Kapı |
|---|---|---|
| 1-2 | Dikey kesit: eş bağlantılı araç fiziği, 1 pist, mobil | **A:** 10 çift oynatma: ≥7 çift gönüllü yeniden dener, ≥12 dk ortalama oturum, fizik kopmuyor |
| 3-4 | Rastgele parkur üreteci, 3 tema/9 bölüm, eşleşme, kontrol noktaları | iç test: 20 çift, çökme yok |
| 5 | Meta: para birimi, 8 araç, kozmetik, günlük ödül, sıralama, pass'ler, analitik | — |
| 6 | Cila, çeviri, ikon/fragman, kapalı beta (50-100 kişi), içerik üretici tohumlama | **B:** D1 ≥ %20, oturum ≥ 15 dk, olumlu oy ≥ %85, 2 kişilik oturum payı ≥ %50 (**hedef; varsayım**, ilk hafta verisiyle ayarlanır) |
| 7 | Herkese açık yayın, içerik üretici dalgası | — |
| 8 | 1. haftalık güncelleme + etkinlik | **C (14. gün):** organik ≥1.000 anlık oyuncu ve favori/ziyaret ≥ %0,25 → devam; değilse dur/pivotla |

Kapı eşikleri benim hipotezim; Akım'ın "yeterli talep = ~1.000 oyuncu" tanımıyla uyumlu. Kapıyı geçemezsek en çok 6-7 hf harcamış oluruz.

## 8. Riskler (dürüst)

| Risk | Olasılık/etki | Önlem |
|---|---|---|
| Tür kalabalık, bir gimmick yetmez | orta/yüksek | haftalık gimmick döngüsü, kapı A-B-C ile erken durdurma |
| Fizik/ağ gecikmesi iki oyuncuda bozuk | orta/yüksek | 1. haftada kanıt; gerekirse eş bağını "ipsiz, ortak kontrol"e indirge |
| Eş bulunamıyor → ilk oturum ölür | orta | bot eş + hızlı eşleşme |
| Başarı bir klibe bağlı (şans) | yüksek | birden çok klip anı, çok dilli içerik üretici tohumlaması |
| Para kazanma tahmini bilinmiyor | yüksek | yalnızca ölçülmüş merdiven; kapı B/C verisi |
| Rakip kopya (fikir korumasız) | orta | hız (haftalık güncelleme), eş bağı/koleksiyon (kopyalanması zor) |

**Garanti yok.** Plan, bilinmeyeni (talep, dönüşüm) en ucuza (2 hf, ardından beta) ölçmek ve kapıdan geçmezse durmak üzerine kurulu.

## 9. Ölçüm betiği

`../akim/scripts/roblox_deep.py "oyun adı" ...`: oyuncu, ziyaret/gün, favori oranı, oy, güncelleme, pass fiyatları, rozet (ilerleme) hunisi. Bu tablo, lansmandan sonra kendi oyunumuz için de aynı kıyas olarak kullanılır.
