# TANDEM — hafif prototip yapılandırması (yeni sohbetin başlangıç belgesi)

Sürüm: 2026-10-03 · Durum: **onay bekliyor** (kullanıcı "yeterince iyi" derse yeni sohbette uygulanır).
Bu belge tek başına yeterli olacak şekilde yazıldı. Gerekçeler: [PRODUCT_KARARLAR_tandem.md](PRODUCT_KARARLAR_tandem.md) (D1-D26), kanıt ve pazar: [PRODUCT_PLAN_tandem_coop.md](PRODUCT_PLAN_tandem_coop.md), neden Happy Wheels değil: [CASE_happy_wheels.md](CASE_happy_wheels.md).

## 0. Amaç (şaşırmamak için)

1. **Asıl amaç Akım'ı uçtan uca kanıtlamak:** Akım fırsatı buldu → ürüne çevirdik → ölçtük → sonucu arkadaşlara gösterdik. Oyun bunun kanıtıdır; oyunun parlak olması şart değil, **ölçülmüş** olması şart.
2. Prototip tek soruyu cevaplar: **"İlk 3 dakika eğlenceli mi, bir çift tekrar oynar mı?"** (D16: önce kanıt, sonra yayın.)
3. Garanti yok. En ucuza öğren, kapıdan geçmezse dur (D25).

## 1. Ürün özeti (D1, D10, D11)

- **İsim (çalışma):** TANDEM. **His:** komik kaos, mekanik ağırlıklı iki kişilik oyun; bulmaca yalnızca küçük "ikimiz birlikte" engelleri.
- **Araç:** tekerlekli **küvet** (prototip). İki oyuncu aynı küvete bağlı.
- **Roller (asimetrik):** **Sürücü** = direksiyon + denge; **Yardımcı** = gaz/fren + 1 özel yetenek (ör. fren paraşütü/zıplama). İkisi de her an bir iş yapar; birbirine bağımlıdır. Roller prototipte **sabit** (D19).
- **Komedi kaynağı:** fizik (savrulma, devrilme, ragdoll) + **ses** (D5, D6). Özel animasyon yok; karakterde Roblox varsayılan animasyonları.
- **Gore yok:** çizgi film "ouch", uçan eşyalar. Roblox 13+ uyumu.
- **Görsel stil:** sade, blok/düşük poligon, oyuncak paleti (D7). Modeller Studio'daki yapay zekâ araçlarıyla (`generate_procedural_model`, `generate_mesh`); isteyen Blender'da düzeltir.
- **Çekirdek döngü (3 dk):** başla → engelleri birlikte aş → düşünce kontrol noktasında **2 sn'de yeniden** (yükleme yok) → pist sonu → "bir tur daha".

## 2. Kapsam (D9, D17-D19, D22)

| Var (prototip) | Yok (Kapı A sonrası) |
|---|---|
| 1 araç (küvet) tam fizik; koltuk + yatak yalnızca **görsel/ses varyantı** | Farklı fizikli araçlar, koleksiyon |
| 1 pist (~3 dk, 8-10 elle yapılmış modül) | Rastgele sonsuz pist, günlük/haftalık parkur |
| Sabit roller, lobide seçim/otomatik atama | Rol değiştirme, bağ seviyesi |
| Bot eş + hızlı eşleşme (45 sn) + arkadaş daveti | Gelişmiş eşleşme, sıralama |
| ~20 olay sesi + 2 müzik döngüsü | Çok dilli içerik, fragman |
| Analitik huni (D23) | Para kazanma, pass'ler (merdiven plan §4'te hazır), kodlar, haftalık "komik kural" |
| Mobil dokunmatik + PC | Konsol |

## 3. Zorluk ve bot parametreleri (D2, D20, D21) — *başlangıç değerleri, ilk testte ayarlanır*

```
BOLUM_1_SURE_SN          = 90     # ilk bölüm; ≥%60 çift bitirmeli
BOLUM_1_ENGEL_TURU_MAX   = 2      # ör. rampa + alçak çıkıntı
KONTROL_NOKTASI_ARALIK_SN= 25     # oynanış süresi, kabaca
YENIDEN_DOGMA_SN         = 2
ORTA_ZORLUK_BASLANGIC_SN = 180    # 3. dakikadan sonra: dar köprü, dönen çubuk, rampa
HIZLI_ESLESME_BEKLEME_SN = 12     # sonra bot
BOT_YARDIMCI_HATA_ORANI  = 0.15   # gazı/freni yanlış zamanda kullanma olasılığı (komik ama yenilmez değil)
BOT_SURUCU_GURULTU       = orta   # basit yol izleme + sapma
GERCEK_ES_DEVRALMA       = kontrol noktasında (fizik kopmasın)
```

## 4. Teknik yapılandırma (Windows, yeni ekip)

**Resmî kaynaklar:** [Studio MCP sunucusu](https://create.roblox.com/docs/studio/mcp), [coding harness rehberi](https://create.roblox.com/docs/ai/coding-harness).

**Kurulum (Faz 0, yaklaşık 2-4 sa):**
1. Güncel Roblox Studio + Claude Code kurulu olsun. Studio **açık** olmalı (MCP yalnızca açık Studio'yla çalışır).
2. Studio → **Assistant → … → Manage MCP Servers → "Enable Studio as MCP server"** aç.
3. **Assistant Settings → MCP Servers → Quick connect → Claude Code** aç; **Claude Code'u yeniden başlat**. Yeşil gösterge = bağlı.
   Quick connect yoksa Claude Code ayarına elle: `command: cmd.exe`, `args: ["/c", "%LOCALAPPDATA%\\Roblox\\mcp.bat"]` (sunucu adı `Roblox_Studio`).
4. **Script Sync** (beta) aç: dosya tabanlı çalışma. `ServerScriptService/` sunucu mantığı, `ReplicatedStorage/` ortak modüller, `StarterPlayerScripts/` istemci; klasöre konan `.luau` dosyaları Studio'da script olur. `StarterGui`/`StarterPack` için MCP kullanılır.
5. Çalışan hâlini **git** ile kontrol noktası olarak kaydet (her oturum sonunda).
6. Bir kere yeniden başlatma gerekebilir (Studio ve istemci sırası). Kurulum bitince **"hazırlık testi"**: Claude Code'a "sahnede kırmızı bir küp oluştur, oyunu başlat, ekran görüntüsü al" de.

**MCP'nin verdiği araçlar (özet):** script okuma/düzenleme/arama, `generate_mesh`/`generate_material`/`generate_procedural_model`, `search_asset`/`insert_asset`, `execute_luau` (Edit/Client/Server), `start_stop_play`, `get_console_output`, `screen_capture`, `character_navigation`, `user_keyboard_input`/`user_mouse_input`, `search_game_tree`/`inspect_instance`.
**Güvenlik:** MCP istemcisi açık yerlerinizi okuyup değiştirebilir; yalnızca güvendiğiniz istemciyi bağlayın. Parola/anahtarı sohbete yazmayın.

**Önerilen mimari (HİPOTEZ — Faz 1 "iki oyuncu fizik" deneyiyle doğrulanır):**
- Küvet **tek model**, iki koltuk. Aracın ağ sahipliği **sürücüde**; yardımcı girdisi (gaz/fren/yetenek) `RemoteEvent` ile sunucuya, oradan araç öznitelik (attribute) olarak sürücü istemcisine yayılır; sürücü istemcisi kuvveti uygular. Gecikme testi (iki farklı bölge) Faz 1'in kapı koşuludur.
- **Yedek plan (D25a):** fizik tutarsızsa "ipsiz, ortak kontrol": iki oyuncunun girdisi toplanarak tek araca uygulanır.
- Bitiş süresi/kontrol noktası **sunucuda** doğrulanır (ışınlanma/hız kontrolü).
- Kullanıcı metni yok (yalnızca Roblox filtreli takma ad).

## 5. Plan (saat cinsinden; **tahmin, ölçüm değil**)

K = gerçek saat / tahmin saat. **Faz 0'ın asıl çıktısı K'dir.**

| Faz | İş | Tahmin (kişi-saat, toplam) |
|---|---|---|
| **0 Kurulum + hız ölçümü** | §4 kurulumu; her kişiye 1 eğitim oturumu ("Claude Code'a görev verme"); "ilk iş": küp araç + ileri/geri sürüş + play-test + ekran görüntüsü; boş yeri **özel** yayınla | ≤ 10 |
| **1 Dikey kesit** | küvet+2 koltuk (3-5), sürücü kontrolü (6-10), yardımcı kontrolü (5-8), **iki oyuncu bağlama + ağ + gecikme testi (6-10, en riskli)**, 1 pist/8 modül (5-8), kontrol noktası + anında yeniden (2-3), mobil dokunmatik (3-5) | 30-50 |
| **2 Prototip çekirdeği** | bot eş (6-10), hızlı eşleşme + arkadaş daveti (5-8), 2 görsel varyant (3-5), ses entegrasyonu (4-6), zorluk eğrisi ayarı (4-6), analitik huni (3-5) | 25-40 |
| **3 Kapı A testi** | hazırlık, 3-5 çift × ~20 dk, gözlem notları, karar | 8-12 |
| **Toplam** | | **~73-112 sa** |

Takvim: 25 sa/hafta (yer tutucu) → 3-4,5 hf; K=1,5 ile 4,5-7 hf. **Faz 0 sonunda gerçek hızla yeniden hesaplanır.** K>2 ise kapsam yarıya iner (D25b): önce Faz 1'i bitir, bot/eşleşmeyi sadeleştir.
Ses üretimi (ekip dışı, paralel): ~20 olay sesi + 2 müzik döngüsü, kodu beklemeden yürür.

## 6. Roller (3-4 kişi, D14)

| Rol | Kim | İş |
|---|---|---|
| **Sistem kurucusu / öğretmen** | kullanıcı | Studio+MCP+Claude Code kurulumu, görev dağıtımı, ekibe öğretme, git kontrol noktaları |
| **Ses & müzik** | kullanıcı + tanıdıkları | olay sesleri, 2 müzik döngüsü, karşılaştırmalı dinletme |
| **3D düzenleme** (isteğe bağlı) | gönüllü | Studio'da üretilen modelleri Blender'da düzeltir; zorunlu değil |
| **Test & ölçüm** | 1 kişi | arkadaşları toplar, gözlem formunu doldurur, sonuçları `VAKA_TANDEM.md`'ye yazar |

Çalışma düzeni: aynı yerde aynı anda iki kişi düzenlemesin (çakışma); düzenlemeyi sırayla yapın ya da Roblox'un ortak düzenleme (Team Create) özelliğini Faz 0'da deneyip doğrulayın. Ses ve 3D işi paralel, kod işi sırayla.

## 7. "His" kalite çıtası (Tanım: bitti sayılır)

- **İlk 30 sn:** menüsüz doğrudan araca binme; ilk hareket ≤10 sn; ilk komik an ≤30 sn.
- **Klip ritmi:** her ~20-30 sn'de bir kliplik an (devrilme, uçuş, eşin yanlış düğmesi) ve **her birinin kendi sesi** var.
- **Ses:** çarpma, devrilme, kurtulma, yardımcının yeteneği, kontrol noktası, bitiş; müzik gerginlikte hızlanır, kurtulmada rahatlar.
- **Fizik:** kopma/sıçrama yok; iki oyuncuda da araç davranışı tutarlı (gecikme testi geçti).
- **Mobil:** düşük seviye telefonda ≥30 FPS; dokunmatik kontrol ilk girişte ≤10 sn'de anlaşılır.
- **Kapsam bütünlüğü:** bu listeyi geçmeyen özellik eklenmez.

## 8. Kapı A (D15: küçük örnek, "ilk izlenim + gözlem")

3-5 çift (5-10 arkadaş), her çift ~20 dk. Ölçüm: gözlem formu + Analytics hunisi + isteyenin ekran kaydı.

| Ölçüt | Eşik (hipotez) |
|---|---|
| 1. bölümü bitiren çift | ≥ %60 |
| "Bir tur daha" (kendiliğinden ikinci tur ya da "tekrar oynarım") | çiftlerin ≥ %60'ı |
| Kliplik an | 2 dk'da ≥ 1 (gözlemci sayar) |
| Bot ile tek başına 1. bölümü bitiren | ≥ %50 |
| 3. dk sonrası "çok zor" diyen | < %40 |
| Engelleyici hata/çökme/fizik kopması | 0 |

**Karar:** hepsi geçerse → Kapı B planı (kapalı beta 50-100 kişi; D1 ≥ %20, oturum ≥ 15 dk, olumlu oy ≥ %85, 2 kişilik oturum payı ≥ %50: plan §7). Geçmezse **tek iyileştirme turu (≤15 sa)**, sonra dur/pivot.
**Uyarı:** 3-5 çift **istatistiksel kanıt değildir**; yalnızca büyük sorunları ve "kesinlikle sevmediler" durumunu yakalar. Gerçek kanıt Kapı B ve C'dir.

## 9. Akım yansıması (D26) — ana hedef

- **Vaka zinciri** dosyası `docs/VAKA_TANDEM.md`: (1) Akım'ın gördüğü sinyal (Roblox nabzı: 2 kişilik fizik komedisi), (2) kanıt tablosu, (3) ürün kararı, (4) her kapı sonucu. Akım'ın önerisi doğru mu yanlış mı, **dürüstçe** yazılır.
- **Aynı ölçekle kıyas:** kapı sonrasında `..\akim\.venv\Scripts\python ..\akim\scripts\roblox_deep.py "oyun adı"` ile kendi oyunumuzu rakiplerle aynı tabloda ölçeriz.
- **Arkadaşlar:** Akım'ın arkadaş kanalı (`ntfy:arkadaslar`) yalnızca S/A fırsatları ve günlük panoyu gönderir; kapı sonuçlarını sohbetle/özetle paylaş ([ARKADAS_REHBERI.md](../../akim/docs/ARKADAS_REHBERI.md)). Prototip yayını **herkese açık değildir** (D16).
- **Akım'a dönüş fikri (yapılacak değil, fikir):** vaka sonucu "fırsat işe yaradı/yaramadı" diye kayda geçirilirse Akım'ın puanlaması gerçek sonuçla kalibre edilebilir.

## 10. Faz 0'da doğrulanacaklar (şu an KANITSIZ varsayımlar)

1. Script Sync (beta) bu Studio sürümünde Windows'ta çalışıyor mu; MCP + Claude Code bağlantısı yeşil mi.
   - **MCP + Claude Code bağlantısı: DOĞRULANDI (2026-10-03 ~11:00).** İlk denemede (~10:50) köprü (`StudioMCP.exe`) "bağlı" görünüp **0 araç** verdi ("Timed out waiting for tools to become available": Studio tarafı etkin değildi). Kullanıcı Studio tarafında bağlantıyı yeniden yapınca 28 araç göründü; kesin neden bilinmiyor (anahtar kapalı/uygulanmamış olabilir). `.mcp.json` değiştirilmedi.
   - **Hazırlık testi: DOĞRULANDI.** Kırmızı küp `execute_luau` ile kuruldu, `start_stop_play` ile oyun başladı, `screen_capture` ile küp ve karakter görüntüsü alındı, oyun durduruldu. Klavye girdisi (`user_keyboard_input`) de çalışıyor (W ile karakter ilerledi).
   - **Dikkat (gözlem):** (a) Studio penceresi **küçültülmüşse** `screen_capture` 3D dünyayı çizmiyor (yalnızca arayüz, koyu zemin); pencere açık/görünür olmalı. (b) Play'de karakterin doğması ilk seferde ~30-60 sn sürdü (avatar yüklemesi); önce karakteri bekle. (c) Yer kayıtsız ("Place3", PlaceId 0): Studio'da kaydedilmeli.
   - **Pratik alternatif: DOĞRULANDI (2026-10-03).** Resmî Script Sync beklenmeden repo→Studio tek yönlü eşitleme kuruldu: `tools/sync/sunucu.js` (127.0.0.1:47821) + Studio'da `execute_luau` ile çağrılan yükleyici (`HttpService` gerekir; yayın öncesi kapatılmalı). Kod repoda yazılır, Edit modunda yüklenir (34 dosya, hatasız). Dosyalar `src/{server,shared,client}` → `ServerScriptService/Tandem`, `ReplicatedStorage/Tandem`, `StarterPlayerScripts/Tandem`.
   - **Script Sync: BELİRSİZ (denenmedi).** Bu sürümde altyapı var (kayıtlarda `FileSyncPlaceListener`, ayarlarda `DefaultScriptSyncFileType`), ama `FileSyncService` Luau'dan erişilebilir değil ve etkinleştirme yalnızca Studio arayüzünden yapılıyor (Explorer'da klasör → sağ tık → "Sync to…" → dizin seç; [belge](https://create.roblox.com/docs/scripting/sync)). MCP ile yapılamaz → kullanıcı denemeli. Belgeye göre özniteliği/etiketi olan script'ler senkronlanmaz. Bu arada kod hem repoda (`ServerScriptService/`) hem Studio'da (MCP `multi_edit`) tutuluyor.
2. İki oyuncu aynı araçta: ağ sahipliği + öznitelik yayılımı yaklaşımı yeterince tutarlı mı (Faz 1 deneyi).
   - **Mimari değişti (2026-10-03):** `VehicleSeat` + istemci ağ sahipliği yerine **sunucu-yetkili fizik** seçildi: ışın tabanlı süspansiyon/lastik modeli sunucuda, araç `SetNetworkOwner(nil)`; iki oyuncu yalnızca girdi kanalı gönderir (30 Hz, rol bazlı). Sebep: iki kişi aynı aracı sürdüğü için tek otorite gerekli, hile/tutarsızlık yok. Bedel: sürücü gecikmesi (RTT) doğrudan hisse yansır; araç görseli istemcide yumuşatılır.
   - **Gözlem (tek istemci, Studio):** kuvvet geri beslemeli terimler (sönümleyici, yanal tutunma) açık integrasyonda 40 Hz karede **kararsız** çıktı (gövde yalpa ataleti çok düşük → kare başına işaret değiştiren salınım, zıplama). Örtük (geri Euler) çözüm gerekti (`server/Arac/Atalet.luau`): sonrası 25-60 Hz karede kararlı; dönüş hızı kinematik beklentiyle örtüşüyor.
   - **Durum: BELİRSİZ — iki oyuncu/gecikme testi YAPILMADI.** Eski (VehicleSeat) ön gözlem: yalnızca tek oyunculu, yerel Studio ön gözlemi (2026-10-03, gecikme yok): `VehicleSeat` girdisi (`ThrottleFloat`/`SteerFloat`) sunucuya ulaşıyor; oturan oyuncu aracın ağ sahibi oluyor; sunucunun tekerlek motoruna ve ön eksen yönüne yazdığı değerler sürücüde çalışıyor (ileri/geri/direksiyon, devrilme yok). W+D gibi çapraz tuşlarda iki girdi de 0,7 geliyor (normalizasyon). Gerçek gecikmede tutarlılık kanıtlanmadı.
3. **Ses yükleme** kuralları/kota/denetim süresi (Roblox ses kütüphanesi ya da yükleme) ve müzik/ses hakları.
4. Yalnızca arkadaşlara özel erişim: Roblox'un erişim ayarı (arkadaş/grup izni) yeterli mi, yoksa özel sunucu mu.
5. Analitik: Roblox'un özel olay/huni API'sinin adı ve sınırları (kendi günlüğümüzü buna göre kur).
6. İçerik olgunluk anketi, 13+ uyumu, rapor yolu.
7. Ortak düzenleme (Team Create) bu ekip için gerekli/uygun mu.
8. Hız katsayısı **K** (Faz 0 çıktısı). — **İPTAL (kullanıcı kararı, 2026-10-03):** saat günlüğü/K bırakıldı; plan saat yerine işlevsel kapılarla ilerler.

## 11. Çalışma düzeni (bu klasörde)

- Bu klasör (`tandem/`) oyunun çalışma klasörüdür; `CLAUDE.md` yeni oturumda otomatik okunur. Akım (`..\akim`) yalnızca ölçüm betiği ve arkadaş kanalı için kardeş klasördür.
- Başlangıç sırası: **Faz 0** (§4-§5) → §10 doğrulamaları → Faz 1 → Faz 2 → Kapı A. Her adım kullanıcıyla birlikte yapılır; saatler `docs/SAAT_GUNLUGU.md`'ye yazılır.
- Her kapı sonunda `docs/VAKA_TANDEM.md` güncellenir (kısa, dürüst) ve Akım sohbetine kısa rapor götürülür.
