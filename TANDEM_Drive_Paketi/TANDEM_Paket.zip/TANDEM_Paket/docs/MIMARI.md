# TANDEM — Mimari (kısa harita)

Kod `src/` altında; Studio'ya `tools/sync` ile yüklenir. Eşleme: `src/server` → ServerScriptService/Tandem, `src/shared` → ReplicatedStorage/Tandem, `src/client` → StarterPlayerScripts/Tandem.

## Kurallar (pazarlıksız)
- Dosya ≤ 25 KB. Sıfır sabit: her sayı/metin/ad `shared/Ayar/*` içinde; kodda yalnızca 0/1/2 ve `Cekirdek/Matematik` adlı sabitleri.
- Kimlikler ASCII Türkçe, `--!strict`, yapılandırmalar `Kitaplik.derinDondur`. `Yapilandirma.<Modul>` yapılandırmayı tembel yükler.
- Sunucu yetkilidir: fizik, kapı, süre, ışınlanma. İstemci yalnızca girdi gönderir ve görüntüler.

## Katmanlar
| Klasör | İçerik |
|---|---|
| `shared/Ayar` | Tüm sayılar/metinler: `Genel, Kosu, Arac, Pist, Bot, Girdi, Gorsel, Arayuz, Ayarlar, Profil`, dil paketleri `Dil/*` |
| `shared/Cekirdek` | `Kitaplik, Matematik, Sinyal, Temizlik, Ag` (uzak olaylar), `Dil` (yerelleştirme), `AyarSema` (ayar doğrulama) |
| `server/Kosu` | `KosuYoneticisi` (koşu başlatma/eşleşme), `Kosu` (durum makinesi), `PistInsa` (pisti ayardan kurar) |
| `server/Arac` | `AracInsa`, `AracFizik` (tekerlek başına ışın + örtük çözücü), `Atalet`, `Yolcu` |
| `server/Bot`, `server/Servis` | Bot beyni/karakteri; `GirdiAlici`, `Ortam`, `Profil` (DataStore) |
| `client/Servis` | `Girdi` (klavye/gamepad/dokunmatik → paket), `Kamera`, `Durum` (sunucu durumu), `Olay` (oyun olayı veri yolu), `Eszaman` (fiziğe bağlı efekti görünen araçla eşler), `Ses`, `GorselEfekt`, `Eslesme` (eş arama durumu), `Ayarlar` (ayar deposu) |
| `client/Arayuz` | `Arayuz` (kök), `Hud`, `Duyuru`, `Sonuc`, `SonucEs` (eş bul/davet düğmeleri), `Geribildirim` (kenar parlaması/flaş), `Etiket` (SEN/BOT), `Istem` ("şu tuşa bas" ipucu), `AyarPaneli`, `Dokunmatik`, `Ipucu`, `Yapi` (yapı taşları) |

## Koşu durum makinesi
`Hazirlik → GeriSayim (giriş çekimi + 3-2-1) → Surus → Bitti`. Her kapıda roller yer değiştirir (Sürücü ↔ Yardımcı). Sunucu `Durum` tablosunu yayınlar (`Sira` artan sayıdır; istemci sırası bozuk gelenleri atar).

## İstemci olay yolu (`client/Servis/Olay`)
Durum farkları ve sunucu `Efekt` olayı **tek yerde** olaylara çevrilir: `RolDegisti, KapiGecildi, Sifirlandi, GeriSayimBasladi, Rakam, SurusBasladi, Basla, Bitti, Efekt, Inis, OrtakAyrildi`. Arayüz (`Arayuz.olaylariBagla`) ve `Ses` buna abone olur; yeni bir parça (görsel efekt, analitik) kendi fark hesabını yapmaz, `Olay.<Ad>:Connect` yazar. `Efekt` yalnızca o koşudaki insanlara gider (`Kosu.efekt`). **Görsel eşzamanlama:** sunucu fiziği istemcide ~0,2 sn geç görünür, uzak olay ise hemen gelir. Bu yüzden `Kosu.efekt` gövdenin konumunu da yollar; `Olay`, `Ayar/Genel.Eszaman.Turler`'deki efektleri `Eszaman.konumda` ile görünen gövde o konuma varınca bırakır; kapı/rol duyurusu ve `Inis` `Eszaman.ertele` ile ölçülen gecikme kadar bekletilir. Yeni fiziğe bağlı efekt türü = `Eszaman.Turler`'e satır (Konum ya da Isinlama kipi).

## Ses (`Ayar/Ses` + `client/Servis/Ses`)
Gruplar ayar kaydırgaçlarına bağlıdır (Ana ⊃ Motor, Efekt). Her şey veridir: `Sesler` (kaynak, düzey, perde, uzamsal), `Efektler` (sunucu efekt türü → şiddet seviyeleri → sesler), `Olaylar` (istemci olayı → sesler), `Donguler` (motor/rüzgâr: hız ve gaza göre perde/düzey), `Inis` (havada kalma süresine göre iniş sesi). **Ses değiştirmek = `Kaynak` satırını değiştirmek.** Kaynaklar geçici yer tutucudur (bkz. `VAKA_TANDEM.md` M3 notu).

## Görsel geri bildirim (`Ayar/Geribildirim`)
Oyuncu yazı okumadan bir şeyin değiştiğini görmeli: `Geribildirim` ekran kenarında rol renginde kalıcı parlama + olay darbeleri (`Olay` sinyallerine abone), `Hud` basılan tuşun hapını yakar, `Etiket` araçtaki kendi/eş koltuğunu işaretler, `Istem` ana tuşa basılmıyorsa büyük ipucu gösterir. Hepsi `Ayar/Geribildirim`'den ayarlanır. **Bot davranışı** `Ayar/Bot.Insan` (tepki gecikmesi, dalgınlık, kişilik) ile `server/Bot/BotBeyni`'dedir.

## Zorluk (`Ayar/Bolge`, `Ayar/Tehlike`, `Kosu.Zorluk`)
**Bölge:** pist bölümüne `Bolge = "Ad"` yazılır; `PistInsa` yol plakasına renk/malzeme + `TandemBolge` özniteliği verir, `AracFizik.bolgeleriUygula` her temas eden tekerleğin plakasını okuyup tutunma çarpanını (`teker.TutunmaOrani`) yazar, sönüm/itme/yan kuvveti gövdeye tekerlek oranında uygular; baskın bölge araçta `Zemin` özniteliği olur (istemci `Gosterge` uyarı gösterir), `Efekt` alanı girişte bir kez tetiklenir. **Tehlike:** bölüme `Tehlikeler = {{Tur, Z, ...}}`; `TehlikeInsa` kurar (çubuk = `PrismaticConstraint` servo, sunucu saatiyle sürülür; havlu = `Engel` grubunda sabit blok, tekerlek ışını görmez; şişe = ağ sahibi sunucu olan serbest silindirler) ve `yenidenBaslat`'ta başa alır. **Kademe:** `Kosu.kapiGec` → `AracFizik.zorlukAyarla(kapi+1)`; ceza `Kurtarma.CezaSn`. Bot, pist kayıtlarını (`Pist.Tehlikeler`) okuyarak zıplar, kaçar, yavaşlar.

## Araç görünümü ve yapay zekâ modelleri (`Ayar/Mesh`, `Arac/MeshSablon`, `Arac/Gorunum`)
Fizik gövdesi görünmez kutudur (`Ayar/Arac.Govde`); görünüm yalnızca süstür. Görünüm parçası tanımında `Mesh = "Ad"` varsa `Gorunum.parca` o modelin şablonunu kopyalar: `Boyut` = hedef ölçü (mesh buna gerilir), `Donus` modeli araç eksenine çevirir, `Boya` dokuyu boyar. Şablonlar `MeshSablon.hazirla()` ile bir kez `InsertService:CreateMeshPartAsync` (kimlik **string**, `Content` değil) ile yüklenir; sunucuda `Kosu.kur` içinde, istemcide `AracGorsel.aracKur` içinde beklenir. Yüklenmeyen model için aynı tanımdan düz parça (Boyut + Renk) kurulur. Yeni model: `generate_mesh` → `Ayar/Mesh.Modeller`'e kimlik+doku → `Ayar/Arac.Gorunum`'a tanım. Modelin kendi ekseni/ölçüsü `Ayar/Mesh` başındaki yorumdadır; mesh pivotu sınırlayıcı kutunun merkezidir. `MeshPart.MeshId` çalışma anında yazılamaz, bu yüzden şablon yolu şart. `EditableMesh` (geometri okuma) deneyim güvenlik ayarında kapalı.

## Hazır çağrılar (`Ayar/Cagri`, `Kosu.cagri`, `BotBeyni.cagri`)
İstemci `Girdi.cagriYap(sıra)` → `Eylem("Cagri", sıra)` (tuş: `Girdi.Klavye.Cagri1..3`, dokunmatik: `Dokunmatik` sağ-orta sütun). Sunucu `Kosu.cagri`: yalnızca `Surus` fazında, sayı olmayan/olmayan sıra reddedilir, oyuncu başına `SogumaSn`; çağıranın **o anki rolünün** listesinden çağrıyı alır ve koşudaki insanlara `Cagri` olayı yollar `(koltuk, sıra, rol)` (koltuk = çağıranın koltuğu; rol değişse de oyuncu koltuğunda kalır). İstemci `Olay.Cagri` (herkes: `Etiket` balonu) ve `Olay.CagriAlindi` (yalnızca eş: `Geribildirim` darbesi + `Ses`). Bot eş çağrının `Bot` alanına göre tepki verir (`Zipla/Hiz/Yon/Korna`, bkz. `Ayar/Cagri` başı). Yeni çağrı = `Ayar/Cagri.Roller` listesine satır + `Ayar/Dil/*` metinleri (3'ten fazlaysa `Ayar/Girdi`'ye yeni `CagriN` tuşu).

## Eş bulma (`KosuYoneticisi` + `Kosu`)
Bir koşuda 1 ya da 2 insan olur; eksik rolü bot oynar. `Kosu.new(yer, {oyuncular}, klasor, hazirlar)`: ilk insan `Kosu.VarsayilanRol`, ikincisi diğer rolü alır. Eş bulma kuralları sunucudadır: yalnızca koşusu `Bitti` olan ve eşi bot olan oyuncu kuyruğa girer (`esBulabilir`); arkadaşlar önceliklidir (`IsFriendsWith`); `Eslesme.BeklemeSn` dolarsa `BotaDondu` + botla yeniden başlar. Eşleşince iki oyuncu eski koşularından çıkar (`oyuncuAyrildi`; insanı kalmayan koşu kapanır) ve yeni bir çift koşusu açılır. Çift koşuda biri ayrılırsa yerine bot oturur; "Tekrar" için ikisi hazır olmalı ya da `TekrarBeklemeSn` dolmalı. İstemci tarafı: `Servis/Eslesme` (durum + istekler), `Arayuz/SonucEs` (düğmeler, durum satırı). **İki insanlı yol henüz denenmedi (bkz. VAKA M4a).**

## Uzak olaylar (`Genel.Ag`)
`Girdi` (güvenilmez, 30 Hz), `Durum`, `Efekt`, `Eylem` (Sifirla/Tekrar/EsBul/EsIptal), `Eslesme` (sunucu → istemci: Araniyor/Bulundu/BotaDondu/Iptal), `Hazir`, `Profil` (RemoteFunction: ayarlar + rekorlar), `AyarKaydet` (hız sınırlı).

## Nasıl eklenir
- **Dil:** `shared/Ayar/Dil/` altına `{ Ad, Kod, Sira, Metin = {...} }` döndüren modül ekle; ayar panelinde kendiliğinden görünür. Eksik anahtar yedek dile (`En`), o da yoksa anahtarın kendisine düşer.
- **Ayar:** `Ayarlar.Kimlikler` + `Ayarlar.Tanimlar` listesine bir satır ekle (Kaydirgac/Anahtar/Secim/Dil); panel, doğrulama ve kalıcılık kendiliğinden gelir. Değeri okuyan kod `Ayarlar.al(kimlik)` kullanır.
- **Dokunmatik düğme:** `Arayuz.Dokunmatik.Yerlesim.<Rol>.<Sol|Sag>.Dugmeler` listesine `{ Kanal, Deger, Birak, Simge }` ekle.
- **Ses:** `Ayar/Ses.Sesler` altına bir giriş ekle, sonra `Efektler`/`Olaylar` listesinde ona bağla. Kod değişmez.
- **Pist:** `Ayar/Pist.luau` bölüm listesi (düz, viraj, rampa, boşluk, engebe, kontrol noktası); `PistInsa` kurar.

## Ayarlar ve kalıcılık
İstemci `Servis/Ayarlar` varsayılanlarla açılır, `Profil` uzak fonksiyonundan gelen değerleri uygular; değişiklik 0,4 sn gecikmeyle `AyarKaydet`'e gider. Sunucu `Servis/Profil` doğrular ve DataStore'a debounce'lu yazar (yeniden deneme, `BindToClose`, yükleme başarısızsa yazmaz). Yayınlanmamış yerde DataStore yok → oturum içi bellek (panel "yalnızca bu oturumda" der). **Gerçek DataStore yazma/okuma henüz doğrulanmadı.**

## Geliştirme kancaları (yayından önce kapat)
`Kosu.Deneme.Etkin / Otopilot / AvatarYukle`, `Arayuz.Deneme.ZorlaCihaz` (false olmalı), HttpService.HttpEnabled.

## Geliştirme döngüsü
Play'i durdur → Studio (Edit) içinde `loadstring(HttpService:GetAsync(adres.."/yukleyici"))()(adres)` → Play. `node tools/sync/sunucu.js` 127.0.0.1:47821'de çalışmalı.
