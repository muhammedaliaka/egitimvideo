# Vaka: Happy Wheels — yapmaya değer mi? (2026-10-03)

**Karar: DEĞMEZ.** Happy Wheels'i ya da "Happy Wheels benzeri" bir oyunu Roblox'ta yapmayın. Aynı türün başka bir biçimi (aşağıda "Ne yapılır") değer olabilir.

Soru: Steam'e 21 Eylül 2026'da gelen Happy Wheels (3.465 yorum, %95 olumlu, ~1.200-1.600 anlık oyuncu, $4,99) sıralamada A 46 çıkıyordu. Roblox'ta karşılığı yok, kısa sürede yapılır mı, dikkat çeker mi?

## 1. Talep nereden geliyor? (mekanikten değil, marka ve nostaljiden)

- Steam sayfası: "**5 milyondan fazla kullanıcı yapımı bölüm**", bölüm editörü, bölüm tarayıcısı, eski hesabı Steam'e bağlama. Ürün = 15 yıllık içerik kütüphanesi + marka.
- 100 yorum örneği: ortanca oynama süresi **3 saat**; "2012'ye geri döndüm", "Jim'e destek", "5 € verip ücretsiz oyun almak" (oyun yıllarca tarayıcıda ücretsizdi). Yorumlarda nostalji ifadesi en baskın tema.
- YouTube: 22 kanal / 24 video (en büyüğü 31 milyon abone) hepsi "Steam'e geldi / 10 yıl sonra oynadım" çerçevesinde. Bu bir **geri dönüş haberi**; mekaniğe duyulan yeni ilgi değil.
- Anlık oyuncu 3 gündür 1.2-1.6 bin'de yatay (ilk 9 günü ölçemedik). Nostalji örneklemi gibi: yüksek merak, kısa oturum.

Sonuç: Steam sinyali Roblox'a **aktarılmaz**. Marka adı kullanılamaz (Jim Bonacci / Fancy Force), adsız bir kopyada nostalji kancası yoktur.

## 2. Roblox'ta neden karşılığı yok? (boşluk değil, işaret)

- "Happy Wheels" adlı/benzeri oyun yok, ama 15 yıldır kimse yapmamış olması fırsat kanıtı değil: **çekirdek (uzuv kopması/gore) Roblox'ta yasak**.
  Roblox Topluluk Standartları: 13+ etiketinde gerçekçi olmayan kan serbest ama **uzuv kopması yasak**; uzuv kopmasına yalnızca 17+ (18 yaşını doğrulamış oyuncular) izin var. Roblox kitlesinin büyük kısmı bunun dışında.
- En yakın Roblox türleri (canlı ölçüm, 2026-10-03): ragdoll oyunlarının en iyisi ~2.000 oyuncu (Ragdoll Engine, 6 yıllık), çoğu 1.000-1.500; çarpışma fiziği (Car Crushers 2) ~2.400. **Tavan düşük.**
- Tutan tür: "araçlı engel parkuru" (obby + araç). Obby But You're on a Scooter ~7.400 oyuncu (418 gün, 116 M ziyaret), Kart of Hell ~5.900, **Grapple Cart Obby ~11.000 (37 günlük)**, Drive A Kukirin ~11.400 (58 günlük).

## 3. Yapım süresi (yapay zekayla, 7 kişilik ekip)

| Kalem | Hafta |
|---|---|
| Ragdoll araç-karakter fiziği (5-6 karakter, eklemler, ayarlama) | 3-5 |
| Oyun içi bölüm editörü + kaydetme/yükleme (DataStore) | 5-8 |
| Bölüm tarayıcısı, oylama, paylaşım + Roblox moderasyon/raporlama | 3-5 |
| Başlangıç içeriği (30-50 bölüm; 5 milyonluk kütüphane olmadan soğuk başlangıç) | 2-4 |
| 13+ uyumu (gore'suz sürüm, sansür/geri bildirim) | 1-2 |
| **Toplam** | **~14-24 hf** (hedef 8,7 hf, 1,25 tolerans = 10,9) |

Editörsüz "lite" sürüm ~6-8 hf, ama o zaman ürün sığ bir 20 bölümlük oyun: Happy Wheels'in elde tutma motoru (kullanıcı bölümleri) yok. Trend penceresi (~16 hf) süreyi karşılamıyor (OWF ~1,4 → sarı/turuncu); soğuk başlangıçlı UGC ürünleri zaten Roblox'ta zor tutuyor (oyuncu oynamak ister, bölüm yapmak isteyenler küçük bir azınlık).

## 4. Değer / dikkat

- **Dikkat çeker mi?** Steam'de evet (marka). Roblox'ta hayır: nostalji kitlesi (25-35 yaş) ile Roblox ana kitlesi (9-16) örtüşmüyor; adsız kopyada kanca yok.
- **Değer mi?** Tam kopya 14-24 hf, marka yok, çekirdek (gore) yasak, tür tavanı ~2 bin → **değmez**.

## 5. Ne yapılır (alternatif, değerli olan)

Aynı fizik/komik-kaza hissini **Roblox'un kazanan biçimine** çevirin: *"Obby ama sen ... üstündesin"* tarzı araçlı engel parkuru, **gore yok** (çizgi film "ouch"), 1-2 kişilik, bölüm editörü **yok**, haftalık yeni bölüm. ~5-7 hf (araç fiziği + 20-30 bölüm + sıralama/ödül döngüsü). Gerekçe: bu tür Roblox'ta kanıtlanmış (yukarıdaki rakamlar), yeni oyunlar 1-2 ayda 10 bin+ oyuncuya çıkabiliyor. **Mutlaka bir "gimmick" gerekir** (kanca, ters yerçekimi, çift kişilik bağlı araç gibi); gimmick'siz kopyalar 1-2 bin'de kalıyor.
Bu Happy Wheels kopyası değil, Roblox yerlisi bir tür: Akım'ın Roblox nabzı (`analysis/pulse.py`) bunu kendi başına yakalamalı.

## 6. Ne zaman yeniden bakılır?

- Happy Wheels 30. günde hâlâ ≥1.500 anlık oyuncuysa (nostaljiyle açıklanamayacak kadar kalıcı) ve oyuncu yorumlarında "bölüm yapıyorum/oynuyorum" teması baskınsa.
- Roblox 17+ (Restricted) kitlesi büyük bir ölçekte kanıtlanırsa (bugün ölçemiyoruz).
- Roblox'ta gore'suz bir ragdoll-araç oyunu >5.000 oyuncuya ulaşırsa (tür tavanı değişmiş demektir).

## 7. Sistemde yapılan düzeltmeler (Akım bu oyunu neden A 46 verdi?)

| Eksik | Düzeltme |
|---|---|
| Yapım tahmini 3,7 hf: `Level Editor` etiketi hiç puan getirmiyordu | "Level Editor" + "Sandbox" birlikte = topluluk içeriği ürünü: +24 puan (~11,5 hf), hedef süreyi aşınca en çok B (`feasibility.UGC_PLATFORM_*`) |
| Yaşam döngüsü "yeni çıkış" (marka bağımlılığı 0,1) | "Nostalgia" + "Classic" etiketleri birlikte ve ≤180 gün: `relaunch` (marka bağımlılığı 0,6, en çok B) (`lifecycle._REVIVAL_TAGS`) |
| Sonuç | Happy Wheels A 46 → C 23; diğer oyunlar değişmedi (canlı veri kopyası) |

Sınırlar: ikinci kural yalnızca iki etiket birlikte olunca çalışır (canlı veride yalnızca Happy Wheels'te çıktı); etiketsiz bir geri dönüş yakalanmaz. Editör kuralı, "Level Editor" + "Sandbox" etiketlerine bağlı. Süre tablosu bir uzman tahminidir, ölçüm değil.
