# TANDEM ekip rehberi (insanlar için)

Bu rehber, projede yapay zekâ (Claude vb.) ile çalışacak herkes içindir. Roblox bilmen gerekmez; yapay zekâya **ne istediğini net söylemen** yeter.

## 1) Başlamadan (5 dakika)
1. Zip'i bir klasöre çıkar. Oyunu denemek için `Tandem.rbxl` dosyasına çift tıkla, **F5**'e bas.
2. Yapay zekâ ile çalışmak için **zip'ten çıkan klasörü** kullandığın araçta aç (Claude Code, Codex, Antigravity, Kiro, VS Code…). Hangi aracın hangi kural dosyasını kendiliğinden okuduğu araca göre değişir (tablo: `docs/VIDEO_FOYU.md`); klasördeki `AGENTS.md`, `CLAUDE.md` ve `00_YAPAY_ZEKA_ONCE_OKU.md` hepsi aynı emri verir: önce `.claude/skills/tandem-ekip/SKILL.md` yönergesini oku. Aracın dosya okuyamıyorsa (ör. tarayıcıdaki sohbet): `00_YAPAY_ZEKA_ONCE_OKU.md` ve `SKILL.md` içeriğini sohbete yapıştır.
3. **Yüklendiğini kontrol et:** yapay zekânın ilk yanıtı `TANDEM yönergesi yüklendi.` diye başlamalı. Başlamıyorsa aşağıdaki "İlk mesaj" kalıbını yapıştır.
4. Studio'yu yapay zekâya bağlamak istersen rehber videosundaki adımlara bak. Bağlantı olmadan da yapay zekâ kodu değiştirebilir; sen `Tandem.rbxl`'yi yeniden üretip denersin (aşağıda).

### İlk mesaj kalıbı (yönergeyi okumuyorsa yapıştır)
```
Bu klasör TANDEM projesi. İş yapmadan önce sırayla şunları OKU ve uygula:
1) .claude/skills/tandem-ekip/SKILL.md (zorunlu çalışma kuralların)
2) docs/MIMARI.md ve docs/PROTOTIP_TANDEM_YAPILANDIRMA.md
3) docs/VAKA_TANDEM.md ve docs/EKIP_GUNLUGU.md (ne yapıldı, ne açık)
Yanıtına "TANDEM yönergesi yüklendi." diyerek başla. Sade Türkçe yaz.
Doğrulamadığın hiçbir şeyi kesin söyleme; yaptığın her değişikliği çalıştırıp doğrula ve sonucu dürüstçe raporla.
Sonra bana bugün ne yapabileceğimizi 3 öneriyle anlat.
```

## 2) İyi istek nasıl yazılır
Formül: **Hedef + Nerede + Nasıl anlayacağız + Sınır**.

| Zayıf | Güçlü |
|---|---|
| "Oyunu daha eğlenceli yap" | "İlk dakikada oyuncu en az bir kez gülsün. Pistin ilk bölümüne, doğru hızla gelene sıçrama hissi veren bir rampa ekle. Bitti dediğimizde: otopilot turunda rampa görünür ve araç düşmeden geçer. Araç fiziğine dokunma." |
| "Ses ekle" | "Çarpma sesini ayarlarına ekle: `Ayar/Ses`'e yeni bir giriş aç, şu dosyayı kaynak yap (kimliği ben vereceğim), çarpma efektine bağla. Kod değişmesin, yalnızca ayar değişsin." |
| "Bug var düzelt" | "Küvet ikinci kapıda bazen havada takılıyor. Önce nedenini bulmak için iki olası sebep yaz, ölç, sonra düzelt. Düzeltince otopilot turu 4 kapıdan geçsin." |

Her istekte şunları iste:
- **"Önce planı söyle, onayımı bekle."** (büyük işlerde)
- **"Doğruladığını göster."** (çalıştırdığı komut ve gördüğü sonuç)
- **"Denemediğini açıkça yaz."**

## 3) Yapay zekâ yanlış yaparsa
- "Bunu **çalıştırıp** doğruladın mı, yoksa tahmin mi?" 
- "Bu dosya/işlev gerçekten var mı? Önce `Grep` ile ara, sonra konuş."
- "İki olası neden yaz, hangisini nasıl ölçerek ayırdığını göster."
- "Yönergeyi (SKILL.md) tekrar oku ve hangi kuralı çiğnediğini söyle."
- Düzelmiyorsa yeni bir sohbet aç, "İlk mesaj" kalıbını yapıştır ve `docs/EKIP_GUNLUGU.md`'yi okumasını söyle.

## 4) Örnek görevler (hepsi serbest, ek özellik de eklenebilir)
- Yeni dil ekle (`Ayar/Dil/` altına bir dosya; ayar panelinde kendiliğinden görünür).
- Yeni hazır çağrı ("Zıpla!", "Yavaşla!") ekle (`Ayar/Cagri`).
- Pist bölümü / engel / zemin türü ekle (`Ayar/Pist`, `Ayar/Bolge`, `Ayar/Tehlike`).
- Ses yer tutucularını gerçek seslerle değiştir (yalnızca `Ayar/Ses` içindeki `Kaynak` satırları).
- Bot eşin davranışını daha komik/insansı yap (`Ayar/Bot`).
- Yeni görsel model (yapay zekâ `generate_mesh` ile üretir → `Ayar/Mesh`).
- Arayüz ya da dokunmatik düğme düzeni.

## 5) Ekip kuralları (çakışma olmasın)
- **Aynı dosyayı iki kişi aynı anda değiştirmesin.** İşe başlamadan `docs/EKIP_GUNLUGU.md` "Kilitler" tablosuna kendi satırını yaz (kim, hangi dosyalar); işin bitince sil.
- Herkes kendi kopyasında çalışır. İş bitince yapay zekâdan **değişen dosyaların listesini** ve kısa açıklamayı iste; bunu **birleştiriciye** (ekibin seçtiği kişi) gönder, o birleştirir ve yeni paketi dağıtır. Roller ve kimin neyi çözdüğü: `docs/DEVIR_REHBERI.md`.
- Yapay zekâ klasör git deposu değilse yerel `git init` + ilk commit önerebilir (yayına etkisi yoktur, farkları görmeyi kolaylaştırır).
- **Yayınlama (Publish), oyunu herkese açma, davet göndermek yalnızca proje yöneticisinin işidir.**
- Parola, anahtar, token'ı yapay zekâya yazma, dosyaya koyma.

## 6) Değişiklik sonrası denemek
1. Yapay zekâ kodu `src` içinde değiştirir ve `node tools/denetim/denetim.js` çalıştırır (0 ihlal şart; Node gerekir).
2. Studio bağlıysa yapay zekâ `tools/sync` ile yükler ve Play'de dener.
3. Studio bağlı değilse: [Rojo](https://rojo.space) ile `rojo build default.project.json -o Tandem.rbxl` çalıştır (yapay zekâ komutu verir) ve `Tandem.rbxl`'yi aç, F5.
4. İki kişilikli deneme: Studio'da **Test → Clients and Servers**, Players = 2, **Start**.
