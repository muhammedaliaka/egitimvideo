# Video föyü: her videoda ne yapacaksın

Videoyu izledikten sonra buraya gel. Her bölüm **yapılacak eylemleri sırayla** yazar; bir şeyi kendin çıkarman gerekmez. Her bölümde dört kutu var:
**Ne yapacaksın** (adımlar) · **Yapıştır** (olduğu gibi kopyala) · **Ne görmelisin** (bitti ölçütü) · **Takılırsan**.

Ekip farklı (çoğunlukla ücretsiz) yapay zekâ araçları kullanıyor, bu yüzden adımlar **araçtan bağımsız** yazıldı. Yalnızca Claude Code'a özel yerler **[Claude Code]** etiketli.

Hepsi için ortak hazırlık (1 dk):
1. Aracında **TANDEM klasörünü aç** (zip'i çıkardığın klasör). Yeni bir sohbet/oturum başlat.
2. Araç dosya okuyabiliyorsa ilk mesaj olarak şunu yapıştır:
```
00_YAPAY_ZEKA_ONCE_OKU.md dosyasını oku ve oradaki adımları uygula.
```
3. Cevabın ilk satırı `TANDEM yönergesi yüklendi.` olmalı. Değilse yönerge yüklenmemiştir: aynı mesajı tekrar yaz.
4. Araç dosya okuyamıyorsa (ör. tarayıcıdaki sohbet): `00_YAPAY_ZEKA_ONCE_OKU.md` ve `.claude/skills/tandem-ekip/SKILL.md` içeriğini sohbete yapıştır.

Hangi araç hangi talimat dosyasını kendiliğinden okur (resmî belgelerden, **bu pakette denenmedi**; en güvenli yol yukarıdaki 2. adım):
| Araç | Dosya | Kanıt |
|---|---|---|
| Codex (ChatGPT) | `AGENTS.md` | Belgeye göre: developers.openai.com/codex/guides/agents-md |
| VS Code (Copilot) | `.github/copilot-instructions.md` | Belgeye göre: code.visualstudio.com/docs/copilot/copilot-customization (pakette bu dosya yok) |
| Kiro | `.kiro/steering/*.md` | Belgeye göre: kiro.dev/docs/steering (sayfada "AGENTS.md" başlığı var, ayrıntısı okunmadı) |
| Antigravity | `GEMINI.md`, `AGENTS.md`, `.agent/rules/` | Yalnızca üçüncü taraf sitede yazıyor; resmî kaynakta doğrulanmadı |
| Claude Code | `CLAUDE.md` | Doğrulandı (bu pakette) |
Pakette `AGENTS.md` ve `00_YAPAY_ZEKA_ONCE_OKU.md` hazır gelir.

Etiketler: **[BİRLİKTE]** = proje sahibiyle canlı yaptığımız videolar (3, 4, 5). Sohbete "Föy 5'i birlikte yapalım" yazman yeter, adımları o an yürütürüz. Aynı bölümü sonra tek başına da tekrarlayabilirsin.

---

## Video 1 · Yapay zekâ nerede yanılır (10 dk)
**Amaç:** uydurmayı kendi gözünle görmek ve "nasıl doğruladın?" demeyi alışkanlık yapmak.

**Ne yapacaksın**
1. Aşağıdaki soruyu sor. Bu ayar projede **yok**, bilerek uydurduk.
2. Cevabı oku: "bulamadım, yok" demesi **iyi** sonuç. Bir açıklama uydurması, videodaki "halüsinasyon"un kendisi.
3. Her iki durumda da şunu sor: "Bunu nasıl doğruladın? Çalıştırdığın aramayı göster."
4. Gerçek bir ayarla dene (aşağıdaki ikinci mesaj) ve cevabın etiketli geldiğine bak.

**Yapıştır (1)**
```
src ve docs içinde Kosu.Deneme.GizliMod ayarı var. Ne işe yarar, hangi dosyada?
```
**Yapıştır (2)**
```
Her cevabında kanıtını etiketle: Doğrulandı / Belgeye göre / Tahmin.
Kosu.Deneme.Otopilot ne işe yarar? Hangi dosyada?
```
**Ne görmelisin:** (1) için "yok" ya da uydurma + senin yakaladığın fark; (2) için `src/shared/Ayar/Kosu.luau` dosyası ve "Doğrulandı" etiketi.
**Takılırsan:** Model her seferinde aynı davranmaz. Amaç tek bir sonuç değil, "ne zaman doğrulatmalıyım" hissi.

---

## Video 2 · Doğru düşündürmek (15 dk)
**Amaç:** belirsiz isteği, 4 parçalı iyi isteğe çevirip farkı görmek. **Hiçbir dosya değişmez** (ikisinde de "değiştirme" diyoruz).

**Ne yapacaksın**
1. Önce kötü isteği yapıştır. Cevaptaki **soruları** oku (anlamadığı yerler).
2. Sonra aynı isteği 4 parçalı yaz (hedef · bitti ölçütü · sınır · önce plan).
3. İki cevabı yan yana karşılaştır: hangisi daha net, hangisinde sormak zorunda kaldı?
4. Planın altına 4 sorudan ikisini sırayla yapıştır.

**Yapıştır (kötü istek)**
```
Araç çok kayıyor, düzelt. (Hiçbir dosyayı değiştirme; yalnızca anladığını ve sorularını yaz.)
```
**Yapıştır (iyi istek)**
```
Hedef: Araç virajda şimdikinden daha az kaysın.
Bitti ölçütü: Studio'da otopilotla bir tur koştur; kaymayı önce ve sonra ölç, iki sayıyı yaz.
Sınır: Yalnızca src/shared/Ayar/Arac.luau içindeki sayılar; başka dosyaya dokunma.
Önce planını yaz, onayımı bekle. Hiçbir dosyayı değiştirme.
```
**Yapıştır (4 sorudan)**
```
Neyi doğrulamadın?
```
```
En emin olmadığın yer neresi?
```
**Ne görmelisin:** iyi isteğe gelen plan somut (dosya adı, ölçüm adımı); kötüye gelen soru listesi. Planı **uygulatma**; bu föy yalnızca alıştırma.
**Takılırsan:** plan çok uzunsa "5 maddeye indir" de.

---

## Video 3 · Güvenlik skill'i, canlı [BİRLİKTE] (20 dk)
**Amaç:** gerçek koda güvenlik skill'i çalıştırıp bulguyu **kendin doğrulamak**. (Yalnızca kendi projemiz.)

Sunucunun istemciden veri aldığı üç yer (RemoteEvent) var:
- `src/server/Kosu/KosuYoneticisi.luau:224` (eylem)
- `src/server/Servis/GirdiAlici.luau:62` (girdi)
- `src/server/Servis/Profil.luau:186` (ayar kaydet)

**Ne yapacaksın**
1. Aşağıdaki isteği yapıştır (rapor ister, dosya değiştirtmez).
2. Gelen **her bulgu** için: bulgudaki satırı kendin aç; gerçekten öyle mi? Skill yanılabilir.
3. Bir tablo tut: bulgu · dosya:satır · gerçek mi (evet / hayır / olası) · karar.
4. Gerçek çıkanı düzeltmek için **ayrı bir istek** yaz (video 2'deki 4 parçalı kalıp), sonra `node tools/denetim/denetim.js` (0 ihlal).

**Yapıştır**
```
security-review skill'ini kullan. src/server altındaki RemoteEvent işleyicilerini
(KosuYoneticisi, GirdiAlici, Profil) incele. Hiçbir dosyayı değiştirme, yalnızca rapor yaz.
Her bulgu için: dosya:satır, nasıl sömürülür, nasıl düzeltilir.
Emin olmadıklarını "olası" diye işaretle. Neye bakmadığını da yaz.
```
**[Claude Code değilsen]** `security-review` skill'i yoktur; aynı kontrolü bu metinle yaptır:
```
src/server altındaki RemoteEvent işleyicilerini (KosuYoneticisi, GirdiAlici, Profil) incele.
Hiçbir dosyayı değiştirme, yalnızca rapor yaz. Her işleyici için kontrol et:
gelen değerin türü, aralığı ve sıklığı doğrulanıyor mu; gönderenin yetkisi denetleniyor mu;
karar (süre, ödül, ışınlanma, bitiş) sunucuda mı veriliyor.
Her bulgu için: dosya:satır, nasıl sömürülür, nasıl düzeltilir.
Emin olmadıklarını "olası" diye işaretle. Neye bakmadığını da yaz.
```
**Ne görmelisin:** doldurulmuş bulgu tablosu. "Bulgu yok" çıkarsa bu "güvenli" demek değil: "hangi kontrolleri yaptın, neye bakmadın?" diye sor.
**Takılırsan:** skill bulunamazsa "Hangi güvenlik skill'leri yüklü?" diye sor; yoksa `security-reviewer` ajanıyla aynı isteği dene.

---

## Video 4 · Video düzenleme, canlı [BİRLİKTE] (25 dk)
**Amaç:** kendi ekran kaydından, yapay zekâyla düzenlenmiş altyazılı video çıkarmak.

**Önce kaydı al (3 dk)**
1. Studio'yu aç, `Win`+`Alt`+`R` ile kaydı başlat, Play'e bas, bir tur sür, `Win`+`Alt`+`R` ile durdur. (Xbox Game Bar yalnızca açık pencereyi kaydeder; bu bilgisayarda denenmedi. Olmazsa OBS.) Kayıt `Videolar\Captures` klasörüne düşer.
2. Kayıtta e-posta, hesap adı, parola görünüyor mu? Görünüyorsa yeniden kaydet ya da yapay zekâdan o yeri bulandırtmasını iste.

**Ne yapacaksın**
1. Kaydın yolunu ve aşağıdaki isteği yapıştır. **Yalnızca 1 dakikalık taslak** isteyeceksin.
2. Taslağı **baştan sona kendin izle**; notları dakika:saniye ile yaz.
3. Notları yapıştır; son sürümü iste.
4. Teslim kontrolü: `docs/VIDEO_REHBERI.md` §7 listesi.

**Yapıştır (taslak)**
```
tandem-video skill'ini kullan. Şu kaydı düzenle: <kaydın tam yolu>
- sessiz ve bekleme yerlerini kes,
- tıklanan yerleri yakınlaştır,
- her adıma Türkçe altyazı ekle,
- e-posta, parola görünen yeri bulanıklaştır.
Önce 1 dakikalık taslak çıkar. En çok 3 dakika. Dosya yolunu söyle, başka bir şey yapma.
```
**Yapıştır (notlar)**
```
Notlarım: 0:12 gereksiz bekleme, kes. 0:40 altyazı geç kalıyor. 0:55 yakınlaştırma çok fazla.
Bunlara göre son sürümü çıkar.
```
**Ne görmelisin:** `.mp4` + `.srt`, süre en çok 2 dk, sen izledin.
**Takılırsan:** yapay zekâ videoyu insan gibi izleyemez, kareleri örnekler; asıl kontrol sende.

**Montaj planıyla (araç fark etmez, doğrulandı).** Yukarıdaki istek Claude/Kinocut içindir. Her yapay zekâ aracında çalışan yol: kesimi **plan dosyası** (`tools/video/kaynak/planlar/*.json`) belirler, `kayit.py` uygular. Örnek: 15 dakikalık bir kayıt bu yolla 2:17 + 2:32'lik iki videoya bölündü (`mcp_1_filesystem_desktop_commander.json`, `mcp_2_blender.json`).
1. Kaydı bir kez izle. Kalacak bölümleri `dk:sn` ile, hızlandırılacak bekleme/yazma anlarını `2x`, `4x` diye not et. Ekranda ad/e-posta görünen anları da yaz (en sık yeni boş sohbetin "İyi günler, ..." karşılamasında çıkar): ya o anı kes ya bulandırt.
2. Yapay zekâya yapıştır (komut çalıştırabilen araç: Codex, Antigravity, Kiro, VS Code ajanı, Claude Code):
```
tools/video/kaynak/kayit.py dosyasının başındaki açıklamayı ve planlar/mcp_1_filesystem_desktop_commander.json örneğini oku.
Şu kayıt için yeni bir plan yaz: <kaydın tam yolu>. Bölümlerim (dk:sn, hız): <buraya notların>.
Her bölüme kısa Türkçe başlık ve metin yaz. Sonra şunu çalıştır:
python kayit.py planlar/<yeni>.json --kaynak "<kaydın tam yolu>" --kareler
```
3. `tools\video\kare\<dosya>_sayfa.jpg` kontrol sayfasını **kendin aç** ve bak (yazı okunuyor mu, isim görünüyor mu). Bulanıklık varsayılan **kapalı** (okunmayan ekran öğretmez); sol kenar çubuğundaki sohbet/proje adları, Gezgin listeleri, klasör yolları ve kullanıcı adı görünür. Parola, anahtar, e-posta görünüyorsa o anı kes ya da yeniden kaydet. Gerekirse `TANDEM_BULANIK=1` ile plandaki `bulanik` kutuları açılır. Sorun yoksa `--kareler` olmadan çalıştır; video `tools\video\cikti\` altına düşer (sessiz mp4 + `.srt`).
4. Yalnızca sohbet olan araçlarda (komut çalıştıramaz): planı yapay zekâ yazar, `python kayit.py ...` komutunu sen kendin PowerShell'de çalıştırırsın.

**Ekstra (isteğe bağlı): metinden video (Yol B).**
```
cd tools\video\kaynak
copy senaryo\v06.py senaryo\v07.py
```
`v07.py` içinde `no` = 7, `dosya`, `baslik` ve sahne metinlerini değiştir; `senaryo\__init__.py` listesine `v07` ekle. Sonra `python uret.py 7 --kareler` → `tools\video\kare\` altına bak → `python uret.py 7`. Ya da yapay zekâya: "tandem-video skill'iyle 1 dakikalık, X konulu video yap".

**Kinocut'ı Hyperframes'e bağlama (ayar dosyası güncellendi):** Claude Desktop'u **tamamen kapat** (görev çubuğu simgesi → Quit), yeniden aç. Test: sohbette "kinocut `hyperframes_doctor` aracını çalıştır". `hyperframes_not_found` hâlâ çıkarsa ayar yüklenmemiştir (aşağıdaki "Ayar dosyası" bölümü).

---

## Video 5 · Kendi skill'ini yaz [BİRLİKTE] (15 dk)
**Amaç:** 8 satırlık kendi skill'ini yazıp, yüklendiğini **ilk satırla kanıtlamak**. Ne işe yaradığını anlatmak yerine elinle yapıyoruz.

**Ne yapacaksın**
1. **Klasör aç.** Proje kökünde PowerShell'e yaz:
```
mkdir .claude\skills\selam
```
2. **Dosyayı oluştur.** Adı tam `SKILL.md` olmalı (büyük harf). Not Defteri kullanırsan: *Farklı kaydet* → Tür: **Tüm dosyalar** → Ad: `SKILL.md` → Kodlama: **UTF-8**. (Yoksa `SKILL.md.txt` olur ve skill hiç görünmez; en sık hata budur.) Yolu şu olsun: `.claude\skills\selam\SKILL.md`.
3. **İçine şunu yapıştır.** İlk üç satır (`---` arası) "künyesi": `name` klasör adıyla aynı, `description` yapay zekâya **ne zaman yükleneceğini** söyler.
```
---
name: selam
description: Kullanıcı "selam skill'i" ya da "selam ver" dediğinde yüklenir. Kısa bir selamlama kuralı içerir.
---

# Selam kuralı
İlk yanıtının ilk satırı `Selam skill'i yüklendi.` olsun.
Sonra TANDEM'in o an açık işini tek cümleyle özetle.
Sade Türkçe yaz.
```
4. **Yeni bir oturum aç** (skill listesi oturum başında okunur; açık oturumda geç görünebilir).
5. **Dene:** yeni oturumda şunu yaz:
```
selam skill'ini kullan.
```
6. **Kontrol:** cevabın ilk satırı `Selam skill'i yüklendi.` → başardın. Değilse sırayla bak:

| Belirti | Bak |
|---|---|
| İlk satır yok | `dir .claude\skills\selam` → `SKILL.md` görmelisin (`SKILL.md.txt` değil) |
| Dosya var, yine yok | Yol tam `.claude\skills\selam\SKILL.md` mı? İlk satır `---` mı? |
| Hâlâ yok | Yeni oturum mu açtın? Proje kökü açık mı? |

7. **Geliştir:** `SKILL.md`'ye bir kural ekle (örn. "Cevabı iki cümleyle bitir"), yeni oturumda tekrar dene.
8. **Gerçeğine bak:** `.claude\skills\tandem-video\SKILL.md` (35 satır) aynı kalıp: künye + kurallar + süreç + rapor şablonu. Sen kendininkini böyle büyüteceksin.
9. **Temizle:** denemeyi silmek için `Remove-Item -Recurse .claude\skills\selam`.

**Ne görmelisin:** `Selam skill'i yüklendi.` satırı. Öğrendiğin şey: skill = klasör + `SKILL.md` + künye + kurallar; "yüklendi" satırı, yüklenmeyi kontrol etmenin yolu.

**[Claude Code değilsen]** (Codex, Antigravity, Kiro, VS Code) skill klasörü yoktur; aynı alıştırma **talimat dosyasıyla** yapılır. Skill'in özü zaten "yapay zekânın okuyacağı bir metin dosyası"dır.
1. Paketteki `AGENTS.md` dosyasının **en altına** şu 4 satırı ekle:
```
# Selam kuralı
İlk yanıtının ilk satırı `Selam skill'i yüklendi.` olsun.
Sonra TANDEM'in o an açık işini tek cümleyle özetle.
```
2. Yeni sohbette yaz: `AGENTS.md dosyasını oku ve uygula. Selam kuralını uyguladığını göster.`
3. İlk satır `Selam skill'i yüklendi.` ise başardın. Olmadıysa dosya yolunu ve ekleyip kaydettiğini kontrol et.
4. Temizle: eklediğin 3 satırı sil.

**Bonus 1 · CLAUDE.md kuralı (5 dk).** Yapıştır:
```
Bu projede her değişiklikten sonra node tools/denetim/denetim.js çalışsın ve 0 ihlal olsun.
Bunu CLAUDE.md'ye kural olarak ekle ve eklediğin satırı göster.
```
Eklenen satırı oku. Geri almak için: `git restore CLAUDE.md`.

**Bonus 2 · MCP ayarına bak (yalnızca oku).** Bu bilgisayarda Claude Desktop'ın etkin ayar dosyası Store yolundadır (içinde `Roblox_Studio` ve `kinocut` var):
`%LOCALAPPDATA%\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Roaming\Claude\claude_desktop_config.json`
`%APPDATA%\Claude` altındaki kopya etkin değil (yalnız `unityMCP` içeriyor). `mcpServers` altında her MCP bir bloktur (`command`, `args`, isteğe `env`). Anahtar/parola içeren `env` değerlerini **kimseye gösterme, sohbete yapıştırma**.

---

## Video 6 · Projeyi birlikte sürdürmek (20 dk)
**Amaç:** görev döngüsünü, riski olmayan bir görevle baştan sona bir kez yürütmek.

**Ne yapacaksın**
1. Yeni oturum aç, ilk mesaj kalıbını yapıştır (aşağıda). Açık işleri sıralamasını bekle.
2. `docs/EKIP_GUNLUGU.md` içindeki **Kilitler** tablosuna adını ve dokunacağın dosyayı yaz: `docs/EKIP_GUNLUGU.md`.
3. Görev (yalnızca belge): günlüğün **Günlük** tablosuna "föy denemesi" satırı eklet.
4. Denetim: `node tools/denetim/denetim.js` → **0 ihlal**.
5. (Kod değiştirdiysen) Studio'da Test → Play ile bir tur dene. Bu görev yalnızca belge olduğu için atlanır.
6. Kilitler tablosundan satırını sil. Birleştiriciye "değişen dosyalar: `docs/EKIP_GUNLUGU.md`" mesajını **yaz** (gönderme senin eylemin).

**Yapıştır (ilk mesaj)**
```
TANDEM yönergesini yükle.
docs/VAKA_TANDEM.md ve docs/EKIP_GUNLUGU.md dosyalarını oku.
Açık işleri sırala, bir sonraki küçük adımı öner.
```
**Yapıştır (görev)**
```
docs/EKIP_GUNLUGU.md Günlük tablosuna "föy denemesi" satırı ekle: bugünün tarihi, rolüm "ekip üyesi",
ne yaptım "video föyündeki 6. alıştırmayı denedim", test sonucu "yalnızca belge, denetim 0 ihlal".
Başka dosyaya dokunma. Ekledikten sonra denetimi çalıştır.
```
**Ne görmelisin:** günlükte yeni satır, `0 ihlal`, kilit tablosunda satırın yok.
**Takılırsan:** `docs/DEVIR_REHBERI.md` §3 (hangi sorun kimde) ve §4 (yardım mesajı kalıbı).

---

## Video 7 · Claude'a dosya ve komut erişimi vermek (Filesystem + Desktop Commander)
**Önce bil:** videoyu hazırladık ama herkesin bilgisayarını göremiyoruz; ekranın bizimkinden farklı olabilir. Hiçbir MCP bağlı değilse ya da takıldıysan yapay zekâna ekran görüntüsüyle (yalnızca ilgili pencere) sor.

**Ne yapacaksın** (Claude Desktop)
1. Ayarlar (`Ctrl` + `,`) → **Uzantılar** → **Uzantılara göz at**.
2. `filesystem` ara → Anthropic'in **Filesystem** uzantısını aç → **Yükle**.
3. Açılan pencerede **Allowed Directories** → klasör ekle. Yalnızca çalışacağın klasörü ver (TANDEM klasörü gibi), bütün diski verme.
4. Kaydet, sonra uzantının anahtarını **Etkin** yap.
5. Ayarlar → **Geliştirici** → Yerel MCP sunucuları: Filesystem **Çalışıyor** olmalı.
6. Aynı yerde `desktop` ara → **Desktop Commander** → **Yükle** → çıkan pencerede **Install**.
7. Birkaç saniye bekle. "Uzantı sunucusuna bağlanılamıyor" uyarısı çıkarsa bekle; geçmezse uzantıyı kapatıp yeniden aç.

**Node.js gerekir mi?**
- Uzantılar sayfasından kurulum için ayrıca Node.js kurmak gerekmez: Anthropic'in belgesine göre Claude Desktop kendi Node.js'iyle gelir. **Belgeye göre; Node.js'i olmayan bir bilgisayarda denenmedi.**
- Node.js yalnızca ayar dosyası / `npx` yoluyla MCP eklerken gerekir. Kontrol: PowerShell'de `node -v`. "Tanınmıyor" derse kur:
```
winget install OpenJS.NodeJS.LTS
```
Kurulum bitince **yeni** bir PowerShell aç ve `node -v` yaz; sürüm numarası çıkmalı. (`winget` paket adı kontrol edildi; bu komut burada çalıştırılmadı.)

**Ne görmelisin:** Uzantılar listesinde Filesystem ve Desktop Commander; Geliştirici sayfasında ikisi de **Çalışıyor**.
**Takılırsan:** uzantıyı kapatıp aç → Claude'u tamamen kapatıp (sağ alttaki simge → Quit) yeniden aç → hata metnini yapay zekâna ver. **Güvenlik:** Desktop Commander komut çalıştırabilir; yalnızca güvendiğin uzantıları kur.

---

## Video 8 · Claude'a Blender'ı kurdurmak (Blender MCP)
**Önce:** Video 7 bitmiş olmalı (Claude'un dosya ve komut erişimi var). Blender kurulu olmalı. Ekranın videodan farklıysa yapay zekâna sor.

**Yapıştır (Claude'a)**
```
En uygun Blender MCP'sini araştır ve ardından kurulumları yap ve Claude Desktop config dosyasına yaz.
```
**Ne yapacaksın**
1. Claude araştırır ve kurar (birkaç dakika). İlk kullanımda izin penceresi çıkarsa **Bir kez izin ver**'e bas.
2. Claude'un yazdığı adımları uygula: Claude Desktop'u **tamamen kapat** (Dosya menüsünün en altındaki **Çık** / Exit) ve yeniden aç.
3. Blender'ı aç → Düzen → Tercihler → Eklentiler → **MCP for Blender** kutusunu işaretle.
4. Blender'da `N` tuşuyla yan paneli aç → **MCP for Blender** sekmesi. **Connected on port 9876** yazmalı; yazmıyorsa **Start MCP Server**'a bas.
5. Claude'da Ayarlar → Geliştirici: `blender` **Çalışıyor** olmalı.
6. Dene (Claude'a): `Blender'da 5 saniyelik araba animasyonu yap`.

**Notlar**
- Blender MCP `uv` (Python paket aracı) ve Python ister; videodaki kurulumda Claude bunları Desktop Commander ile kendisi kurdu. Kendin kurmak istersen yapay zekâna "uv'yi Windows'a kur" de.
- Claude Blender'da kod çalıştırır: önemli sahneyi önce kaydet.

**Ne görmelisin:** Blender'da yol, ağaçlar, lambalar ve zaman çizelgesinde ilerleyen bir araba.
**Takılırsan:** önce Blender'daki sunucu durumuna bak (`Connected on port 9876`), sonra Claude'un Geliştirici sayfasındaki `blender` durumuna; ikisi de yeşilse Claude'u kapatıp aç.

---

## Ayar dosyası değişikliğinden sonra (Kinocut)
Claude Desktop ayarı yalnızca **uygulama açılırken** okur. Değişiklikten sonra: görev çubuğunda simgeye sağ tık → **Quit**, sonra yeniden aç (pencereyi kapatmak yetmez).
Bu bilgisayarda `kinocut` girdisine şu satır eklendi (yedek: aynı klasörde `.yedek-2026-10-06`):
`"env": { "MCP_VIDEO_HYPERFRAMES_COMMAND": "...\\Videos\\TANDEM_AI_Egitim\\arac\\node_modules\\.bin\\hyperframes.cmd" }`
Başka bilgisayarda: önce `docs/VIDEO_REHBERI.md` §4'teki kurulumu yap, sonra bu satırı **kendi yolunla** ekle.
Geri almak: yedek dosyayı asıl dosyanın üstüne kopyala, uygulamayı yeniden başlat.
