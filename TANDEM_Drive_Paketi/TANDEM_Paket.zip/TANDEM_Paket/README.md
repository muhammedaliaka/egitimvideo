# 🏎️ Tandem

> Roblox yarış oyunu — Rojo + Git ile yönetilen profesyonel proje yapısı.

---

## 📁 Klasör Yapısı

```
tandem/
├── src/
│   ├── server/          → ServerScriptService/Tandem (sadece sunucuda çalışır)
│   ├── client/          → StarterPlayer/StarterPlayerScripts/Tandem (istemcide çalışır)
│   └── shared/          → ReplicatedStorage/Tandem (her ikisinde de)
├── tools/               → denetim (kural denetimi), sync (Studio MCP eşitleme), paket (dağıtım paketi)
├── docs/                → Dökümanlar
├── default.project.json → Rojo yapılandırması (tools/sync ile aynı yerleşim)
├── dist/                → üretilen paket (git'e girmez)
└── .gitignore
```

---

## 🚀 Kurulum

### Gereksinimler

- [Roblox Studio](https://www.roblox.com/create)
- [Rojo](https://rojo.space/) (Studio eklentisi + CLI)
- [Git](https://git-scm.com/)
- [VS Code](https://code.visualstudio.com/) + [Luau LSP](https://marketplace.visualstudio.com/items?itemName=JohnnyMorganz.luau-lsp) eklentisi

### Başlangıç

```bash
# 1. Repoyu klonla
git clone https://github.com/KULLANICI_ADI/tandem.git
cd tandem

# 2. Rojo'yu başlat
rojo serve default.project.json

# 3. Roblox Studio'yu aç
#    Rojo eklentisinden "Connect" butonuna tıkla
#    Proje otomatik senkronize olur
```

---

### Ekibe dağıtım (kurulu paket)

```powershell
node tools/denetim/denetim.js          # 0 ihlal olmalı
powershell -ExecutionPolicy Bypass -File tools\paket\paketle.ps1
```

`dist/TANDEM_Paket.zip` çıkar: içinde hazır `Tandem.rbxl`, kaynak ve `OKU_BENI.md` var. Ekip dosyayı Drive'dan indirip çift tıklar; Team Create gerekmez. Çok oyunculu yerel test: Studio → Test → Clients and Servers.

---

## 🔀 Git Workflow (Ekip için)

```bash
# Yeni özellik başlatmak için
git checkout dev
git pull origin dev
git checkout -b feature/ozellik-adi

# Çalışmayı bitirince
git add .
git commit -m "feat: özellik açıklaması"
git push origin feature/ozellik-adi

# GitHub'da Pull Request aç → dev branch'e merge et
```

### Branch Stratejisi

| Branch | Amaç |
|--------|------|
| `main` | Yayında olan kararlı versiyon |
| `dev` | Geliştirme ana hattı |
| `feature/...` | Yeni özellikler |
| `fix/...` | Hata düzeltmeleri |
| `hotfix/...` | Acil production düzeltmeleri |

---

## 💻 Commit Mesajı Formatı

```
feat: yeni özellik eklendi
fix: hata düzeltildi
refactor: kod yeniden düzenlendi
docs: döküman güncellendi
chore: genel bakım/araç değişiklikleri
```

---

## 👥 Ekip

| Rol | Sorumluluk |
|-----|-----------|
| Lead Dev | main/dev yönetimi, PR review |
| Scripter | feature branch'te Luau yazımı |
| Builder | Harita/model, asset yükleme |

---

## 📜 Lisans

Bu proje özel bir ekip projesidir.
