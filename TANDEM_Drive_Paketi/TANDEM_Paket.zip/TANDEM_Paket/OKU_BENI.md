# TANDEM test paketi

İki kişilik fizik-komedi araç oyunu (küvet araba). Bu paket **kurulu halde** gelir: ek program gerekmez.

> Claude'u Roblox Studio'ya bağlamak istersen (isteğe bağlı): aynı Drive klasöründeki **rehber videosunu** izle (`TANDEM_Rehber_Video.mp4`, bölüm listesi `TANDEM_Rehber_Bolumler.txt`). Oyunu oynamak için bu bağlantı gerekmez.

> Ekip eğitimi: aynı Drive klasöründeki `Egitim_Videolari` (8 kısa video, toplam ~19 dk). Roller, destek ve izleme sırası: `docs/DEVIR_REHBERI.md`.

## 1) Hazır dosyayı aç (en kolay yol)
1. `Tandem.rbxl` dosyasına çift tıkla. Roblox Studio açılır (Studio yüklü olmalı).
2. **Tek kişi:** F5 (Play). Eşin bot olur.
3. **İki veya daha fazla kişi, sunucu modu (internetsiz, aynı bilgisayarda):** üstte **Test** sekmesi → **Clients and Servers** → *Players* kutusuna kişi sayısını yaz (2, 3...) → **Start**. Hepsi tek yerel sunucuya girer. Team Create gerekmez.

## 2) Gerçek internet testi (herkes kendi bilgisayarından)
- Oyun linki: https://www.roblox.com/games/87182062360026
- Oyun **özel**dir: sadece ekibe açıktır. Roblox'a kendi hesabınla girip **Oyna**'ya bas.
- Birlikte oynamak için: koşu bitince **Eş Bul**'a bas. 45 saniye içinde arkadaşın da basarsa aynı araca binersiniz (arkadaşlar öncelikli). Basılmazsa botla devam edersin.
- Sunucu 60 oyuncuya kadar koşu açar; herkesin kendi pisti olur.

## 3) "Takım Çalışması oturumuna katılım başarısız ... connectToTeamCreateSession: no response" hatası
Bu, Roblox'un Team Create bağlantısıdır; oyunu **oynamak için gerekmez**. Yukarıdaki 1. ve 2. yol Team Create kullanmaz.
Yine de gerekirse sırayla dene:
1. Studio'yu kapatıp aç; hepsi oturumdan çıkıp **tek tek** girsin.
2. Studio ve Windows güncel olsun.
3. VPN ve antivirüs/güvenlik duvarı programını kapatıp dene (Studio'ya izin ver).
4. Modemi yeniden başlat; mümkünse telefon hotspot'u ile dene (zayıf internet bu hatayı çok verir).
5. Olmuyorsa Team Create'i bırak: herkes bu paketi kendi bilgisayarında açar.

## 4) Yapay zekâ (Claude vb.) ile çalışacaksan
Bu klasör projenin **tamamıdır** ve yapay zekâya ne yapacağını söyleyen **zorunlu yönergeyi** içerir:
1. Zip'i bir klasöre çıkar, **o klasörü** kullandığın yapay zekâ aracında aç (Claude Code, Codex, Antigravity, Kiro, VS Code…).
2. Hangi aracın hangi kural dosyasını kendiliğinden okuduğu araca göre değişir (tablo: `docs/VIDEO_FOYU.md`). `CLAUDE.md`, `AGENTS.md` ve klasörün en üstündeki `00_YAPAY_ZEKA_ONCE_OKU.md` aynı emri verir: yapay zekâ önce `.claude/skills/tandem-ekip/SKILL.md` yönergesini okur (çalışma kuralları, halüsinasyonsuz muhakeme, proje kilitleri, rapor biçimi). Aracın dosya okuyamıyorsa (ör. tarayıcıdaki sohbet), bu iki dosyanın içeriğini sohbete yapıştır.
3. **Kontrol et:** yapay zekânın ilk yanıtı `TANDEM yönergesi yüklendi.` diye başlamalı. Başlamazsa `docs/EKIP_REHBERI.md` içindeki "İlk mesaj kalıbı"nı yapıştır.
4. Nasıl iyi istek yazılır, ekip kuralları (çakışma olmasın) ve örnek görevler: `docs/EKIP_REHBERI.md`. İş günlüğü ve "kim hangi dosyada çalışıyor": `docs/EKIP_GUNLUGU.md`.
5. Claude'un Studio'yu görmesi/denemesi için Roblox Studio MCP bağlantısı gerekir (rehber videosundaki adımlar). Kuramazsan bile yapay zekâ kodu `src` içinde değiştirebilir; sen `Tandem.rbxl`'yi yeniden üretip (aşağıda) denersin.
6. Güvenlik: yapay zekâya parola/anahtar yazma; MCP'yi yalnızca kendi Studio'na bağla.

## 5) Kod değiştirecek olanlar
- Kaynak kod `src` klasöründedir. Kod **tek kişide** değişsin (iki kişi aynı dosyayı değiştirirse çakışır); yeni sürüm yine paket olarak dağıtılır.
- Rojo ile canlı eşitleme: [Rojo](https://rojo.space) kur → proje klasöründe `rojo serve` → Studio'da Rojo eklentisinden **Connect**. Yeni `Tandem.rbxl` üretmek için: `rojo build default.project.json -o Tandem.rbxl`.
- Kod kuralları (dosya başına en çok 25 KB, sabit sayı yok): `node tools/denetim/denetim.js` 0 ihlal vermeli.

## Klasörde ne var?
- `Tandem.rbxl` — hazır oyun (çift tıkla). `src` — kod. `default.project.json` — Rojo ayarı.
- `00_YAPAY_ZEKA_ONCE_OKU.md`, `CLAUDE.md`, `AGENTS.md`, `.claude/skills/tandem-ekip/` — yapay zekâya zorunlu çalışma yönergesi.
- `docs/` — projenin kuralları, kararları, mimarisi, vaka günlüğü, ekip rehberi ve ekip günlüğü.
- `tools/denetim` — kod kuralı denetimi; `tools/sync` — Studio'ya canlı eşitleme aracı (Node gerekir).

## Notlar
- Studio içinde puanlar/ayarlar kaydedilmez (DataStore kapalı); bu normal. Yayınlanmış oyunda kaydedilir.
- Yayın öncesi test kancaları kapalıdır (`Kosu.Deneme.Etkin = false`).
