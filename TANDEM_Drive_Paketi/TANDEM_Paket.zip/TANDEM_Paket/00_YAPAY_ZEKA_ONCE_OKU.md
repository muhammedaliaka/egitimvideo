# YAPAY ZEKÂ: ÖNCE BUNU YAP (ZORUNLU, PAZARLIK YOK)

Sen bir yapay zekâ asistanısın ve bu klasör **TANDEM** projesi (Roblox, iki kişilik fizik-komedi oyunu; ekip çalışması). Bu projede **herhangi bir işi** (kod, ayar, ses, pist, bot, arayüz, Studio, test, dosya) yapmadan ya da kullanıcıya bir şey söylemeden önce, sırayla:

1. **`.claude/skills/tandem-ekip/SKILL.md` dosyasını TAMAMEN OKU ve her kuralını uygula.** Bu senin işletim talimatındır; muhakeme protokolü (halüsinasyon yok, kanıt etiketi, ölçerek doğrulama), proje kilitleri, onay gerektirenler ve rapor biçimi orada. Aracın bu dosyayı otomatik yüklemediyse **kendin aç ve oku**; "okudum" deme, okumadan başlama.
2. `docs/MIMARI.md`, `docs/PROTOTIP_TANDEM_YAPILANDIRMA.md`, `docs/PRODUCT_KARARLAR_tandem.md` dosyalarını oku (proje haritası, kararlar).
3. `docs/VAKA_TANDEM.md` ve `docs/EKIP_GUNLUGU.md` dosyalarını oku (ne yapıldı, ne açık, kimin hangi dosyada çalıştığı).
4. **İlk yanıtının ilk satırı `TANDEM yönergesi yüklendi.` olsun.** Kullanıcı bunu görmezse yönergeyi yüklememişsindir.

Bu adımları atlayıp iş yapma. Tahminle kod yazma; var olmayan dosya, işlev, ayar ya da Roblox API'si uydurma; doğrulamadığın şeyi kesin söyleme. Kullanıcıya **sade Türkçe** yaz. Ekip Roblox'a yeni: kısa, adım adım, uygulanabilir yönlendir. Kapsam serbesttir (yeni özellik eklemekten çekinme) ama kilitli kararlara ve onay gerektiren işlere (yayın, toplu silme, parola/anahtar) dokunma.

---

