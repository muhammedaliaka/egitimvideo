# YAPAY ZEKÂ: ÖNCE BUNU YAP (ZORUNLU, PAZARLIK YOK)

Sen bir yapay zekâ asistanısın ve bu klasör **TANDEM** projesi (Roblox, iki kişilik fizik-komedi oyunu; ekip çalışması). Bu projede **herhangi bir işi** (kod, ayar, ses, pist, bot, arayüz, Studio, test, dosya) yapmadan ya da kullanıcıya bir şey söylemeden önce, sırayla:

1. **`.claude/skills/tandem-ekip/SKILL.md` dosyasını TAMAMEN OKU ve her kuralını uygula.** Bu senin işletim talimatındır; muhakeme protokolü (halüsinasyon yok, kanıt etiketi, ölçerek doğrulama), proje kilitleri, onay gerektirenler ve rapor biçimi orada. Aracın bu dosyayı otomatik yüklemediyse **kendin aç ve oku**; "okudum" deme, okumadan başlama.
2. `docs/MIMARI.md`, `docs/PROTOTIP_TANDEM_YAPILANDIRMA.md`, `docs/PRODUCT_KARARLAR_tandem.md` dosyalarını oku (proje haritası, kararlar).
3. `docs/VAKA_TANDEM.md` ve `docs/EKIP_GUNLUGU.md` dosyalarını oku (ne yapıldı, ne açık, kimin hangi dosyada çalıştığı).
4. **İlk yanıtının ilk satırı `TANDEM yönergesi yüklendi.` olsun.** Kullanıcı bunu görmezse yönergeyi yüklememişsindir.

Bu adımları atlayıp iş yapma. Tahminle kod yazma; var olmayan dosya, işlev, ayar ya da Roblox API'si uydurma; doğrulamadığın şeyi kesin söyleme. Kullanıcıya **sade Türkçe** yaz. Ekip Roblox'a yeni: kısa, adım adım, uygulanabilir yönlendir. Kapsam serbesttir (yeni özellik eklemekten çekinme) ama kilitli kararlara ve onay gerektiren işlere (yayın, toplu silme, parola/anahtar) dokunma.

---

@.claude/skills/tandem-ekip/SKILL.md

---

# TANDEM — proje talimatları

Roblox'ta iki kişilik fizik-komedi araç oyunu (çalışma adı TANDEM). Akım'ın (`..\akim`) bulduğu fırsatın uçtan uca kanıtı.

## Kurallar
- Kullanıcıya **her zaman sade Türkçe** yanıt ver. Ekip Roblox'a yeni; her adımı kısa ve uygulanabilir anlat, kullanıcıyı yönlendir.
- **Önce `docs/PROTOTIP_TANDEM_YAPILANDIRMA.md` oku.** Kararlar: `docs/PRODUCT_KARARLAR_tandem.md` (D1-D26). Kanıt: `docs/PRODUCT_PLAN_tandem_coop.md`. Mimari: `docs/MIMARI.md`.
- **Kalite çıtası:** "prototip" çöp demek değildir; yapılabilecek en iyi prototip hedeflenir. Roblox'un tüm sistemleri serbest. Kilit olmayan kural çiğnenebilir (gerekçesiyle). Öneri/ek özellik eklemekten çekinme; kapsam artık serbest (eski "yeni özellik = önce sor" kuralı kalktı).
- **Kilitli kararlar:** D1 komik kaos/mekanik, D2 kolay giriş, D3 bot + hızlı eşleşme + davet, D4 ses kullanıcıdan (geçici sesler = yer tutucu), D10 ev eşyası aracı, D11 asimetrik roller (rol kontrol noktasında değişir), D12 arkadaş kanalı, D14-D16 (5-10 test kişisi, önce kanıt sonra yayın, prototip herkese açık değil).
- **Kullanıcının sabit standartları (pazarlıksız):** dosya başına **en çok 25 KB**; **sıfır sabit kodlama** (her sayı/metin/ad yapılandırma modülünde — kodda yalnızca 0/1/2 ve `Cekirdek/Matematik` adlı sabitleri); ayarlar **kalıcı** kaydedilir.
- Saat günlüğü / K katsayısı **bırakıldı**; saat sorma.
- §10'daki doğrulanmamış varsayımları **doğrulamadan** kesin bilgi gibi yazma; sonucu ("doğrulandı / yanlış çıktı / belirsiz") belgeye işle.
- **Alt ajan açma** (yükleme bant genişliği sınırlı). Tüm işi bu oturumda yap.
- Parola, anahtar, hesap bilgisi isteme/yazma. MCP istemcisi Studio'yu değiştirebilir: yalnızca güvenilen bağlantı.
- Kod: **Luau**, dosya tabanlı: `src/{server,shared,client}`; Studio'ya `tools/sync` ile yüklenir (döngü: Play'i durdur → eşitle → Play). Sunucu doğrulaması şart (bitiş süresi, kontrol noktası, ışınlanma).
- Kimlikler ASCII Türkçe (ç/ğ/ş yok), `--!strict`, yapılandırmalar `Kitaplik.derinDondur`.
- Her kapı sonunda `docs/VAKA_TANDEM.md` güncelle (kısa, dürüst). Çalışan hâli git ile kontrol noktası yap (kullanıcı isterse).
- **Yayın öncesi kapat:** `Kosu.Deneme.Etkin/Otopilot/AvatarYukle`, `Arayuz.Deneme.ZorlaCihaz` (false), HttpService.HttpEnabled; yeri kaydet. Yayın/davet kullanıcının eylemidir.
