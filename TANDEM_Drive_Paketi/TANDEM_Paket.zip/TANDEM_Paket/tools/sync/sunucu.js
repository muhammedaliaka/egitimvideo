// Geliştirme eşitleme sunucusu: src/ içindeki .luau dosyalarını Studio'ya sunar.
// Yalnızca 127.0.0.1'e bağlanır, yalnızca okur. Studio tarafı yukleyici.luau ile çeker.
const http = require("http");
const fs = require("fs");
const path = require("path");

const ayar = JSON.parse(fs.readFileSync(path.join(__dirname, "eslesme.json"), "utf8"));
const kaynakDizin = path.resolve(__dirname, "..", "..", ayar.kaynak);

function turBul(dosyaAdi) {
  // Uzantıları uzundan kısaya dene: ".server.luau" önce, ".luau" en son.
  const siralama = Object.entries(ayar.uzantilar).sort((a, b) => b[1].length - a[1].length);
  for (const [tur, uzanti] of siralama) {
    if (dosyaAdi.endsWith(uzanti)) return { tur, ad: dosyaAdi.slice(0, -uzanti.length) };
  }
  return null;
}

function tara(dizin, kok, parcalar, cikti) {
  for (const girdi of fs.readdirSync(dizin, { withFileTypes: true })) {
    const tam = path.join(dizin, girdi.name);
    if (girdi.isDirectory()) {
      tara(tam, kok, parcalar.concat(girdi.name), cikti);
      continue;
    }
    const bilgi = turBul(girdi.name);
    if (!bilgi) continue;
    cikti.push({
      kok,
      dizin: parcalar,
      ad: bilgi.ad,
      tur: bilgi.tur,
      icerik: fs.readFileSync(tam, "utf8"),
    });
  }
}

function paketle() {
  const dosyalar = [];
  for (const kok of Object.keys(ayar.kokler)) {
    const dizin = path.join(kaynakDizin, kok);
    if (fs.existsSync(dizin)) tara(dizin, kok, [], dosyalar);
  }
  return { kokler: ayar.kokler, dosyalar };
}

const sunucu = http.createServer((istek, yanit) => {
  try {
    if (istek.url === "/saglik") return yanit.end("tamam");
    if (istek.url === "/yukleyici") {
      yanit.setHeader("Content-Type", "text/plain; charset=utf-8");
      return yanit.end(fs.readFileSync(path.join(__dirname, "yukleyici.luau"), "utf8"));
    }
    if (istek.url === "/paket") {
      yanit.setHeader("Content-Type", "application/json; charset=utf-8");
      return yanit.end(JSON.stringify(paketle()));
    }
    yanit.statusCode = 404;
    yanit.end("yok");
  } catch (hata) {
    yanit.statusCode = 500;
    yanit.end(String(hata));
  }
});

sunucu.listen(ayar.port, "127.0.0.1", () => console.log(`eşitleme sunucusu: 127.0.0.1:${ayar.port}`));
