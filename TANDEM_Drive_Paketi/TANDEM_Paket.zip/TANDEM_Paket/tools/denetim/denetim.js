// Kod denetimi: kullanıcının sabit standartlarını (dosya ≤ 25 KB, sıfır sabit kodlama) kaynak dosyalarda kontrol eder.
// Kullanım: node tools/denetim/denetim.js        (çıkış kodu 1 = ihlal var)
// Kurallar ve istisnalar tools/denetim/izinler.json içindedir (kodda sayı/metin yok sayılır: yapılandırmada tutulur).

const fs = require("fs");
const path = require("path");

const kok = path.join(__dirname, "..", "..");
const izinler = JSON.parse(fs.readFileSync(path.join(__dirname, "izinler.json"), "utf8"));
const kaynak = path.join(kok, izinler.kaynakKlasoru);

function dosyalar(klasor) {
	return fs.readdirSync(klasor, { withFileTypes: true }).flatMap((girdi) => {
		const yol = path.join(klasor, girdi.name);
		return girdi.isDirectory() ? dosyalar(yol) : girdi.name.endsWith(".luau") ? [yol] : [];
	});
}

// Yorumları boşlukla, metinleri ayrı listeye alır; satır numaraları korunur
function ayikla(kod) {
	const metinler = [];
	let temiz = "";
	let i = 0;
	let satir = 1;
	while (i < kod.length) {
		const c = kod[i];
		if (kod.startsWith("--", i)) {
			const uzun = /^--\[(=*)\[/.exec(kod.slice(i));
			if (uzun) {
				const son = kod.indexOf("]" + uzun[1] + "]", i);
				const parca = kod.slice(i, son < 0 ? kod.length : son + uzun[1].length + 2);
				satir += (parca.match(/\n/g) || []).length;
				temiz += parca.replace(/[^\n]/g, " ");
				i += parca.length;
			} else {
				while (i < kod.length && kod[i] !== "\n") i++;
			}
			continue;
		}
		if (c === '"' || c === "'") {
			let j = i + 1;
			while (j < kod.length && kod[j] !== c && kod[j] !== "\n") j += kod[j] === "\\" ? 2 : 1;
			metinler.push({ satir, metin: kod.slice(i + 1, j), onceki: temiz.slice(-40) });
			temiz += " ".repeat(j - i + 1);
			i = j + 1;
			continue;
		}
		if (c === "\n") satir++;
		temiz += c;
		i++;
	}
	return { temiz, metinler };
}

const ihlaller = [];
function ekle(dosya, satir, tur, ayrinti) {
	ihlaller.push({ dosya: path.relative(kaynak, dosya).replace(/\\/g, "/"), satir, tur, ayrinti });
}

function istisnaMi(dosya, liste) {
	const goreli = path.relative(kaynak, dosya).replace(/\\/g, "/");
	return liste.some((onek) => goreli === onek || goreli.startsWith(onek));
}

for (const dosya of dosyalar(kaynak)) {
	const kod = fs.readFileSync(dosya, "utf8");
	const boyut = Buffer.byteLength(kod, "utf8");
	if (boyut > izinler.enFazlaBayt) ekle(dosya, 0, "boyut", `${boyut} bayt > ${izinler.enFazlaBayt}`);

	const { temiz, metinler } = ayikla(kod);

	if (!istisnaMi(dosya, izinler.sayiIstisnalari)) {
		temiz.split("\n").forEach((satirMetni, sira) => {
			for (const eslesme of satirMetni.matchAll(/(?<![A-Za-z_\d.])(\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+)/g)) {
				if (!izinler.izinliSayilar.includes(Number(eslesme[1]))) ekle(dosya, sira + 1, "sayi", eslesme[1]);
			}
		});
	}

	if (!istisnaMi(dosya, izinler.metinIstisnalari)) {
		for (const { satir, metin, onceki } of metinler) {
			if (metin === "" || izinler.izinliMetinler.includes(metin)) continue;
			if (izinler.izinliBaglamlar.some((kalip) => new RegExp(kalip + "\\s*$").test(onceki))) continue;
			ekle(dosya, satir, "metin", JSON.stringify(metin));
		}
	}
}

const gruplu = {};
for (const ihlal of ihlaller) (gruplu[ihlal.dosya] ||= []).push(ihlal);
for (const [dosya, liste] of Object.entries(gruplu)) {
	console.log(`\n${dosya} (${liste.length})`);
	for (const i of liste.slice(0, izinler.dosyaBasinaGoster)) console.log(`  ${i.satir}: ${i.tur} ${i.ayrinti}`);
	if (liste.length > izinler.dosyaBasinaGoster) console.log(`  ... +${liste.length - izinler.dosyaBasinaGoster}`);
}
const sayim = ihlaller.reduce((a, i) => ((a[i.tur] = (a[i.tur] || 0) + 1), a), {});
console.log(`\nToplam ihlal: ${ihlaller.length}`, sayim);
process.exit(ihlaller.length > 0 ? 1 : 0);
