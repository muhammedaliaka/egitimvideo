"""Video 3: veri (metin + ekranda görünecek öğeler). Düzenleme rehberi: __init__.py."""

VIDEO = {
    "no": 3, "dosya": "03_Aciklari_bulan_skilller", "renk": (239, 71, 111),
    "baslik": "Güvenlik açıklarını bulan skill'ler",
    "sahneler": [
        {"tur": "kapak", "baslik": "Güvenlik açıklarını bulan skill'ler", "alt": "Kodu bir saldırgan gibi incelemek", "adimlar": [
            {"soz": "Üçüncü video: kodundaki güvenlik açıklarını bulan skill'ler."},
        ]},
        {"tur": "kart", "adimlar": [
            {"soz": "Skill bir talimat kitabıdır. Yapay zekâ gerektiğinde açar ve içindeki adımları sırayla uygular. Skill desteği araca göre değişir; Claude Code'da klasörü böyledir.",
             "ikon": "bilgi", "buyuk": "Skill = talimat kitabı", "kucuk": "Claude Code: .claude/skills/<ad>/SKILL.md · diğer araçlar: talimat dosyası"},
        ]},
        {"tur": "liste", "baslik": "Proje sahibinin kurduğu güvenlik skill'leri", "adimlar": [
            {"soz": "Bunlar proje sahibinin bilgisayarında kurulu. Sende yoksa sorun değil; aynı kontrolü talimat metniyle de yaptırabilirsin. security-review: kullanıcı girdisi, gizli anahtar ve yetki konularında kodu inceler.",
             "madde": ("nokta", "security-review", "Girdi doğrulama, gizli anahtar, yetki kontrol listesi")},
            {"soz": "security-reviewer ajanı: en yaygın on web açığını, enjeksiyonu ve sızan anahtarları arar.",
             "madde": ("nokta", "security-reviewer (ajan)", "OWASP Top 10, enjeksiyon, sızan anahtar")},
            {"soz": "cso, yani güvenlik şefi modu: tehdit modeli çıkarır, bağımlılıkları ve geçmişte sızmış sırları tarar.",
             "madde": ("nokta", "cso (gstack)", "Tehdit modeli, bağımlılıklar, geçmişte sızmış sırlar")},
            {"soz": "security-bounty-hunter: gürültüye değil, dışarıdan gerçekten sömürülebilen açıklara odaklanır.",
             "madde": ("nokta", "security-bounty-hunter", "Dışarıdan sömürülebilen gerçek açıklar")},
            {"soz": "security-scan: yapay zekânın kendi ayarlarını, MCP bağlantılarını ve hook'ları tarar.",
             "madde": ("nokta", "security-scan", "Claude ayarları, MCP'ler, hook'lar")},
        ]},
        {"tur": "kart", "adimlar": [
            {"soz": "Bunlar iki açık kaynak paketten geliyor: ECC ve gstack. Kurmadan önce yapay zekâya paketi okutup ne yaptığını özetlet.",
             "ikon": "bilgi", "buyuk": "Nereden?", "kucuk": "ECC: github.com/affaan-m/ECC   ·   gstack: github.com/garrytan/gstack"},
        ]},
        {"tur": "liste", "baslik": "Roblox'ta en büyük açık: istemciye güvenmek", "adimlar": [
            {"soz": "Roblox'ta en büyük açık, oyuncunun bilgisayarına güvenmektir. Hileci, RemoteEvent'e istediği her şeyi yollayabilir."},
            {"soz": "O yüzden kararı hep sunucu verir: süre, kontrol noktası, ışınlanma ve bitiş.",
             "madde": ("ok", "Kararı sunucu verir", "Süre, kontrol noktası, ışınlanma, bitiş")},
            {"soz": "Gelen her değerin türünü, aralığını ve ne sıklıkla geldiğini kontrol et.",
             "madde": ("ok", "Gelen her değeri kontrol et", "Tür, aralık, sıklık")},
            {"soz": "Ödül ve kayıt kararını da sunucu verir. İstemci yalnızca istek yollar.",
             "madde": ("ok", "Ödül ve kayıt sunucuda", "İstemci yalnızca istek yollar")},
        ]},
        {"tur": "kod", "baslik": "Örnek istek", "adimlar": [
            {"soz": "Örnek bir istek şöyle. Skill kuruluysa adını yazarsın; kurulu değilse, yapay zekâya kodu bir saldırgan gibi incelemesini söylemen yeter.",
             "satirlar": ["Kodu bir saldırgan gibi incele:", "src/server altındaki tüm RemoteEvent", "işleyicilerini kontrol et."]},
            {"soz": "Her bulgu için dosya ve satırı, nasıl sömürüleceğini ve düzeltmesini iste.",
             "satirlar": ["Her bulgu için: dosya:satır,", "nasıl sömürülür, nasıl düzeltilir."]},
            {"soz": "Emin olmadıklarını ayrıca işaretlemesini de iste.",
             "satirlar": ["Emin olmadıklarını “olası” diye işaretle."]},
        ]},
        {"tur": "liste", "baslik": "Dikkat", "adimlar": [
            {"soz": "Skill de yanılabilir. Her bulguyu Studio'da kendin dene.",
             "madde": ("uyari", "Skill de yanılabilir", "Her bulguyu Studio'da kendin dene")},
            {"soz": "Yalnızca kendi projeni tara. Başkasının oyununda açık denemek yasak ve etik değil.",
             "madde": ("uyari", "Yalnızca kendi projeni tara", "Başkasının oyunu: yasak ve etik değil")},
            {"soz": "Yabancı bir skill'i kurmadan önce oku: skill, bilgisayarında komut çalıştırabilir.",
             "madde": ("uyari", "Yabancı skill'i önce oku", "Skill bilgisayarında komut çalıştırabilir")},
        ]},
        {"tur": "kapak", "rozet": "ok", "baslik": "Sıradaki: Yapay zekâ ile video düzenleme", "alt": "Video 4/6", "adimlar": [
            {"soz": "Sıradaki video: yapay zekâyla video düzenleme."},
        ]},
    ],
}
