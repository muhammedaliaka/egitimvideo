"""TANDEM ekip eğitimi: kısa videoların senaryosu. Yalnızca veri; her video ayrı dosyadır (v01.py ... v06.py).

Yeni video eklemek: v07.py kopyala-yapıştır yap, ``VIDEO`` içindeki ``no``/``dosya``/``baslik``/``sahneler``i değiştir, aşağıdaki listeye ekle.

Sahne türleri: kapak, liste, iki_sutun, kod, akis, kart (örnekler mevcut dosyalarda).
Her sahnede "adimlar" sırayla okunur; adımın görsel öğesi (madde, kutu, satır, kart) cümleyle birlikte belirir.
"soz" hem altyazı hem seslendirme metnidir; seslendirmede sesletim.py İngilizce sözcükleri Türkçe okunuşa çevirir.
Kendi sesinle okumak istersen: ses/ klasöründeki aynı adlı WAV dosyasını ses_kendi/ altına kendi kaydınla koy, uret.py'yi yeniden çalıştır.
"""
from . import v01, v02, v03, v04, v05, v06
from .sesletim import SESLETIM

SERI = "TANDEM · Yapay Zekâ Eğitimi"
VIDEOLAR = [v01.VIDEO, v02.VIDEO, v03.VIDEO, v04.VIDEO, v05.VIDEO, v06.VIDEO]
