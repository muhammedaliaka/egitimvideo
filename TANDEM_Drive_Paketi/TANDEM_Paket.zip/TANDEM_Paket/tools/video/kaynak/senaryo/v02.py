"""Video 2: veri (metin + ekranda görünecek öğeler). Düzenleme rehberi: __init__.py."""

VIDEO = {
    "no": 2, "dosya": "02_Muhakeme_guclu_ve_sinirli", "renk": (46, 196, 182),
    "baslik": "Muhakeme: ne kadar güçlü, ne kadar sınırlı?",
    "sahneler": [
        {"tur": "kapak", "baslik": "Muhakeme: ne kadar güçlü, ne kadar sınırlı?", "alt": "Yapay zekâyı doğru düşündürmek", "adimlar": [
            {"soz": "İkinci video: yapay zekânın düşünme gücü. Ne kadar güçlü, nerede sınırlı ve onu nasıl doğru düşündürürsün?"},
        ]},
        {"tur": "iki_sutun", "sol": "Güçlü", "sag": "Sınırlı", "adimlar": [
            {"soz": "Güçlü yanı: yüzlerce dosyayı dakikalar içinde okur ve bağlantıları kurar.", "sol": "Yüzlerce dosyayı dakikalar içinde okur"},
            {"soz": "Çok adımlı bir plan yapar ve adım adım uygular.", "sol": "Çok adımlı plan yapar ve uygular"},
            {"soz": "Birden çok çözüm dener ve karşılaştırır.", "sol": "Birden çok çözüm dener, karşılaştırır"},
            {"soz": "Sınırlı yanı: yalnızca ona gösterdiğini bilir. Ekranını ya da aklındakini göremez.", "sag": "Yalnızca gösterdiğini bilir"},
            {"soz": "Bilgisi eskiyebilir. Roblox'un oyuncu kontrol modülü değişti; eski yöntem hata verdi. Yapay zekâ bunu ancak Studio'da deneyince fark etti.",
             "sag": "Bilgisi eskiyebilir (Roblox değişir)"},
            {"soz": "Ölçmeden emin olamaz. Ölçüm araçlarını ona sen açarsın: Studio bağlantısı, log, test.", "sag": "Ölçmeden emin olamaz"},
        ]},
        {"tur": "kod", "baslik": "İyi istek kalıbı", "adimlar": [
            {"soz": "İyi bir istek dört parçadan oluşur. Önce hedef: ne olsun istiyorsun?",
             "satirlar": ["Hedef: Havlu engeline çarpınca ses çalsın."]},
            {"soz": "Sonra bitti ölçütü: iş bittiğinde ne göreceksin?",
             "satirlar": ["Bitti ölçütü: Çarpma anında ses var,", "değmeden ses yok. Studio'da deneyip göster."]},
            {"soz": "Sonra sınır: neye dokunmasın?",
             "satirlar": ["Sınır: Yalnızca Ayar ve Geribildirim dosyaları."]},
            {"soz": "Son olarak: önce planını yazsın ve senin onayını beklesin.",
             "satirlar": ["Önce planını yaz, onayımı bekle."]},
        ]},
        {"tur": "akis", "baslik": "Hata ayıklama: tahmin değil, ölçüm", "adimlar": [
            {"soz": "Bir hata gördüğünde yapay zekâdan şu sırayı iste."},
            {"soz": "Önce belirtiyi tam yaz: ne oldu, ne bekliyordun?", "kutu": "Belirtiyi yaz"},
            {"soz": "Sonra en az iki olası neden yazdır.", "kutu": "En az 2 olası neden"},
            {"soz": "Hangisinin doğru olduğunu ölçerek ayırsın: log, ekran görüntüsü ya da küçük bir deney.", "kutu": "Ölçerek ayır"},
            {"soz": "Belirtiyi gizlemesin, kök nedeni düzeltsin.", "kutu": "Kök nedeni düzelt"},
            {"soz": "Ve düzeltmeden sonra tekrar ölçsün. Sonuç değişmediyse, düzelmemiştir.", "kutu": "Tekrar ölç"},
        ]},
        {"tur": "liste", "baslik": "Cevabı iyileştiren 4 soru", "adimlar": [
            {"soz": "Cevabın kalitesini artıran dört soru var."},
            {"soz": "Neyi doğrulamadın?", "madde": ("sayi", "“Neyi doğrulamadın?”", None)},
            {"soz": "En emin olmadığın yer neresi?", "madde": ("sayi", "“En emin olmadığın yer neresi?”", None)},
            {"soz": "Studio'da dene ve sonucu göster.", "madde": ("sayi", "“Studio'da dene, sonucu göster.”", None)},
            {"soz": "Bir alternatif daha öner ve ikisini karşılaştır.", "madde": ("sayi", "“Bir alternatif daha öner, karşılaştır.”", None)},
        ]},
        {"tur": "kart", "adimlar": [
            {"soz": "Büyük bir işte önce plan iste. Sonra küçük adımlarla ilerle; her adımdan sonra denetimi çalıştır ve Play'e basıp dene.",
             "ikon": "ok", "buyuk": "Büyük iş: önce plan, sonra küçük adımlar", "kucuk": "Her adımdan sonra: denetim (0 ihlal) + Play ile dene"},
        ]},
        {"tur": "kapak", "rozet": "ok", "baslik": "Sıradaki: Açıkları bulan skill'ler", "alt": "Video 3/6", "adimlar": [
            {"soz": "Sıradaki videoda, güvenlik açıklarını bulan skill'leri tanıyacağız."},
        ]},
    ],
}
