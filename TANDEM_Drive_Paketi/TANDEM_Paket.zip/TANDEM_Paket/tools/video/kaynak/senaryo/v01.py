"""Video 1: veri (metin + ekranda görünecek öğeler). Düzenleme rehberi: __init__.py."""

VIDEO = {
    "no": 1, "dosya": "01_Yapay_zeka_ne_yapar_nerede_yanilir", "renk": (255, 138, 61),
    "baslik": "Yapay zekâ ne yapar, nerede yanılır?",
    "sahneler": [
        {"tur": "kapak", "baslik": "Yapay zekâ ne yapar, nerede yanılır?", "alt": "Seri tanıtımı ve temel uyarılar", "adimlar": [
            {"soz": "Merhaba! Bu kısa seride, yapay zekâyla tek başına nasıl iş çıkaracağını öğreneceksin."},
            {"soz": "İlk konu: yapay zekâ neyi çok iyi yapar, nerede yanılır?"},
        ]},
        {"tur": "liste", "baslik": "Çok iyi yaptığı işler", "adimlar": [
            {"soz": "Kodu okur, açıklar ve değiştirir. Bir dosyayı anlamadıysan, “bu dosya ne yapıyor?” diye sorman yeterli.",
             "madde": ("ok", "Kodu okur, açıklar, değiştirir", "“Bu dosya ne yapıyor?” diye sorabilirsin")},
            {"soz": "MCP bağlantısıyla Roblox Studio'yu yönetir: oyunu başlatır, test eder, ekran görüntüsü alır.",
             "madde": ("ok", "Studio'yu MCP ile yönetir", "Play'e basar, test eder, ekran görüntüsü alır")},
            {"soz": "Ölçerek hata bulur. TANDEM'de efektler engele değmeden önce çıkıyordu. Yapay zekâ nedenini ölçtü: ekrandaki araç, sunucunun saniyenin beşte biri kadar gerisinde kalıyordu.",
             "madde": ("ok", "Ölçerek hata bulur", "TANDEM: araç görüntüsü 0,19 sn geriydi → efekt erken çıkıyordu")},
            {"soz": "Sıkıcı işleri de hızla bitirir: belge, test, paket, hatta bu video.",
             "madde": ("ok", "Sıkıcı işi hızla bitirir", "Belge, test, paket, video")},
        ]},
        {"tur": "liste", "baslik": "Yanıldığı yerler", "adimlar": [
            {"soz": "Uydurabilir. Var olmayan bir dosya adı, bir Roblox özelliği ya da komut yazabilir. Buna halüsinasyon denir.",
             "madde": ("x", "Uydurabilir (halüsinasyon)", "Var olmayan dosya, özellik, komut")},
            {"soz": "Yanlışken bile çok emin konuşur. Emin ses tonu, doğru olduğu anlamına gelmez.",
             "madde": ("x", "Yanlışken bile emin konuşur", "Emin ton ≠ doğru cevap")},
            {"soz": "Denemeden “çalışmalı” diyebilir. Çalıştırıp görmediği şeye güvenme.",
             "madde": ("x", "Denemeden “çalışmalı” der", "Çalıştırıp görmediği şeye güvenme")},
            {"soz": "Uzun sohbette baştaki kuralları unutabilir. Önemli kararları dosyaya yazdır.",
             "madde": ("x", "Uzun sohbette unutur", "Önemli kararları dosyaya yazdır")},
            {"soz": "Bir web sayfasındaki ya da dosyadaki yazıyı komut sanabilir. Komutu yalnızca sen verirsin.",
             "madde": ("uyari", "Dışarıdaki yazıyı komut sanabilir", "Web sayfası, dosya, hata mesajı: hepsi veri")},
        ]},
        {"tur": "kart", "adimlar": [
            {"soz": "Gerçek bir örnek. Proje sahibinin bilgisayarında yapay zekâ, VPN'i hiçbir projenin başlatmadığını söyledi.",
             "ikon": "bilgi", "buyuk": "“Hiçbir proje VPN'i başlatmıyor.”", "kucuk": "Yapay zekânın ilk cevabı"},
            {"soz": "Yanlıştı. Akım projesi her açılışta VPN'i başlatıyordu. Kanıt aranınca bulundu ve düzeltildi.",
             "ikon": "uyari", "buyuk": "Yanlış çıktı.", "kucuk": "Akım projesi her açılışta başlatıyordu → kanıt arayınca bulundu"},
        ]},
        {"tur": "liste", "baslik": "Altın kural: güven ama doğrula", "adimlar": [
            {"soz": "Altın kural: güven ama doğrula. Önemli her cevapta şunu sor: bunu nasıl doğruladın?"},
            {"soz": "İyi bir cevap kanıtını etiketler. Doğrulandı: çalıştırdım ve gördüm.",
             "madde": ("yesil", "Doğrulandı", "Çalıştırdım, gördüm")},
            {"soz": "Belgeye göre: resmî kaynakta yazıyor.",
             "madde": ("mavi", "Belgeye göre", "Resmî kaynakta yazıyor (adı verilir)")},
            {"soz": "Tahmin: kanıt yok. Tahmin varsa, nasıl doğrulanacağını da sor.",
             "madde": ("sari", "Tahmin", "Kanıt yok → nasıl doğrulanacağı yazılmalı")},
        ]},
        {"tur": "kapak", "rozet": "ok", "baslik": "Sıradaki: Yapay zekâyı doğru düşündürmek", "alt": "Video 2/6", "adimlar": [
            {"soz": "Bir sonraki videoda, yapay zekâyı doğru düşündürmenin yollarını göreceğiz."},
        ]},
    ],
}
