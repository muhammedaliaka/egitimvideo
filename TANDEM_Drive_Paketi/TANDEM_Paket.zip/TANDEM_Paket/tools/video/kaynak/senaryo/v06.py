"""Video 6: veri (metin + ekranda görünecek öğeler). Düzenleme rehberi: __init__.py."""

VIDEO = {
    "no": 6, "dosya": "06_Projeyi_birlikte_surdurmek", "renk": (6, 214, 160),
    "baslik": "Projeyi birlikte sürdürmek",
    "sahneler": [
        {"tur": "kapak", "baslik": "Projeyi birlikte sürdürmek", "alt": "Proje sahibi ara sıra destek verir; işi siz yürütürsünüz", "adimlar": [
            {"soz": "Son video. Proje sahibi artık ara sıra destek verecek. Projeyi siz sürdüreceksiniz; işte yöntem."},
        ]},
        {"tur": "akis", "baslik": "Her görevde döngü", "adimlar": [
            {"soz": "Önce oku: yapay zekâya vaka dosyasını ve ekip günlüğünü okut.", "kutu": "Oku (VAKA + GÜNLÜK)"},
            {"soz": "Günlükteki kilitler tablosuna adını ve dokunacağın dosyaları yaz.", "kutu": "Kilit al"},
            {"soz": "Yapay zekâyla küçük bir adım yap ve denetimi çalıştır: sıfır ihlal.", "kutu": "Yap + denetle"},
            {"soz": "Studio'da Play'e basıp kendin dene.", "kutu": "Studio'da dene"},
            {"soz": "Günlüğe ne yaptığını ve test sonucunu yaz, kilidi kaldır.", "kutu": "Günlüğe yaz, kilidi kaldır"},
            {"soz": "Değişen dosyaların listesini birleştiriciye gönder.", "kutu": "Birleştiriciye gönder"},
        ]},
        {"tur": "kod", "baslik": "Her oturumda ilk mesaj", "adimlar": [
            {"soz": "Her yeni oturumda ilk mesajın şu olsun.",
             "satirlar": ["TANDEM yönergesini yükle.", "docs/VAKA_TANDEM.md ve", "docs/EKIP_GUNLUGU.md dosyalarını oku."]},
            {"soz": "Açık işleri sıralasın ve sana bir sonraki küçük adımı önersin.",
             "satirlar": ["Açık işleri sırala,", "bir sonraki küçük adımı öner."]},
        ]},
        {"tur": "kod", "baslik": "Aracında skill yoksa", "adimlar": [
            {"soz": "Aracında skill yoksa, ilk satırı değiştir: yönergeyi dosyadan okut.",
             "satirlar": ["AGENTS.md dosyasını oku ve uygula.", "docs/VAKA_TANDEM.md ve", "docs/EKIP_GUNLUGU.md dosyalarını oku."]},
        ]},
        {"tur": "liste", "baslik": "Çakışma olmasın", "adimlar": [
            {"soz": "Ekipten bir kişi birleştirici olsun: değişiklikleri toplar ve yeni paketi herkese dağıtır.",
             "madde": ("ok", "Bir kişi birleştirici olsun", "Değişiklikleri toplar, yeni paketi dağıtır")},
            {"soz": "Aynı dosyaya iki kişi aynı anda dokunmasın. Kilitler tablosu bunun için.",
             "madde": ("x", "Aynı dosyaya aynı anda iki kişi dokunmaz", "Önce kilitler tablosuna bak")},
            {"soz": "Team Create'te toplu silme ya da toplu ad değiştirme yapma; herkese anında yansır.",
             "madde": ("x", "Team Create'te toplu silme yok", "Herkese anında yansır")},
        ]},
        {"tur": "liste", "baslik": "Proje sahibine ne zaman yazmalı?", "adimlar": [
            {"soz": "Proje sahibine şu durumlarda yaz: oyunu yayınlamak, davet göndermek ya da herkese açmak.",
             "madde": ("uyari", "Yayınlama, davet, herkese açma", None)},
            {"soz": "Hesap, para ya da satın alma gereken işler.",
             "madde": ("uyari", "Hesap, para, satın alma", None)},
            {"soz": "Kilitli bir kararı değiştirmek istediğinde.",
             "madde": ("uyari", "Kilitli bir kararı değiştirmek", "docs/PRODUCT_KARARLAR_tandem.md")},
            {"soz": "Ya da iki gündür çözemediğin bir sorun varsa.",
             "madde": ("uyari", "2 gündür çözülmeyen sorun", None)},
        ]},
        {"tur": "kod", "baslik": "Yardım mesajı kalıbı", "adimlar": [
            {"soz": "Yazarken tek mesajda dört şeyi ver: ne yapmaya çalıştın ve ne oldu,",
             "satirlar": ["Ne yapmaya çalıştım: …", "Ne oldu (hata metni): …"]},
            {"soz": "ne denedin ve ekip günlüğündeki ilgili satır.",
             "satirlar": ["Ne denedim: …", "Günlükteki satır: …"]},
        ]},
        {"tur": "kart", "adimlar": [
            {"soz": "Unutma: yapay zekâ çok hızlı ve çalışkan bir ekip arkadaşı. Bazen yanılır. Yönetici sensin. Başarılar!",
             "ikon": "ok", "buyuk": "Yapay zekâ hızlı bir ekip arkadaşıdır.", "kucuk": "Bazen yanılır. Yönetici sensin. Başarılar!"},
        ]},
    ],
}
