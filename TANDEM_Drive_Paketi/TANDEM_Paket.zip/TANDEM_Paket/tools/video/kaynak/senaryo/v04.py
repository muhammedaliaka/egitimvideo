"""Video 4: veri (metin + ekranda görünecek öğeler). Düzenleme rehberi: __init__.py."""

VIDEO = {
    "no": 4, "dosya": "04_Yapay_zeka_ile_video_duzenleme", "renk": (139, 92, 246),
    "baslik": "Yapay zekâ ile video düzenleme",
    "sahneler": [
        {"tur": "kapak", "baslik": "Yapay zekâ ile video düzenleme", "alt": "Bu video da böyle yapıldı", "adimlar": [
            {"soz": "Dördüncü video: yapay zekâyla video düzenleme. İlginç bir bilgi: izlediğin bu video da böyle yapıldı."},
        ]},
        {"tur": "akis", "baslik": "Bu video nasıl yapıldı?", "adimlar": [
            {"soz": "Önce senaryo yazıldı: her cümle ve ekranda ne görüneceği.", "kutu": "Senaryo (metin)"},
            {"soz": "Sonra her cümle, Microsoft'un yapay sinir sesiyle okundu. Anahtar ya da hesap gerekmedi.", "kutu": "Ses (Microsoft sinir sesi)"},
            {"soz": "Ekranlar Python ile çizildi; yazılar cümleyle birlikte belirdi.", "kutu": "Çizim (Python)"},
            {"soz": "Son olarak ffmpeg; sesi, müziği ve görüntüyü tek dosyada birleştirdi.", "kutu": "Birleştirme (ffmpeg)"},
            {"soz": "Ama son adım her zaman insan: izle, hatayı bul, düzelttir.", "kutu": "İnsan izler, düzelttirir"},
        ]},
        {"tur": "liste", "baslik": "Hazır motor ve araçlar", "adimlar": [
            {"soz": "ffmpeg: kesme, birleştirme ve ses ayarı yapan ücretsiz motor. Neredeyse her araç bunu kullanır.",
             "madde": ("nokta", "ffmpeg", "Kes, birleştir, ses ayarı: her şeyin motoru")},
            {"soz": "Proje sahibinde video-editing skill'i kurulu: gerçek çekimi keser, yapılandırır, altyazı ekler.",
             "madde": ("nokta", "video-editing (skill) · sahibinde", "Gerçek çekimi kes, yapılandır, altyazı ekle")},
            {"soz": "Yine proje sahibinde kinocut adlı bir video MCP'si kurulu: kesme, altyazı ve kalite kontrolü yapar.",
             "madde": ("nokta", "kinocut (MCP) · sahibinde", "Kesme, altyazı, kalite kontrol")},
        ]},
        {"tur": "liste", "baslik": "Videoyu kodla yazmak", "adimlar": [
            {"soz": "Remotion: videoyu React koduyla yazarsın. Eski MCP'si kalktı; resmî yöntem artık skill'ler.",
             "madde": ("nokta", "Remotion (React)", "Resmî skill'ler: npx skills add remotion-dev/skills · MCP kullanımdan kalktı")},
            {"soz": "Hyperframes: videoyu HTML ile yazarsın. HeyGen'in açık kaynak aracı, Apache 2.0 lisanslı. Proje sahibinde kuruldu ve bir örnek video üretildi.",
             "madde": ("nokta", "Hyperframes (HTML)", "HeyGen · Apache-2.0 · sahibinde kuruldu, örnek video üretildi")},
        ]},
        {"tur": "liste", "baslik": "Profesyonel editör: DaVinci Resolve", "adimlar": [
            {"soz": "DaVinci Resolve'u yapay zekâya bağlayan açık kaynak bir MCP var; MIT lisanslı.",
             "madde": ("nokta", "DaVinci Resolve MCP", "Açık kaynak (MIT) · Resolve 18.5 ve üstü")},
            {"soz": "Dışarıdan tam kontrol için ücretli Studio sürümü gerekir. Ücretsiz sürümde komutlar program içinden bağlanır.",
             "madde": ("uyari", "Tam kontrol: ücretli Studio", "Ücretsiz sürüm: program içi köprü")},
            {"soz": "Bu ekipte DaVinci kurulu değil. İstersen kendi bilgisayarında dene.",
             "madde": ("nokta", "Bu ekipte kurulu değil", "İstersen kendi bilgisayarında dene")},
        ]},
        {"tur": "akis", "baslik": "Kendi çekiminden video", "adimlar": [
            {"soz": "Kendi çekiminden video yapmak için önce ekranını kaydet. OBS ücretsizdir.", "kutu": "Ekranı kaydet (OBS)"},
            {"soz": "Kaydı yapay zekâya ver ve ne istediğini söyle.", "kutu": "Yapay zekâya ver"},
            {"soz": "Önce kısa bir taslak çıkarsın.", "kutu": "Kısa taslak"},
            {"soz": "Sen izle ve dakika, saniye vererek not al.", "kutu": "İzle, not al (dk:sn)"},
            {"soz": "Notlara göre son sürümü çıkarsın. Ekibin MCP videoları da tam böyle yapıldı.", "kutu": "Son sürüm"},
        ]},
        {"tur": "kod", "baslik": "Örnek istek", "adimlar": [
            {"soz": "Örnek istek: kayıttaki sessiz ve bekleme yerlerini kes,",
             "satirlar": ["kayit.mp4'ü düzenle:", "- sessiz ve bekleme yerlerini kes,"]},
            {"soz": "tıklanan yerleri yakınlaştır, her adıma Türkçe altyazı ekle,",
             "satirlar": ["- tıklanan yerleri yakınlaştır,", "- her adıma Türkçe altyazı ekle,"]},
            {"soz": "e-posta ve parola görünen yerleri bulanıklaştır. Önce bir dakikalık taslak çıkar.",
             "satirlar": ["- e-posta, parola görünen yeri bulanıklaştır.", "Önce 1 dakikalık taslak çıkar."]},
        ]},
        {"tur": "liste", "baslik": "Dikkat", "adimlar": [
            {"soz": "Yapay zekâ videoyu insan gibi baştan sona izleyemez; kareleri örnekler. Son kontrol sende.",
             "madde": ("uyari", "Videoyu tam izleyemez", "Kareleri örnekler; son kontrol sende")},
            {"soz": "Kayıtta parola, e-posta ya da anahtar görünmesin.",
             "madde": ("uyari", "Kişisel bilgi görünmesin", "Parola, e-posta, anahtar")},
            {"soz": "Müzik ve görüntünün telif hakkına dikkat et.",
             "madde": ("uyari", "Müzik ve görüntü telifi", "Lisansı belli olmayanı kullanma")},
            {"soz": "Remotion üç çalışana kadar ücretsiz; daha büyük kârlı şirketler lisans almalı.",
             "madde": ("uyari", "Remotion lisansı", "En fazla 3 çalışan: ücretsiz · fazlası: şirket lisansı")},
            {"soz": "Araç ve skill'i kurmadan önce resmî kaynağını ve komutunu oku.",
             "madde": ("uyari", "Kurmadan önce oku", "Resmî kaynak · komutu ve dosyaları gözden geçir")},
        ]},
        {"tur": "kapak", "rozet": "ok", "baslik": "Sıradaki: MCP ve skill'leri kendine göre kurmak", "alt": "Video 5/6", "adimlar": [
            {"soz": "Sıradaki video: MCP ve skill'leri kendine göre kurmak."},
        ]},
    ],
}
