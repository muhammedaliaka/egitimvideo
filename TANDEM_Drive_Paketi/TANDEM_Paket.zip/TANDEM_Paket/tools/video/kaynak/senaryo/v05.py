"""Video 5: veri (metin + ekranda görünecek öğeler). Düzenleme rehberi: __init__.py."""

VIDEO = {
    "no": 5, "dosya": "05_MCP_ve_skillleri_kurmak", "renk": (255, 209, 102),
    "baslik": "MCP ve skill'leri kendine göre kurmak",
    "sahneler": [
        {"tur": "kapak", "baslik": "MCP ve skill'leri kendine göre kurmak", "alt": "Kural dosyası · skill · MCP · dosya erişimi", "adimlar": [
            {"soz": "Beşinci video: yapay zekâyı kendine göre kurmak. Üç parça var: kural dosyası, skill ve MCP."},
        ]},
        {"tur": "liste", "baslik": "Üç parça", "adimlar": [
            {"soz": "Kural dosyası, projenin kuralları. Yapay zekâ her oturumda onu baştan okur. Adı araca göre değişir: CLAUDE.md ya da AGENTS.md gibi. Hangisini okuduğunu yapay zekâya sorabilirsin.",
             "madde": ("sayi", "Kural dosyası = proje kuralları", "CLAUDE.md, AGENTS.md… (araca göre)")},
            {"soz": "Skill, gerektiğinde açılan talimat kitabıdır.",
             "madde": ("sayi", "Skill = talimat kitabı", "Gerektiğinde açılır")},
            {"soz": "MCP ise yapay zekânın elleridir: Studio'yu, tarayıcıyı ya da GitHub'ı kullanmasını sağlar.",
             "madde": ("sayi", "MCP = yapay zekânın elleri", "Studio, tarayıcı, GitHub…")},
        ]},
        {"tur": "kod", "baslik": "Claude Code: .claude/skills/tandem-ekip/SKILL.md", "adimlar": [
            {"soz": "Claude Code'da kendi skill'ini yazmak kolay. Proje klasöründe şu yolda bir dosya açarsın. Skill'i olmayan araçlarda aynı metni kural dosyasına yazarsın.",
             "satirlar": ["---", "name: tandem-ekip", "description: TANDEM'de her işten önce yüklenir.", "---"]},
            {"soz": "İlk satırlarda ad ve açıklama var. Yapay zekâ, açıklamaya bakarak skill'i ne zaman açacağına karar verir."},
            {"soz": "Altına kuralları sade dille yazarsın.",
             "satirlar": ["# Kurallar", "- Kullanıcıya sade Türkçe yaz.", "- Dosya başına en çok 25 KB."]},
            {"soz": "Bir püf noktası: skill'e, yüklendiğini kanıtlayan bir ilk satır yazdır. TANDEM skill'i bunun için “TANDEM yönergesi yüklendi” diye başlar.",
             "satirlar": ["- İlk satırın: “TANDEM yönergesi yüklendi.”"]},
        ]},
        {"tur": "liste", "baslik": "Dosya erişimi: ne kadar izin?", "adimlar": [
            {"soz": "Yapay zekâ, açtığın proje klasöründe çalışır ve oradaki dosyalara erişir.",
             "madde": ("ok", "Proje klasörünü aç", "Yapay zekâ orada çalışır")},
            {"soz": "Başka bir klasör gerekiyorsa, onu da ekleyebilirsin. Claude Desktop'ta bunu Filesystem uzantısı yapar; kurulumunu ayrı videoda gösterdik.",
             "madde": ("ok", "Gerekirse klasör ekle", "Başka proje, ortak belgeler")},
            {"soz": "Ama bütün diske geniş izin verme. İndirilenler ve masaüstünde özel dosyalar olabilir.",
             "madde": ("uyari", "Tüm diske geniş izin verme", "İndirilenler, masaüstü, şifre dosyaları")},
            {"soz": "Yapay zekâ bir komut için izin istediğinde, ne yapacağını oku, sonra onayla.",
             "madde": ("uyari", "İzin isteğini oku, sonra onayla", None)},
        ]},
        {"tur": "liste", "baslik": "MCP güvenliği", "adimlar": [
            {"soz": "Tanımadığın bir MCP'yi kurma. MCP bilgisayarında işlem yapabilir. Studio MCP'si oyununu değiştirir, Desktop Commander gibi güçlü bir MCP ise senin yetkinle komut çalıştırır.",
             "madde": ("x", "Tanımadığın MCP'yi kurma", "Studio MCP oyunu değiştirir · Desktop Commander komut çalıştırır")},
            {"soz": "Parola ve anahtarları sohbete yazma. Gerekirse .env dosyasında tut ve Git'e koyma.",
             "madde": ("x", "Parola ve anahtarı sohbete yazma", ".env dosyasında tut, Git'e koyma")},
            {"soz": "MCP'yi resmî kaynaktan kur. Roblox Studio MCP kurulumunu ilk rehber videoda göstermiştik.",
             "madde": ("ok", "Resmî kaynaktan kur", "Studio MCP: ilk rehber videosu")},
        ]},
        {"tur": "kod", "baslik": "Kendine göre ayarlat", "adimlar": [
            {"soz": "En kolay yol: yapay zekâdan kendi kurulumunu yapmasını iste.",
             "satirlar": ["Bu projede her değişiklikten sonra", "denetim.js çalışsın ve 0 ihlal olsun."]},
            {"soz": "Bunu kural dosyasına eklesin ve ne eklediğini sana göstersin.",
             "satirlar": ["Bunu kural dosyasına ekle", "(CLAUDE.md ya da AGENTS.md)", "ve eklediğin satırı göster."]},
        ]},
        {"tur": "kapak", "rozet": "ok", "baslik": "Sıradaki: Projeyi birlikte sürdürmek", "alt": "Video 6/6", "adimlar": [
            {"soz": "Son video: projeyi birlikte nasıl sürdüreceğiniz."},
        ]},
    ],
}
