# Windows'un yerleşik Türkçe sesiyle (Microsoft Tolga, OneCore) metni WAV'a çevirir. İndirme gerektirmez.
# Kullanım: powershell -ExecutionPolicy Bypass -File ses.ps1 -Liste is.json
# is.json: [{"metin": "...", "cikti": "C:\\...\\001.wav"}, ...]  (cikti zaten varsa atlanır; elle kaydedilmiş ses korunur)
param([Parameter(Mandatory = $true)][string]$Liste, [double]$Hiz = 1.0)
$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTaskGenel = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
	$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]
function Bekle($islem, [Type]$tur) {
	$gorev = $asTaskGenel.MakeGenericMethod($tur).Invoke($null, @($islem))
	$gorev.Wait(-1) | Out-Null
	$gorev.Result
}

[Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media.SpeechSynthesis, ContentType = WindowsRuntime] | Out-Null
$sentez = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer
$ses = [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices | Where-Object { $_.Language -eq 'tr-TR' } | Select-Object -First 1
if (-not $ses) { throw "Türkçe ses (tr-TR) bulunamadı. Ayarlar > Saat ve dil > Konuşma bölümünden Türkçe ses ekle." }
$sentez.Voice = $ses
$sentez.Options.SpeakingRate = $Hiz

$isler = Get-Content -Raw -Encoding UTF8 $Liste | ConvertFrom-Json
foreach ($is in $isler) {
	if (Test-Path $is.cikti) { continue }
	$akis = Bekle ($sentez.SynthesizeTextToStreamAsync($is.metin)) ([Windows.Media.SpeechSynthesis.SpeechSynthesisStream])
	$net = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($akis)
	$dosya = [System.IO.File]::Create($is.cikti)
	$net.CopyTo($dosya)
	$dosya.Close(); $net.Close()
	Write-Output ("ses: " + [System.IO.Path]::GetFileName($is.cikti))
}
Write-Output ("ses motoru: " + $ses.DisplayName)
