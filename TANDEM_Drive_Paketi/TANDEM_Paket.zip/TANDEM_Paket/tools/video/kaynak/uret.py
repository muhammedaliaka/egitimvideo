"""TANDEM eğitim videolarını üretir.

Kullanım (kaynak klasöründe):  python uret.py [1 2 ...] [--kareler]
  numara verilmezse 6 videonun hepsi; --kareler yalnızca kontrol kareleri üretir (kare/), video yazmaz.
Akış: seslendirme (ses_motor.py: ses_ayar.json'daki motor, yalnızca eksik/değişen cümleler) -> zaman çizelgesi -> kareler (cizim.py) ffmpeg'e akar
      -> ses karışımı (konuşma + fon müziği + efekt) -> cikti/<ad>.mp4 + .srt
Kendi sesin: ses_kendi/ klasörüne ses/ ile aynı adlı WAV koyarsan o kullanılır.
"""
import json
import re
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

import cizim
import muzik
import ses_motor
from senaryo import SESLETIM, VIDEOLAR

KAYNAK = Path(__file__).resolve().parent
KOK = KAYNAK.parent
SES, SES_KENDI, GECICI, CIKTI, KARE = KOK / "ses", KOK / "ses_kendi", KOK / "gecici", KOK / "cikti", KOK / "kare"
FPS, SR, W, H = 30, muzik.SR, cizim.W, cizim.H

BAS_SN, GIRIS_SN, ARA_SN, SAHNE_SON_SN = 0.5, 0.7, 0.45, 0.6
GECIS_SN, ANIM_SN, KAYMA_PX = 0.5, 0.5, 48
YAZIM_EN_COK_SN, SON_BEKLE_SN, KARARMA_SN = 1.4, 2.0, 0.8
MUZIK_SEVIYE, KISMA, POP_SEVIYE, GECIS_SEVIYE = 0.10, 0.55, 0.16, 0.45
ALTYAZI_ALT_BOSLUK = 40
OGE_ANAHTARLARI = ("madde", "kutu", "sol", "sag", "buyuk")


def sesletim(metin):
    for k in sorted(SESLETIM, key=len, reverse=True):
        metin = metin.replace(k, SESLETIM[k])
    return metin.replace("“", "").replace("”", "")


def ses_adi(v, i, j):
    return f"{v['no']:02d}_{i:02d}_{j:02d}.wav"


def seslendir(videolar):
    kayit_yolu = SES / "metinler.json"
    kayit = json.loads(kayit_yolu.read_text("utf-8")) if kayit_yolu.exists() else {}
    if kayit.get("_motor") != ses_motor.imza():
        for eski in SES.glob("*.wav"):
            eski.unlink()  # ses motoru/sesi/hızı değişti: hepsi yeniden okunacak
        kayit = {"_motor": ses_motor.imza()}
    isler = []
    for v in videolar:
        for i, s in enumerate(v["sahneler"]):
            for j, a in enumerate(s["adimlar"]):
                ad, metin = ses_adi(v, i, j), sesletim(a["soz"])
                yol = SES / ad
                if kayit.get(ad) != metin and yol.exists():
                    yol.unlink()  # metin değişti: yeniden okunacak
                if not yol.exists():
                    isler.append({"metin": metin, "cikti": str(yol)})
                kayit[ad] = metin
    ses_motor.uret(isler, GECICI)
    kayit_yolu.write_text(json.dumps(kayit, ensure_ascii=False, indent=1), "utf-8")


def wav_oku(yol):
    with wave.open(str(yol)) as w:
        if w.getsampwidth() != 2:
            raise ValueError(f"16 bit WAV bekleniyordu: {yol}")
        sr, ch = w.getframerate(), w.getnchannels()
        x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float) / 32768
    if ch == 2:
        x = x.reshape(-1, 2).mean(axis=1)
    dolu = np.where(np.abs(x) > 0.01)[0]
    if len(dolu):
        x = x[max(dolu[0] - int(0.03 * sr), 0): dolu[-1] + int(0.1 * sr)]
    if sr != SR:
        x = np.interp(np.arange(int(len(x) * SR / sr)) * sr / SR, np.arange(len(x)), x)
    return x / (np.max(np.abs(x)) + 1e-9) * 0.85


def cizelge(v):
    t, sahneler = BAS_SN, []
    for i, s in enumerate(v["sahneler"]):
        bas = t
        t += GIRIS_SN
        adimlar = []
        for j, a in enumerate(s["adimlar"]):
            ad = ses_adi(v, i, j)
            x = wav_oku(SES_KENDI / ad if (SES_KENDI / ad).exists() else SES / ad)
            adimlar.append({"bas": t, "sure": len(x) / SR, "ses": x, "a": a})
            t += len(x) / SR + ARA_SN
        t += SAHNE_SON_SN - ARA_SN
        sahneler.append({"bas": bas, "son": t, "adimlar": adimlar, "s": s})
    return sahneler, t + SON_BEKLE_SN


# ------------------------------------------------------------------ altyazı
def _satir(metin):
    return cizim.altyazi_satir_sayisi(metin)


def altyazi_parcalari(metin):
    if _satir(metin) <= 2:
        return [metin]
    parcalar, s = [], ""
    for c in re.split(r"(?<=[.!?:;])\s+", metin):
        dene = (s + " " + c).strip()
        if s and _satir(dene) > 2:
            parcalar.append(s)
            s = c
        else:
            s = dene
    parcalar.append(s)
    sonuc = []
    for p in parcalar:
        while _satir(p) > 2:
            k = p.split()
            n = len(k)
            while n > 1 and _satir(" ".join(k[:n])) > 2:
                n -= 1
            sonuc.append(" ".join(k[:n]))
            p = " ".join(k[n:])
        sonuc.append(p)
    return sonuc


def altyazilar(sahneler):
    liste = []
    for sh in sahneler:
        for ad in sh["adimlar"]:
            parcalar = altyazi_parcalari(ad["a"]["soz"])
            toplam, t = sum(len(p) for p in parcalar), ad["bas"]
            for p in parcalar:
                d = ad["sure"] * len(p) / toplam
                liste.append([t, t + d, p])
                t += d
            liste[-1][1] = ad["bas"] + ad["sure"] + ARA_SN * 0.8
    return liste


def srt_yaz(liste, yol):
    def zaman(t):
        ms = int(round(t * 1000))
        return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"
    yol.write_text("\n".join(f"{k}\n{zaman(a)} --> {zaman(b)}\n{m}\n" for k, (a, b, m) in enumerate(liste, 1)), "utf-8")


# ------------------------------------------------------------------ kareler
def yumusak(p):
    return 1 - (1 - min(max(p, 0.0), 1.0)) ** 3


class Kareci:
    def __init__(self, v, sahneler, toplam, alt):
        self.v, self.sahneler, self.toplam, self.alt = v, sahneler, toplam, alt
        self.onbellek = {}

    def S(self, i, n):
        if (i, n) not in self.onbellek:
            self.onbellek[(i, n)] = cizim.sahne_ciz(self.v, self.sahneler[i]["s"], n)
        return self.onbellek[(i, n)]

    def son_hal(self, i):
        return self.S(i, len(self.sahneler[i]["adimlar"]))

    def sahne_karesi(self, i, t):
        sh = self.sahneler[i]
        s, adimlar = sh["s"], sh["adimlar"]
        n = sum(1 for ad in adimlar if ad["bas"] <= t)
        if n == 0:
            return self.S(i, 0)
        ad = adimlar[n - 1]
        a, gecen = ad["a"], t - ad["bas"]
        if s["tur"] == "kod" and a.get("satirlar"):
            toplam = sum(len(x) for x in a["satirlar"])
            kar = int(toplam * min(gecen / min(YAZIM_EN_COK_SN, 0.7 * ad["sure"]), 1.0))
            return self.S(i, n) if kar >= toplam else cizim.sahne_ciz(self.v, s, n, yazim=(n - 1, kar))
        if not any(k in a for k in OGE_ANAHTARLARI) or gecen >= ANIM_SN:
            return self.S(i, n)
        e = yumusak(gecen / ANIM_SN)
        sonraki = self.S(i, n) if s["tur"] == "kart" else cizim.sahne_ciz(self.v, s, n, dx=int(KAYMA_PX * (1 - e)))
        return Image.blend(self.S(i, n - 1), sonraki, e)

    def kare(self, t):
        i = max(k for k, sh in enumerate(self.sahneler) if sh["bas"] <= t or k == 0)
        img = self.sahne_karesi(i, t)
        bas = self.sahneler[i]["bas"]
        img = Image.blend(self.son_hal(i - 1), img, yumusak((t - bas) / GECIS_SN)) if i > 0 and t < bas + GECIS_SN else img.copy()
        for a, b, metin in self.alt:
            if a <= t < b:
                kat = cizim.altyazi_katmani(metin)
                img.paste(kat, (0, H - ALTYAZI_ALT_BOSLUK - kat.height), kat)
                break
        c = ImageDraw.Draw(img)
        c.rectangle([0, H - 8, W, H], fill=(30, 38, 58))
        c.rectangle([0, H - 8, int(W * t / self.toplam), H], fill=self.v["renk"])
        karanlik = min(t / KARARMA_SN, (self.toplam - t) / KARARMA_SN, 1.0)
        if karanlik < 1.0:
            img = Image.blend(Image.new("RGB", (W, H)), img, max(karanlik, 0.0))
        return img


def video_yaz(kareci, wav, mp4, v):
    komut = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
             "-i", str(wav), "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
             "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-c:a", "aac", "-b:a", "160k", "-ar", str(SR),
             "-metadata", f"title={v['baslik']}", "-metadata", "artist=TANDEM ekip eğitimi", "-movflags", "+faststart", "-shortest", str(mp4)]
    surec = subprocess.Popen(komut, stdin=subprocess.PIPE)
    for f in range(int(kareci.toplam * FPS)):
        surec.stdin.write(kareci.kare(f / FPS).tobytes())
    surec.stdin.close()
    if surec.wait() != 0:
        raise RuntimeError(f"ffmpeg başarısız: {mp4}")


# ------------------------------------------------------------------ ses
def kayan_ortalama(x, n):
    c = np.cumsum(np.insert(x, 0, 0.0))
    y = (c[n:] - c[:-n]) / n
    return np.pad(y, (n // 2, len(x) - len(y) - n // 2), mode="edge")


def _ekle(hedef, x, t0):
    i = int(t0 * SR)
    if 0 <= i < len(hedef):
        n = min(len(x), len(hedef) - i)
        hedef[i:i + n] += x[:n, None] if x.ndim == 1 else x[:n]


def ses_karisimi(sahneler, toplam, yol):
    n = int(toplam * SR)
    konusma = np.zeros(n)
    for sh in sahneler:
        for ad in sh["adimlar"]:
            i0 = int(ad["bas"] * SR)
            k = min(len(ad["ses"]), n - i0)
            konusma[i0:i0 + k] += ad["ses"][:k]
    pencere = int(0.25 * SR)
    kis = 1 - KISMA * np.clip(kayan_ortalama(np.abs(konusma), pencere) / 0.04, 0, 1)
    kis = kayan_ortalama(kis, pencere)
    karisim = muzik.fon_muzigi(toplam)[:n] * MUZIK_SEVIYE * kis[:, None]
    karisim[:, 0] += konusma
    karisim[:, 1] += konusma
    for k, sh in enumerate(sahneler):
        if k > 0:
            _ekle(karisim, muzik.efekt_gecis() * GECIS_SEVIYE, sh["bas"] - 0.25)
        for ad in sh["adimlar"]:
            if sh["s"]["tur"] != "kod" and any(x in ad["a"] for x in OGE_ANAHTARLARI):
                _ekle(karisim, muzik.efekt_pop() * POP_SEVIYE, ad["bas"])
    karisim /= max(1.0, np.max(np.abs(karisim)) / 0.95)
    with wave.open(str(yol), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((karisim * 32767).astype(np.int16).tobytes())


# ------------------------------------------------------------------ ana akış
def kontrol_kareleri(kareci, v):
    for i, sh in enumerate(kareci.sahneler):
        for etiket, t in (("son", sh["son"] - 0.05), ("anim", sh["adimlar"][-1]["bas"] + ANIM_SN * 0.4)):
            kareci.kare(t).resize((W // 2, H // 2), Image.LANCZOS).save(KARE / f"{v['no']:02d}_{i:02d}_{etiket}.png")


def main():
    args = sys.argv[1:]
    nolar = {int(a) for a in args if a.isdigit()}
    secili = [v for v in VIDEOLAR if not nolar or v["no"] in nolar]
    for d in (SES, SES_KENDI, GECICI, CIKTI, KARE):
        d.mkdir(parents=True, exist_ok=True)
    seslendir(secili)
    for v in secili:
        sahneler, toplam = cizelge(v)
        alt = altyazilar(sahneler)
        kareci = Kareci(v, sahneler, toplam, alt)
        if "--kareler" in args:
            kontrol_kareleri(kareci, v)
            print(f"{v['dosya']}: kontrol kareleri yazıldı ({toplam:.1f} sn)")
            continue
        wav = GECICI / f"{v['dosya']}.wav"
        ses_karisimi(sahneler, toplam, wav)
        video_yaz(kareci, wav, CIKTI / f"{v['dosya']}.mp4", v)
        srt_yaz(alt, CIKTI / f"{v['dosya']}.srt")
        print(f"{v['dosya']}: {toplam:.1f} sn")


if __name__ == "__main__":
    main()
