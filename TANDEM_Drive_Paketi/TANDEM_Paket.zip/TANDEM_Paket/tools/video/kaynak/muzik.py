"""Yerelde sentezlenen sakin fon müziği ve küçük efektler (telifsiz, 48 kHz stereo). Önceki rehber videosunun muzik.py'sinden sadeleştirildi."""
import numpy as np

SR = 48000
BPM = 70
VURUS = 60.0 / BPM
OLCU = VURUS * 4
AKORLAR = [
    [60, 64, 67, 71, 74], [57, 60, 64, 67, 71], [53, 57, 60, 64, 67], [55, 59, 62, 64, 69],
    [50, 53, 57, 60, 64], [55, 59, 62, 65, 69], [60, 64, 67, 71, 74], [57, 60, 64, 67, 71],
]
ARP = [0, 2, 4, 3, 1, 3]
RNG = np.random.default_rng(11)


def frekans(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


def _t(sure):
    return np.arange(int(sure * SR)) / SR


def _ekle(hedef, ses, t0, sol=1.0, sag=1.0):
    i = int(t0 * SR)
    if i >= len(hedef) or i < 0:
        return
    n = min(len(ses), len(hedef) - i)
    hedef[i:i + n, 0] += ses[:n] * sol
    hedef[i:i + n, 1] += ses[:n] * sag


def _pad(f, sure):
    t = _t(sure + 1.5)
    s = sum(np.sin(2 * np.pi * f * (1 + d) * t) + 0.3 * np.sin(2 * np.pi * 2 * f * (1 + d) * t) for d in (-0.003, 0.0, 0.004))
    zarf = np.minimum(t / 1.2, 1.0) * np.where(t > sure, np.exp(-(t - sure) / 0.6), 1.0)
    return s * zarf * 0.05


def _tus(f):
    t = _t(2.0)
    mod = 1.4 * np.exp(-6 * t) * np.sin(2 * np.pi * f * t)
    s = np.sin(2 * np.pi * f * t + mod) * np.exp(-2.2 * t)
    return s * np.minimum(t / 0.005, 1.0) * 0.12


def fon_muzigi(sure):
    out = np.zeros((int((sure + 2) * SR), 2))
    t, k = 0.0, 0
    while t < sure:
        akor = AKORLAR[k % len(AKORLAR)]
        for j, m in enumerate(akor[:4]):
            p = _pad(frekans(m - 12), OLCU)
            _ekle(out, p, t, 0.8 + 0.1 * (j % 2), 0.9 - 0.1 * (j % 2))
        for b, idx in enumerate(ARP):
            if (k + b) % 3 == 2:  # seyrek: her ölçüde birkaç nota
                continue
            tt = t + b * OLCU / len(ARP)
            pan = 0.35 + 0.3 * ((b * 37 + k * 11) % 7) / 6
            _ekle(out, _tus(frekans(akor[idx])), tt, 1 - pan, pan)
        t += OLCU
        k += 1
    out = out[: int(sure * SR)]
    sonu = int(min(3.0, sure / 4) * SR)
    out[-sonu:] *= np.linspace(1, 0, sonu)[:, None]
    basi = int(1.5 * SR)
    out[:basi] *= np.linspace(0, 1, basi)[:, None]
    return out / (np.max(np.abs(out)) + 1e-9)


def efekt_pop():
    t = _t(0.16)
    f = 600 + 500 * (1 - np.exp(-t / 0.03))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.045) * 0.5


def efekt_gecis(sure=0.7):
    t = _t(sure)
    n = RNG.standard_normal(len(t))
    # basit yumuşatılmış gürültü (whoosh): kayan ortalama penceresi zamanla daralır
    p = t / sure
    pencere = 24
    s = np.convolve(n, np.ones(pencere) / pencere, mode="same")
    s = s / (np.max(np.abs(s)) + 1e-9)
    return s * np.sin(np.pi * p) ** 2 * 0.35
