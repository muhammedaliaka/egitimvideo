"""Ekran kaydı montajı (Yol A): plan dosyasına göre keser, hızlandırır, yakınlaştırır, bulandırır, seslendirir ve altyazı yazar.

Kullanım (kaynak klasöründe):
  python kayit.py planlar\\mcp_1_filesystem_desktop_commander.json --kaynak "C:\\...\\kayit.mp4"
  --kareler : videoyu birleştirmez; her bölümün karesinden kontrol sayfası üretir (kare\\)
Orijinal kayda dokunmaz. Çıktı: cikti\\<dosya>.mp4 + .srt. Anlatım yoksa video sessiz olur.
Seslendirme: ses_motor.py (ses_ayar.json: Microsoft sinir sesi ya da Windows sesi).

Plan (JSON): dosya, baslik, alt, renk [r,g,b], kapanis, bolumler[]; isteğe bağlı kapak_anlatim, kapanis_anlatim,
sesletim {"yazım": "okunuş"} (plana özel okunuş, genel sözlük senaryo/sesletim.py). Her bölüm:
  basla, bitis   "d:ss" ya da saniye (kaynak kayıttan)
  hiz            1 = gerçek hız, 2 = iki kat hızlı. Anlatım sığmazsa hız en çok 0.6'ya kadar düşer (yavaşlatma), yine sığmazsa son kare tutulur
  duzen          "tam": yakınlaştırılmış kare + alt bant altyazı | "yan": sol metin paneli + sağda dar kesit
  kirp           [x, y, w, h] kaynak pikseli; "tam" için 16:9, "yan" için 900x884 oranı
  baslik, metin  ekrandaki altyazı
  anlatim        seslendirilecek metin (.srt de bundan yazılır)
  bulanik        isteğe bağlı [[x, y, w, h], ...] kaynak pikselinde bulandırılacak alanlar (isim, e-posta, anahtar, kullanıcı adı).
                 Varsayılan KAPALI: yalnız ortam değişkeni TANDEM_BULANIK=1 iken uygulanır (plandaki kutular durur, silinmez).
                 Kutu yalnız bir an görünüyorsa 5. ve 6. değer olarak kaynak zamanı yaz: [x, y, w, h, "6:41", "6:55"]
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

import cizim
import ses_motor
from senaryo import SESLETIM

KAYNAK = Path(__file__).resolve().parent
KOK = KAYNAK.parent
GECICI, CIKTI, KARE = KOK / "gecici", KOK / "cikti", KOK / "kare"
SES = GECICI / "kayit_ses"
W, H, FPS, MIX_SR = cizim.W, cizim.H, 30, 48000

KART_SN = 3.0
BAS_GECIKME_SN, KUYRUK_SN, EN_DUSUK_HIZ = 0.3, 0.6, 0.6
YAN_SOL, BANT_YUK = 820, 190
BULANIK_ETKIN = os.environ.get("TANDEM_BULANIK") == "1"  # varsayılan KAPALI (proje sahibi kararı 2026-10-07): bulanıklık ekranı okunmaz yapıyor; açmak için TANDEM_BULANIK=1
BULANIK_YARICAP, BULANIK_GUC = 24, 3  # boxblur renk kanalı yarıçapı kutunun dörtte birinden küçük olmalı (bkz. bulanik_zinciri)
HEDEF_LUFS = "loudnorm=I=-16:TP=-1.5:LRA=11"
KODLA = ["-c:v", "libx264", "-preset", "fast", "-crf", "20", "-pix_fmt", "yuv420p", "-r", str(FPS), "-an"]
SARI = cizim.SARI


def sn(z):
    if isinstance(z, (int, float)):
        return float(z)
    d, s = str(z).split(":")
    return int(d) * 60 + float(s)


def ffmpeg(*args):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *map(str, args)])
    if r.returncode:
        sys.exit("ffmpeg hata verdi: " + " ".join(map(str, args))[:300])


def zaman_srt(t):
    ms = int(round(t * 1000))
    return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


# ------------------------------------------------------------------ seslendirme
def okunus(metin, ek):
    sozluk = {**SESLETIM, **ek}
    for k in sorted(sozluk, key=len, reverse=True):
        metin = metin.replace(k, sozluk[k])
    return metin.replace("“", "").replace("”", "")


def ses_oku(yol):
    """WAV -> MIX_SR örnekleme, baş/son sessizliği kırpılmış, tepe 0.85 olan float dizi."""
    with wave.open(str(yol)) as w:
        sr, ch = w.getframerate(), w.getnchannels()
        x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float64) / 32768
    if ch == 2:
        x = x.reshape(-1, 2).mean(axis=1)
    dolu = np.where(np.abs(x) > 0.01)[0]
    if len(dolu):
        x = x[max(dolu[0] - int(0.03 * sr), 0): dolu[-1] + int(0.1 * sr)]
    x = np.interp(np.arange(int(len(x) * MIX_SR / sr)) * sr / MIX_SR, np.arange(len(x)), x)
    return x / (np.max(np.abs(x)) + 1e-9) * 0.85


def anlatimlar(plan):
    """Sırayla (anahtar, metin): kapak, bölüm numaraları, kapanış (yalnızca anlatımı olanlar)."""
    liste = [("kapak", plan["kapak_anlatim"])] if plan.get("kapak_anlatim") else []
    liste += [(i, b["anlatim"]) for i, b in enumerate(plan["bolumler"]) if b.get("anlatim")]
    return liste + ([("kapanis", plan["kapanis_anlatim"])] if plan.get("kapanis_anlatim") else [])


def sesleri_uret(plan):
    SES.mkdir(exist_ok=True)
    isler, yol = [], {}
    for anahtar, metin in anlatimlar(plan):
        o = okunus(metin, plan.get("sesletim", {}))
        ad = hashlib.md5((ses_motor.imza() + "|" + o).encode("utf-8")).hexdigest()[:12] + ".wav"
        yol[anahtar] = SES / ad
        isler.append({"metin": o, "cikti": str(yol[anahtar])})
    ses_motor.uret(isler, GECICI)
    return {k: ses_oku(p) for k, p in yol.items()}


def cumleler(metin, bas, sure):
    """Anlatımı cümlelere böl, süreyi harf sayısına orantılı dağıt: [(başlangıç, bitiş, cümle)]."""
    parca = [c for c in re.split(r"(?<=[.!?])\s+", metin.strip()) if c]
    toplam = sum(len(c) for c in parca)
    t, sonuc = bas, []
    for c in parca:
        d = sure * len(c) / toplam
        sonuc.append((t, t + d, c))
        t += d
    return sonuc


# ------------------------------------------------------------------ katmanlar (PNG)
def rozet_yaz(c, b, x, y):
    if abs(b["hiz"] - 1) > 0.05:
        etiket = "%gx %s" % (round(b["hiz"], 1), "hızlandırıldı" if b["hiz"] > 1 else "yavaşlatıldı")
        c.rounded_rectangle([x, y, x + 250, y + 46], radius=12, fill=(40, 52, 80))
        c.text((x + 125, y + 23), etiket, font=cizim.F(28), fill=cizim.SOLUK, anchor="mm")


def bant_png(b, yol):
    im = Image.new("RGBA", (W, BANT_YUK), (0, 0, 0, 0))
    c = ImageDraw.Draw(im)
    c.rectangle([0, 0, W, BANT_YUK], fill=(6, 8, 15, 225))
    c.text((60, 20), b["baslik"], font=cizim.FK(40), fill=SARI, anchor="lt")
    y = 76
    for s in cizim.sar(b["metin"], cizim.F(40), W - 140)[:2]:
        c.text((60, y), s, font=cizim.F(40), fill=cizim.YAZI, anchor="lt")
        y += 52
    rozet_yaz(c, b, W - 310, 20)
    im.save(yol)


def yan_png(b, renk, yol):
    im = cizim.arka_plan(tuple(renk)).copy()
    c = ImageDraw.Draw(im)
    y = 150
    for s in cizim.sar(b["baslik"], cizim.FK(56), YAN_SOL - 140):
        c.text((80, y), s, font=cizim.FK(56), fill=SARI, anchor="lt")
        y += 72
    c.rounded_rectangle([80, y + 6, 200, y + 14], radius=4, fill=tuple(renk))
    y += 50
    for s in cizim.sar(b["metin"], cizim.F(40), YAN_SOL - 140):
        c.text((80, y), s, font=cizim.F(40), fill=cizim.YAZI, anchor="lt")
        y += 56
    rozet_yaz(c, b, 80, H - 120)
    im.save(yol)


def kart_png(baslik, alt, renk, yol):
    im = cizim.arka_plan(tuple(renk)).copy()
    c = ImageDraw.Draw(im)
    y = 380
    for s in cizim.sar(baslik, cizim.FK(80), 1560):
        c.text((W // 2, y), s, font=cizim.FK(80), fill=cizim.YAZI, anchor="mt")
        y += 100
    for s in cizim.sar(alt, cizim.F(44), 1500) if alt else []:
        c.text((W // 2, y + 24), s, font=cizim.F(44), fill=cizim.SOLUK, anchor="mt")
        y += 58
    im.save(yol)


# ------------------------------------------------------------------ bölüm üretimi
def bulanik_zinciri(bolge, basla):
    """[x, y, w, h] her zaman; [x, y, w, h, "d:ss", "d:ss"] yalnız o kaynak-zaman aralığında (içerik kayarsa kutu da değişsin diye)."""
    f = ""
    for i, (x, y, w, h, *aralik) in enumerate(bolge if BULANIK_ETKIN else []):
        ac = ""
        if aralik:
            bas, bit = (sn(t) - basla for t in aralik)
            ac = f":enable='between(t,{bas:.3f},{bit:.3f})'"
        r = max(1, min(BULANIK_YARICAP, min(w, h) // 4 - 1))
        f += f"split=2[a{i}][b{i}];[b{i}]crop={w}:{h}:{x}:{y},boxblur={r}:{BULANIK_GUC}[c{i}];[a{i}][c{i}]overlay={x}:{y}{ac},"
    return f


def sure_ve_hiz(b, d):
    """Anlatım (d sn) sığsın diye hızı EN_DUSUK_HIZ'a kadar düşür (1'in altı = yavaşlatma), yine sığmazsa son kareyi tut: (etkin hız, toplam süre, dondurma)."""
    kaynak_sn = sn(b["bitis"]) - sn(b["basla"])
    gerek = d + BAS_GECIKME_SN + KUYRUK_SN if d else 0.0
    hiz = b["hiz"]
    if gerek and kaynak_sn / hiz < gerek:
        hiz = max(EN_DUSUK_HIZ, kaynak_sn / gerek)
    taban = kaynak_sn / hiz
    dondur = max(0.0, gerek - taban)
    return hiz, taban + dondur, dondur


def bolum_uret(kaynak, b, renk, no, cikis, d):
    hiz, sure, dondur = sure_ve_hiz(b, d)
    b = {**b, "hiz": hiz}
    png = GECICI / f"katman_{no:02d}.png"
    yan = b["duzen"] == "yan"
    if yan:
        yan_png(b, renk, png)
    else:
        bant_png(b, png)
    x, y, w, h = b["kirp"]
    hedef_w, hedef_h = (W - YAN_SOL, H) if yan else (W, H)
    tut = f",tpad=stop_mode=clone:stop_duration={dondur:.3f}" if dondur else ""
    video = (
        "[0:v]" + bulanik_zinciri(b.get("bulanik", []), sn(b["basla"]))
        + f"crop={w}:{h}:{x}:{y},scale={hedef_w}:{hedef_h}:flags=lanczos,setpts=PTS/{hiz:.4f},fps={FPS}{tut}[v];"
    )
    birlestir = f"[1:v][v]overlay={YAN_SOL}:0:shortest=1[o]" if yan else f"[v][1:v]overlay=0:{H - BANT_YUK}:shortest=1[o]"
    ffmpeg("-ss", sn(b["basla"]), "-t", sn(b["bitis"]) - sn(b["basla"]), "-i", kaynak,
           "-loop", 1, "-framerate", FPS, "-i", png,
           "-filter_complex", video.rstrip(",") + birlestir, "-map", "[o]", "-t", f"{sure:.3f}", *KODLA, cikis)
    return sure


def kart_uret(baslik, alt, renk, no, sure, cikis):
    png = GECICI / f"kart_{no}.png"
    kart_png(baslik, alt, renk, png)
    ffmpeg("-loop", 1, "-framerate", FPS, "-i", png, "-t", f"{sure:.3f}", *KODLA, cikis)


def kart_suresi(d):
    return max(KART_SN, d + BAS_GECIKME_SN + KUYRUK_SN) if d else KART_SN


def ses_dosyasi(parcalar, toplam_sn, yol):
    """[(başlangıç sn, float dizi)] -> tek WAV (MIX_SR, 16 bit mono)."""
    mix = np.zeros(int(toplam_sn * MIX_SR) + MIX_SR)
    for bas, x in parcalar:
        i = int(bas * MIX_SR)
        mix[i:i + len(x)] += x[: len(mix) - i]
    pcm = (np.clip(mix, -1, 1) * 32767).astype(np.int16)
    with wave.open(str(yol), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(MIX_SR)
        w.writeframes(pcm.tobytes())


def kontrol_sayfasi(parcalar, yol):
    kareler = []
    for p in parcalar:
        k = GECICI / (p.stem + ".jpg")
        ffmpeg("-i", p, "-vf", "select=eq(n\\,%d)" % FPS, "-frames:v", 1, "-q:v", 3, k)
        if k.exists():
            kareler.append(k)
    sutun = 3
    satir = (len(kareler) + sutun - 1) // sutun
    sayfa = Image.new("RGB", (640 * sutun, 360 * satir), (20, 20, 20))
    for i, k in enumerate(kareler):
        sayfa.paste(Image.open(k).resize((640, 360)), ((i % sutun) * 640, (i // sutun) * 360))
    sayfa.save(yol, quality=85)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("plan")
    ap.add_argument("--kaynak", required=True, help="orijinal ekran kaydı (değiştirilmez)")
    ap.add_argument("--kareler", action="store_true", help="yalnızca kontrol sayfası üret")
    a = ap.parse_args()
    plan = json.loads(Path(a.plan).read_text(encoding="utf-8"))
    kaynak, renk, ad = Path(a.kaynak), plan.get("renk", [66, 165, 245]), plan["dosya"]
    if not kaynak.is_file():
        sys.exit(f"Kayıt bulunamadı: {kaynak}")
    for k in (GECICI, CIKTI, KARE):
        k.mkdir(exist_ok=True)
    ses = sesleri_uret(plan)
    sure_of = lambda anahtar: len(ses[anahtar]) / MIX_SR if anahtar in ses else 0.0  # noqa: E731

    parcalar, srt, sesler, t = [], [], [], 0.0
    giris = GECICI / f"{ad}_00_kapak.mp4"
    sure = kart_suresi(sure_of("kapak"))
    kart_uret(plan["baslik"], plan.get("alt", ""), renk, "kapak", sure, giris)
    parcalar.append(giris)
    if "kapak" in ses:
        sesler.append((t + BAS_GECIKME_SN, ses["kapak"]))
        srt += cumleler(plan["kapak_anlatim"], t + BAS_GECIKME_SN, sure_of("kapak"))
    t += sure
    for i, b in enumerate(plan["bolumler"]):
        cikis = GECICI / f"{ad}_{i + 1:02d}.mp4"
        sure = bolum_uret(kaynak, b, renk, i + 1, cikis, sure_of(i))
        if i in ses:
            sesler.append((t + BAS_GECIKME_SN, ses[i]))
            srt += cumleler(b["anlatim"], t + BAS_GECIKME_SN, sure_of(i))
        else:
            srt.append((t, t + sure, b["baslik"] + ". " + b["metin"]))
        parcalar.append(cikis)
        t += sure
        print(f"bölüm {i + 1}: {sure:.1f} sn ({b['basla']}-{b['bitis']} x{b['hiz']}, anlatım {sure_of(i):.1f} sn)")
    son = GECICI / f"{ad}_99_kapanis.mp4"
    sure = kart_suresi(sure_of("kapanis"))
    kart_uret(plan["kapanis"], "", renk, "kapanis", sure, son)
    parcalar.append(son)
    if "kapanis" in ses:
        sesler.append((t + BAS_GECIKME_SN, ses["kapanis"]))
        srt += cumleler(plan["kapanis_anlatim"], t + BAS_GECIKME_SN, sure_of("kapanis"))
    t += sure

    kontrol_sayfasi(parcalar, KARE / f"{ad}_sayfa.jpg")
    if a.kareler:
        print("kontrol sayfası:", KARE / f"{ad}_sayfa.jpg", f"| toplam {t:.1f} sn")
        return
    liste = GECICI / f"{ad}_liste.txt"
    liste.write_text("".join(f"file '{p.as_posix()}'\n" for p in parcalar), encoding="utf-8")
    mp4 = CIKTI / f"{ad}.mp4"
    if sesler:
        sessiz, wav = GECICI / f"{ad}_sessiz.mp4", GECICI / f"{ad}_ses.wav"
        ffmpeg("-f", "concat", "-safe", 0, "-i", liste, "-c", "copy", sessiz)
        ses_dosyasi(sesler, t, wav)
        ffmpeg("-i", sessiz, "-i", wav, "-c:v", "copy", "-af", HEDEF_LUFS, "-c:a", "aac", "-b:a", "160k", "-ar", MIX_SR,
               "-t", f"{t:.3f}", "-movflags", "+faststart", mp4)
    else:
        ffmpeg("-f", "concat", "-safe", 0, "-i", liste, "-c", "copy", "-movflags", "+faststart", mp4)
    (CIKTI / f"{ad}.srt").write_text(
        "".join(f"{n}\n{zaman_srt(b)} --> {zaman_srt(e)}\n{m}\n\n" for n, (b, e, m) in enumerate(srt, 1)), encoding="utf-8")
    print(f"TOPLAM {t:.1f} sn -> {mp4}")


if __name__ == "__main__":
    main()
