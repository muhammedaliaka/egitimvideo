"""Microsoft sinir sesiyle (edge-tts) cümleleri WAV'a çevirir. Doğrudan çağrılmaz; ses_motor.py çağırır.
Kullanım: python ses_edge.py is.json   (is.json: [{"metin": "...", "cikti": "...\\001.wav"}])
Ayar: ses_ayar.json. Servis internet ister; metin Microsoft'a gider (resmî olmayan edge-tts yolu).
"""
import asyncio
import json
import subprocess
import sys
from pathlib import Path

KAYNAK = Path(__file__).resolve().parent


async def bir(edge_tts, sem, a, is_):
    cikti = Path(is_["cikti"])
    mp3 = cikti.with_suffix(".mp3")
    async with sem:
        for n in range(a["deneme"]):
            try:
                await edge_tts.Communicate(is_["metin"], a["ses"], rate=a["hiz"], pitch=a["perde"]).save(str(mp3))
                break
            except Exception as hata:
                if n + 1 == a["deneme"]:
                    raise RuntimeError(f"Ses üretilemedi ({cikti.name}): {hata}") from hata
                await asyncio.sleep(2 ** n)
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(mp3),
                        "-ar", str(a["ornekleme"]), "-ac", "1", "-c:a", "pcm_s16le", str(cikti)])
    mp3.unlink(missing_ok=True)
    if r.returncode:
        cikti.unlink(missing_ok=True)
        raise RuntimeError(f"ffmpeg WAV'a çeviremedi: {cikti.name}")
    print("ses:", cikti.name)


async def main(liste):
    try:
        import edge_tts
    except ImportError:
        sys.exit("edge-tts kurulu değil: pip install edge-tts (ya da ses_ayar.json içinde motor = windows yap)")
    a = json.loads((KAYNAK / "ses_ayar.json").read_text("utf-8"))
    isler = json.loads(Path(liste).read_text("utf-8"))
    sem = asyncio.Semaphore(a["es_zamanli"])
    await asyncio.gather(*(bir(edge_tts, sem, a, i) for i in isler))
    print("ses motoru: edge-tts", a["ses"])


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1]))
