"""Sahne çizimi (PIL, 1920x1080). Her sahne türü, ilk n adımın öğeleri görünür hâlde çizilir; son öğe dx kadar kaydırılabilir."""
from functools import lru_cache
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

W, H = 1920, 1080
FONTLAR = Path(r"C:\Windows\Fonts")

ARKA1, ARKA2 = (12, 16, 27), (21, 28, 46)
YAZI, SOLUK = (236, 240, 248), (150, 162, 186)
KUTU, KUTU_VURGU, KENAR = (27, 35, 55), (36, 47, 74), (55, 68, 100)
YESIL, KIRMIZI, SARI, MAVI = (46, 204, 113), (239, 83, 80), (255, 193, 7), (66, 165, 245)
KOYU = (14, 17, 27)
RENKLI_NOKTA = {"yesil": YESIL, "mavi": MAVI, "sari": SARI}

ICERIK_UST, ICERIK_ALT = 290, 850
SOL = 140


@lru_cache(None)
def _font(ad, boy):
    return ImageFont.truetype(str(FONTLAR / ad), boy)


def F(boy):
    return _font("segoeui.ttf", boy)


def FK(boy):
    return _font("segoeuib.ttf", boy)


def FY(boy):
    return _font("seguisb.ttf", boy)


def FM(boy):
    return _font("consola.ttf", boy)


def uzerine_yazi(renk):
    """Dolgu rengi üstünde okunur yazı rengi (açık zeminde koyu, koyu zeminde beyaz)."""
    r, g, b = renk
    return KOYU if 0.299 * r + 0.587 * g + 0.114 * b > 150 else (255, 255, 255)


def sar(metin, font, genislik):
    satirlar, s = [], ""
    for k in metin.split():
        dene = (s + " " + k).strip()
        if not s or font.getlength(dene) <= genislik:
            s = dene
        else:
            satirlar.append(s)
            s = k
    if s:
        satirlar.append(s)
    return satirlar


def sigdir(metin, font, genislik):
    if font.getlength(metin) > genislik:
        raise ValueError(f"Metin sığmıyor ({font.getlength(metin):.0f}>{genislik}px): {metin}")


# ------------------------------------------------------------------ çerçeve
@lru_cache(8)
def arka_plan(renk):
    y = np.linspace(0, 1, H)[:, None, None]
    img = np.array(ARKA1, float) * (1 - y) + np.array(ARKA2, float) * y
    img = np.broadcast_to(img, (H, W, 3)).copy()
    xs = np.linspace(0, W / H, W)[None, :]
    ys = np.linspace(0, 1, H)[:, None]
    d = np.sqrt((xs - 0.9 * W / H) ** 2 + (ys - 0.04) ** 2)
    parilti = (np.exp(-(d / 0.6) ** 2) * 0.16)[..., None]
    img = img * (1 - parilti) + np.array(renk, float) * parilti
    im = Image.fromarray(img.clip(0, 255).astype(np.uint8))
    c = ImageDraw.Draw(im)
    for gx in range(64, W, 64):
        for gy in range(64, H, 64):
            c.rectangle([gx, gy, gx + 1, gy + 1], fill=(36, 46, 68))
    return im


@lru_cache(8)
def cerceve(renk, seri, ust_sag):
    im = arka_plan(renk).copy()
    c = ImageDraw.Draw(im)
    c.rounded_rectangle([80, 44, 98, 62], radius=4, fill=renk)
    c.text((112, 53), seri, font=F(28), fill=SOLUK, anchor="lm")
    c.text((W - 80, 53), ust_sag, font=FY(28), fill=SOLUK, anchor="rm")
    return im


def baslik(c, metin, renk):
    sigdir(metin, FK(62), W - 2 * SOL)
    c.text((SOL, 140), metin, font=FK(62), fill=YAZI, anchor="lt")
    c.rounded_rectangle([SOL, 238, SOL + 120, 246], radius=4, fill=renk)


# ------------------------------------------------------------------ simgeler
def isaret(c, tur, cx, cy, renk, sayi=None, r=26):
    if tur == "ok":
        c.ellipse([cx - r, cy - r, cx + r, cy + r], fill=YESIL)
        k = r / 26
        c.line([(cx - 12 * k, cy + 1 * k), (cx - 3 * k, cy + 10 * k), (cx + 13 * k, cy - 9 * k)], fill=(255, 255, 255), width=max(3, int(6 * k)), joint="curve")
    elif tur == "x":
        c.ellipse([cx - r, cy - r, cx + r, cy + r], fill=KIRMIZI)
        k = r / 26 * 10
        for a, b in (((cx - k, cy - k), (cx + k, cy + k)), ((cx - k, cy + k), (cx + k, cy - k))):
            c.line([a, b], fill=(255, 255, 255), width=max(3, int(r / 26 * 6)))
    elif tur == "uyari":
        c.polygon([(cx, cy - r - 2), (cx + r + 4, cy + r - 2), (cx - r - 4, cy + r - 2)], fill=SARI)
        c.text((cx, cy + 6), "!", font=FK(int(r * 1.25)), fill=KOYU, anchor="mm")
    elif tur == "bilgi":
        c.ellipse([cx - r, cy - r, cx + r, cy + r], fill=renk)
        c.text((cx, cy + 2), "i", font=FK(int(r * 1.3)), fill=uzerine_yazi(renk), anchor="mm")
    elif tur == "sayi":
        c.ellipse([cx - r, cy - r, cx + r, cy + r], fill=renk)
        c.text((cx, cy + 1), str(sayi), font=FK(int(r * 1.15)), fill=uzerine_yazi(renk), anchor="mm")
    elif tur == "nokta":
        c.ellipse([cx - 12, cy - 12, cx + 12, cy + 12], fill=renk)
    elif tur in RENKLI_NOKTA:
        c.ellipse([cx - 20, cy - 20, cx + 20, cy + 20], fill=RENKLI_NOKTA[tur])
    elif tur == "ileri":
        c.ellipse([cx - r, cy - r, cx + r, cy + r], fill=renk)
        k, yr = r / 100, uzerine_yazi(renk)
        c.polygon([(cx - 38 * k, cy - 16 * k), (cx + 4 * k, cy - 16 * k), (cx + 4 * k, cy - 40 * k), (cx + 50 * k, cy),
                   (cx + 4 * k, cy + 40 * k), (cx + 4 * k, cy + 16 * k), (cx - 38 * k, cy + 16 * k)], fill=yr)
    else:
        raise ValueError(f"Bilinmeyen işaret: {tur}")


def ok_ciz(c, x0, x1, y, renk, kalinlik=6):
    c.line([(x0, y), (x1 - 14, y)], fill=renk, width=kalinlik)
    c.polygon([(x1, y), (x1 - 22, y - 14), (x1 - 22, y + 14)], fill=renk)


# ------------------------------------------------------------------ sahne türleri
def _ogeli(sahne, anahtar):
    return [i for i, a in enumerate(sahne["adimlar"]) if anahtar in a]


def kapak(c, v, sahne, n, dx):
    renk = v["renk"]
    if sahne.get("rozet") == "ok":
        isaret(c, "ileri", W // 2, 330, renk, r=100)
    else:
        c.ellipse([W // 2 - 100, 230, W // 2 + 100, 430], fill=renk)
        c.text((W // 2, 334), str(v["no"]), font=FK(120), fill=uzerine_yazi(renk), anchor="mm")
    satirlar = sar(sahne["baslik"], FK(80), 1560)
    y = 490
    for s in satirlar:
        c.text((W // 2, y), s, font=FK(80), fill=YAZI, anchor="mt")
        y += 100
    if sahne.get("alt"):
        c.text((W // 2, y + 20), sahne["alt"], font=F(44), fill=SOLUK, anchor="mt")


def liste(c, v, sahne, n, dx):
    baslik(c, sahne["baslik"], v["renk"])
    ogeler = _ogeli(sahne, "madde")
    alt_var = any(sahne["adimlar"][i]["madde"][2] for i in ogeler)
    adim = min(150 if alt_var else 110, (ICERIK_ALT - ICERIK_UST) // max(len(ogeler), 1))
    sayac = 0
    for sira, i in enumerate(ogeler):
        if i >= n:
            break
        tur, metin, alt = sahne["adimlar"][i]["madde"]
        if tur == "sayi":
            sayac += 1
        kay = dx if i == n - 1 else 0
        y = ICERIK_UST + sira * adim + 30
        isaret(c, tur, 175 + kay, y, v["renk"], sayi=sayac)
        sigdir(metin, FY(46), W - 240 - 80)
        c.text((235 + kay, y), metin, font=FY(46), fill=YAZI, anchor="lm")
        if alt:
            sigdir(alt, F(34), W - 240 - 80)
            c.text((237 + kay, y + 50), alt, font=F(34), fill=SOLUK, anchor="lm")


def iki_sutun(c, v, sahne, n, dx):
    paneller = {"sol": (120, 180, 930, 850, YESIL, "ok"), "sag": (990, 180, 1800, 850, KIRMIZI, "x")}
    for taraf, (x0, y0, x1, y1, renk, tur) in paneller.items():
        c.rounded_rectangle([x0, y0, x1, y1], radius=26, fill=KUTU, outline=KENAR, width=2)
        c.text((x0 + 50, y0 + 40), sahne[taraf], font=FK(54), fill=renk, anchor="lt")
        y = y0 + 150
        for i in _ogeli(sahne, taraf):
            satirlar = sar(sahne["adimlar"][i][taraf], FY(40), x1 - x0 - 150)
            if i < n:
                kay = dx if i == n - 1 else 0
                isaret(c, tur, x0 + 72 + kay, y + 26, renk, r=22)
                for j, s in enumerate(satirlar):
                    c.text((x0 + 112 + kay, y + 26 + j * 50), s, font=FY(40), fill=YAZI, anchor="lm")
            y += len(satirlar) * 50 + 46
        if y > y1 + 20:
            raise ValueError(f"İki sütun taşıyor: {sahne[taraf]}")


KOD_X0, KOD_Y0, KOD_X1, KOD_Y1 = 180, 160, 1740, 860
KOD_SATIR_Y, KOD_SATIR_ARA = 270, 62


def kod_satirlari(sahne, n):
    satirlar = []
    for a in sahne["adimlar"][:n]:
        satirlar += a.get("satirlar", [])
    return satirlar


def kod(c, v, sahne, n, dx, yazim=None):
    """yazim=(adim, karakter): o adımın satırları karakter sayısı kadar yazılmış (daktilo)."""
    c.rounded_rectangle([KOD_X0, KOD_Y0, KOD_X1, KOD_Y1], radius=20, fill=(16, 20, 32), outline=KENAR, width=2)
    c.rounded_rectangle([KOD_X0, KOD_Y0, KOD_X1, KOD_Y0 + 66], radius=20, fill=(30, 38, 58), corners=(True, True, False, False))
    for k, renk in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
        cx = KOD_X0 + 40 + k * 32
        c.ellipse([cx - 9, KOD_Y0 + 24, cx + 9, KOD_Y0 + 42], fill=renk)
    c.text((KOD_X0 + 150, KOD_Y0 + 33), sahne["baslik"], font=FY(30), fill=SOLUK, anchor="lm")
    tam = kod_satirlari(sahne, n if yazim is None else yazim[0])
    yazilan = []
    if yazim is not None:
        kalan = yazim[1]
        for s in sahne["adimlar"][yazim[0]].get("satirlar", []):
            if kalan <= 0:
                break
            yazilan.append(s[:kalan])
            kalan -= len(s)
    y = KOD_SATIR_Y
    for s in tam + yazilan:
        sigdir(s, FM(42), KOD_X1 - KOD_X0 - 110)
        renk = SOLUK if s.strip() == "---" else (v["renk"] if s.startswith(("#", "-")) else YAZI)
        c.text((KOD_X0 + 60, y), s, font=FM(42), fill=renk, anchor="lm")
        y += KOD_SATIR_ARA
    if y > KOD_Y1:
        raise ValueError(f"Kod penceresi taşıyor: {sahne['baslik']}")
    if yazilan:
        son = yazilan[-1]
        x = KOD_X0 + 60 + FM(42).getlength(son) + 4
        yy = y - KOD_SATIR_ARA
        c.rectangle([x, yy - 24, x + 22, yy + 24], fill=v["renk"])


def akis_duzeni(sayi):
    satirlar = {1: [1], 2: [2], 3: [3], 4: [2, 2], 5: [3, 2], 6: [3, 3]}[sayi]
    kw, kh, ara = 460, 160, 100
    ys = [490] if len(satirlar) == 1 else [360, 640]
    kutular = []
    for r, adet in enumerate(satirlar):
        gen = adet * kw + (adet - 1) * ara
        x0 = (W - gen) // 2
        for k in range(adet):
            kutular.append((x0 + k * (kw + ara), ys[r], kw, kh, k < adet - 1))
    return kutular


def akis(c, v, sahne, n, dx):
    baslik(c, sahne["baslik"], v["renk"])
    ogeler = _ogeli(sahne, "kutu")
    duzen = akis_duzeni(len(ogeler))
    gorunen = [i for i in ogeler if i < n]
    for sira, i in enumerate(ogeler):
        if i >= n:
            break
        x, y, kw, kh, sonrasi_var = duzen[sira]
        son = i == gorunen[-1]
        kay = dx if i == n - 1 else 0
        x += kay
        c.rounded_rectangle([x, y, x + kw, y + kh], radius=24, fill=KUTU_VURGU if son else KUTU,
                            outline=v["renk"] if son else KENAR, width=5 if son else 3)
        isaret(c, "sayi", x + 46, y + kh // 2, v["renk"], sayi=sira + 1, r=24)
        satirlar = sar(sahne["adimlar"][i]["kutu"], FY(38), kw - 110)
        if len(satirlar) > 3:
            raise ValueError(f"Kutu metni uzun: {sahne['adimlar'][i]['kutu']}")
        y0 = y + kh // 2 - (len(satirlar) - 1) * 23
        for j, s in enumerate(satirlar):
            c.text((x + 86, y0 + j * 46), s, font=FY(38), fill=YAZI, anchor="lm")
        if sonrasi_var and sira + 1 < len(ogeler) and ogeler[sira + 1] < n:
            ok_ciz(c, x + kw + 14, x + kw + 86, y + kh // 2, KENAR)


def kart(c, v, sahne, n, dx):
    icerik = None
    for a in sahne["adimlar"][:n]:
        if "buyuk" in a:
            icerik = a
    kart_ust, kart_alt = 200, 840
    c.rounded_rectangle([260, kart_ust, 1660, kart_alt], radius=34, fill=KUTU, outline=KENAR, width=2)
    if icerik is None:
        return
    buyuk = sar(icerik["buyuk"], FK(62), 1220)
    kucuk = sar(icerik["kucuk"], F(38), 1240) if icerik.get("kucuk") else []
    yukseklik = 112 + 50 + len(buyuk) * 80 + (24 + len(kucuk) * 52 if kucuk else 0)
    if yukseklik > kart_alt - kart_ust - 60:
        raise ValueError(f"Kart taşıyor: {icerik['buyuk']}")
    y = (kart_ust + kart_alt - yukseklik) // 2
    isaret(c, icerik.get("ikon", "bilgi"), W // 2, y + 56, v["renk"], r=56)
    y += 112 + 50
    for s in buyuk:
        c.text((W // 2, y), s, font=FK(62), fill=YAZI, anchor="mt")
        y += 80
    y += 24
    for s in kucuk:
        c.text((W // 2, y), s, font=F(38), fill=SOLUK, anchor="mt")
        y += 52


TURLER = {"kapak": kapak, "liste": liste, "iki_sutun": iki_sutun, "kod": kod, "akis": akis, "kart": kart}


def sahne_ciz(v, sahne, n, dx=0, yazim=None, toplam=6):
    im = cerceve(v["renk"], "TANDEM · Yapay Zekâ Eğitimi", f"Video {v['no']}/{toplam}").copy()
    c = ImageDraw.Draw(im)
    if sahne["tur"] == "kod":
        kod(c, v, sahne, n, dx, yazim)
    else:
        TURLER[sahne["tur"]](c, v, sahne, n, dx)
    return im


# ------------------------------------------------------------------ altyazı
@lru_cache(256)
def altyazi_katmani(metin):
    font = F(42)
    satirlar = sar(metin, font, 1560)
    lh = 56
    gen = max(font.getlength(s) for s in satirlar)
    kh = lh * len(satirlar) + 26
    kat = Image.new("RGBA", (W, kh), (0, 0, 0, 0))
    c = ImageDraw.Draw(kat)
    c.rounded_rectangle([(W - gen) / 2 - 30, 0, (W + gen) / 2 + 30, kh], radius=16, fill=(6, 8, 15, 205))
    for i, s in enumerate(satirlar):
        c.text((W / 2, 13 + i * lh + lh / 2), s, font=font, fill=YAZI, anchor="mm")
    return kat


def altyazi_satir_sayisi(metin):
    return len(sar(metin, F(42), 1560))
