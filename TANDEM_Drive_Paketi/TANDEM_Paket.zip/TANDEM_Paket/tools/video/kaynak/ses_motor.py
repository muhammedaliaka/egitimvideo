"""Seslendirme motoru seçici. ses_ayar.json içindeki "motor" değerine göre cümleleri WAV'a çevirir:
  "edge"    Microsoft sinir sesi (tr-TR-AhmetNeural erkek, tr-TR-EmelNeural kadın). `pip install edge-tts` gerekir.
            DİKKAT: metin Microsoft'un çevrimiçi servisine gider (internet gerekir; gizli bilgi yazma).
  "windows" Windows'un yerleşik Türkçe sesi (çevrimdışı, daha yapay; ses.ps1).
edge-tts başka bir Python'a kuruluysa o yorumlayıcının yolunu TANDEM_SES_PYTHON ortam değişkenine yaz.
"""
import json
import os
import subprocess
import sys
from pathlib import Path

KAYNAK = Path(__file__).resolve().parent
IMZA_ALANLARI = ("motor", "ses", "hiz", "perde")


def ayar():
    return json.loads((KAYNAK / "ses_ayar.json").read_text("utf-8"))


def imza():
    """Motor/ses/hız değişince önbellekteki WAV'ların geçersiz olduğunu anlamak için."""
    a = ayar()
    return "|".join(str(a.get(k, "")) for k in IMZA_ALANLARI)


def uret(isler, gecici):
    """isler: [{"metin": ..., "cikti": ...wav}]. Çıktısı zaten olan iş atlanır."""
    isler = [i for i in isler if not Path(i["cikti"]).exists()]
    if not isler:
        return
    liste = Path(gecici) / f"ses_isleri_{os.getpid()}.json"  # eşzamanlı çalışmalar birbirini ezmesin
    liste.write_text(json.dumps(isler, ensure_ascii=False), "utf-8")
    if ayar()["motor"] == "windows":
        komut = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(KAYNAK / "ses.ps1"), "-Liste", str(liste)]
    else:
        komut = [os.environ.get("TANDEM_SES_PYTHON") or sys.executable, str(KAYNAK / "ses_edge.py"), str(liste)]
    subprocess.run(komut, check=True)
