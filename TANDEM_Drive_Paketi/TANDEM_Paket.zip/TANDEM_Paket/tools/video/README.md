# tools/video — ekip eğitim videosu şablonu

Metinden anlatımlı, altyazılı video üretir (Windows, Python, ffmpeg). Ayrıntı ve diğer yollar (Hyperframes, Remotion, DaVinci): `docs/VIDEO_REHBERI.md`.

Bir video en çok 3 dakika, tek konu. Gerekenler: `pip install pillow numpy edge-tts` ve ffmpeg.

**Ses:** varsayılan Microsoft sinir sesi `tr-TR-AhmetNeural` (`edge-tts`; internet ister, metin Microsoft'a gider, gizli bilgi yazma). Ayar: `kaynak/ses_ayar.json` (`ses`: Ahmet erkek, `tr-TR-EmelNeural` kadın; `hiz`, `perde`). İnternetsiz yedek: `"motor": "windows"`. `edge-tts` başka bir Python'daysa yolunu `TANDEM_SES_PYTHON` ortam değişkenine yaz. Kendi sesin: `ses_kendi/` altına aynı adlı WAV.

```
cd kaynak
python uret.py 4 --kareler    # kontrol kareleri -> ../kare
python uret.py 4              # video -> ../cikti
```

Ekran kaydını keserek/hızlandırarak videoya çevirmek için (araç fark etmez):

```
cd kaynak
python kayit.py planlar\mcp_1_filesystem_desktop_commander.json --kaynak "C:\...\kayit.mp4" --kareler   # kontrol sayfası -> ../kare
python kayit.py planlar\mcp_1_filesystem_desktop_commander.json --kaynak "C:\...\kayit.mp4"             # video + .srt -> ../cikti
```

- `kaynak/kayit.py` plan dosyasına (`kaynak/planlar/*.json`) göre keser, hızlandırır, yakınlaştırır, bulandırır, altyazı yazar, plandaki `anlatim` metnini seslendirir; orijinal kayda dokunmaz. Başındaki açıklama plan alanlarını anlatır. Kullanıcı adı/e-posta görünen kareleri `bulanik` ile kapat (içerik kayıyorsa kutuya zaman aralığı ekle); çıktı karelerine bakmadan paylaşma.
- `kaynak/senaryo/` her video bir dosya (v01.py ...); yeni video = bir dosya kopyala.
- `hyperframes_ornek/index.html` HTML ile video örneği (Hyperframes).
- Üretilen klasörler (`ses`, `cikti`, `kare`, `gecici`) git'e girmez.
